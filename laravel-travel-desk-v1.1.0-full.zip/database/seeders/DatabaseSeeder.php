<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\Role;
use App\Models\User;
use App\Models\Supplier;
use App\Models\Tour;
use App\Models\TourOption;
use App\Models\Addon;
use App\Models\Counter;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $adminRole = Role::firstOrCreate(['key' => 'admin'], [
            'name' => 'Admin',
            'permissions' => ['*'],
            'system' => true,
        ]);

        $agentRole = Role::firstOrCreate(['key' => 'sales_agent'], [
            'name' => 'Sales Agent',
            'permissions' => ['bookings.create', 'payments.record', 'receipts.print', 'attendance.self'],
            'system' => true,
        ]);

        $admin = User::firstOrCreate(['username' => 'admin'], [
            'email' => 'salesdesk@luxuryattractions.com',
            'password' => Hash::make('admin123'),
            'role_id' => $adminRole->id,
            'full_name' => 'System Administrator',
            'display_name' => 'Admin',
            'work_mobile' => '+971 52 888 5145',
            'monthly_salary' => 12000,
        ]);

        $agent = User::firstOrCreate(['username' => 'agent'], [
            'email' => 'agent@luxuryattractions.com',
            'password' => Hash::make('agent123'),
            'role_id' => $agentRole->id,
            'full_name' => 'Sara Ahmed',
            'display_name' => 'Sara',
            'work_mobile' => '+971 50 123 4567',
            'monthly_salary' => 6000,
        ]);

        $supplier = Supplier::firstOrCreate(['name' => 'Arabian Adventures DMC'], [
            'contact' => '+971 4 000 0000',
            'rating' => 4.9,
            'total_reviews' => 120,
        ]);

        // Desert Safari
        $ds = Tour::firstOrCreate(['code_prefix' => 'DS'], [
            'name' => 'Desert Safari',
            'product_type' => 'tour',
            'ticket_timing_type' => 'time_slotted',
            'description' => 'Evening desert safari with dune bashing, camel ride, BBQ dinner and live shows.',
            'shared_available' => true,
            'duration_minutes' => 360,
            'supplier_id' => $supplier->id,
            'operating_hours' => 'Daily 14:30 – 21:30',
        ]);
        TourOption::firstOrCreate(['tour_id' => $ds->id, 'name' => 'Normal'], ['adult_price' => 150, 'child_price' => 120]);
        TourOption::firstOrCreate(['tour_id' => $ds->id, 'name' => 'VIP'], ['adult_price' => 250, 'child_price' => 200]);

        // Burj Khalifa (Time-Slotted Ticket)
        $bk = Tour::firstOrCreate(['code_prefix' => 'BK'], [
            'name' => 'Burj Khalifa',
            'product_type' => 'ticket',
            'ticket_timing_type' => 'time_slotted',
            'description' => 'At the Top observation deck admission (Levels 124 & 125). Requires a specific entry time slot.',
            'opening_time' => '08:30',
            'closing_time' => '23:00',
            'operating_hours' => 'Daily 08:30 – 23:00 (last entry 22:15)',
            'validity' => 'Selected date & specific time slot only',
            'requires_ticket' => true,
            'no_transfer_allowed' => true,
            'duration_minutes' => 180,
            'supplier_id' => $supplier->id,
        ]);
        TourOption::firstOrCreate(['tour_id' => $bk->id, 'name' => 'At the Top (124/125) – Non-Prime'], ['adult_price' => 169, 'child_price' => 129, 'ticket_type' => 'E-ticket', 'sort' => 1]);
        TourOption::firstOrCreate(['tour_id' => $bk->id, 'name' => 'At the Top (124/125) – Prime Hours'], ['adult_price' => 249, 'child_price' => 199, 'ticket_type' => 'E-ticket', 'sort' => 2]);

        // Ski Dubai (Flexible Anytime Admission Ticket)
        $sd = Tour::firstOrCreate(['code_prefix' => 'SD'], [
            'name' => 'Ski Dubai',
            'product_type' => 'ticket',
            'ticket_timing_type' => 'anytime',
            'description' => 'Indoor ski resort located in Mall of the Emirates. Grants admission to the venue at any time on the selected date.',
            'opening_time' => '10:00',
            'closing_time' => '23:00',
            'operating_hours' => 'Daily 10:00 – 23:00 (Anytime admission on selected date)',
            'validity' => 'Valid at any time on selected date (Flexible entry)',
            'requires_ticket' => true,
            'no_transfer_allowed' => true,
            'duration_minutes' => 180,
            'supplier_id' => $supplier->id,
            'notes' => 'Admission valid all day during operating hours. Winter clothing provided.',
        ]);
        TourOption::firstOrCreate(['tour_id' => $sd->id, 'name' => 'Snow Classic Pass'], ['adult_price' => 265, 'child_price' => 265, 'ticket_type' => 'E-ticket', 'sort' => 1]);
        TourOption::firstOrCreate(['tour_id' => $sd->id, 'name' => 'Snow Plus Pass'], ['adult_price' => 340, 'child_price' => 340, 'ticket_type' => 'E-ticket', 'sort' => 2]);
        TourOption::firstOrCreate(['tour_id' => $sd->id, 'name' => '2 Hours Slope Pass'], ['adult_price' => 250, 'child_price' => 210, 'ticket_type' => 'E-ticket', 'sort' => 3]);

        // Initialize counters
        Counter::firstOrCreate(['key' => 'receipt:2026'], ['value' => 10]);
        Counter::firstOrCreate(['key' => 'tour:DS'], ['value' => 5]);
        Counter::firstOrCreate(['key' => 'tour:BK'], ['value' => 5]);
        Counter::firstOrCreate(['key' => 'tour:SD'], ['value' => 5]);
    }
}
