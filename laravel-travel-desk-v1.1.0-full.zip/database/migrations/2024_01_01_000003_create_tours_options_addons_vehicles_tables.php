<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('suppliers', function (Blueprint $table) {
            $table->id();
            $table->string('name')->unique();
            $table->string('contact')->nullable();
            $table->string('email')->nullable();
            $table->string('whatsapp')->nullable();
            $table->string('platform_url')->nullable();
            $table->string('platform_username')->nullable();
            $table->text('platform_password_encrypted')->nullable();
            $table->decimal('rating', 3, 2)->default(5.00);
            $table->integer('total_reviews')->default(0);
            $table->boolean('active')->default(true);
            $table->timestamps();
        });

        Schema::create('vehicles', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->integer('capacity');
            $table->decimal('price', 14, 2)->default(0);
            $table->decimal('supplier_cost', 14, 2)->default(0);
            $table->string('currency', 3)->default('AED');
            $table->unsignedBigInteger('tour_id')->nullable();
            $table->boolean('active')->default(true);
            $table->timestamps();
        });

        Schema::create('tours', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('code_prefix', 10)->unique();
            $table->text('description')->nullable();
            $table->string('product_type')->default('tour'); // tour | ticket
            $table->string('ticket_timing_type')->default('time_slotted'); // time_slotted | anytime
            $table->boolean('active')->default(true);
            $table->string('currency', 3)->default('AED');
            $table->boolean('no_transfer_allowed')->default(false);
            $table->boolean('shared_available')->default(true);
            $table->boolean('private_available')->default(false);
            $table->string('default_direction')->default('two_way');
            $table->string('shared_transfer_pricing')->default('included');
            $table->decimal('shared_transfer_price', 14, 2)->default(0);
            $table->integer('duration_minutes')->default(0);
            $table->string('opening_time')->nullable();
            $table->string('closing_time')->nullable();
            $table->string('operating_hours')->nullable();
            $table->string('validity')->nullable();
            $table->json('available_days')->nullable();
            $table->text('pickup_rules')->nullable();
            $table->text('drop_rules')->nullable();
            $table->foreignId('supplier_id')->nullable()->constrained('suppliers')->nullOnDelete();
            $table->boolean('requires_ticket')->default(false);
            $table->boolean('allow_over_capacity')->default(false);
            $table->text('notes')->nullable();
            $table->text('terms')->nullable();
            $table->timestamps();
        });

        Schema::create('tour_options', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tour_id')->constrained('tours')->cascadeOnDelete();
            $table->string('name');
            $table->text('description')->nullable();
            $table->string('pricing_method')->default('per_person');
            $table->decimal('adult_price', 14, 2)->default(0);
            $table->decimal('child_price', 14, 2)->default(0);
            $table->decimal('infant_price', 14, 2)->default(0);
            $table->decimal('group_price', 14, 2)->default(0);
            $table->decimal('min_adult_price', 14, 2)->nullable();
            $table->decimal('min_child_price', 14, 2)->nullable();
            $table->decimal('min_infant_price', 14, 2)->nullable();
            $table->decimal('min_group_price', 14, 2)->nullable();
            $table->boolean('adult_allowed')->default(true);
            $table->boolean('child_allowed')->default(true);
            $table->boolean('infant_allowed')->default(true);
            $table->string('ticket_type')->nullable();
            $table->string('ticket_category')->nullable();
            $table->boolean('active')->default(true);
            $table->integer('sort')->default(0);
            $table->timestamps();
        });

        Schema::create('addons', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tour_id')->constrained('tours')->cascadeOnDelete();
            $table->string('name');
            $table->string('pricing_method')->default('per_unit');
            $table->decimal('price', 14, 2)->default(0);
            $table->decimal('min_price', 14, 2)->nullable();
            $table->text('description')->nullable();
            $table->boolean('active')->default(true);
            $table->timestamps();
        });

        Schema::create('pickup_time_slots', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tour_id')->constrained('tours')->cascadeOnDelete();
            $table->string('pickup_start', 10);
            $table->string('pickup_end', 10);
            $table->string('drop_start', 10)->nullable();
            $table->string('drop_end', 10)->nullable();
            $table->boolean('active')->default(true);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('pickup_time_slots');
        Schema::dropIfExists('addons');
        Schema::dropIfExists('tour_options');
        Schema::dropIfExists('tours');
        Schema::dropIfExists('vehicles');
        Schema::dropIfExists('suppliers');
    }
};
