<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('payments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('booking_id')->constrained('bookings')->cascadeOnDelete();
            $table->string('method'); // cash | card
            $table->string('currency', 3);
            $table->decimal('amount', 14, 2);
            $table->decimal('exchange_rate', 14, 6)->default(1);
            $table->decimal('base_amount', 14, 2);
            $table->string('reference')->nullable();
            $table->string('provider')->nullable();
            $table->string('card_type')->nullable();
            $table->string('status')->default('active');
            $table->foreignId('user_id')->constrained('users');
            $table->timestamp('paid_at')->useCurrent();
            $table->timestamps();
        });

        Schema::create('counters', function (Blueprint $table) {
            $table->string('key')->primary();
            $table->unsignedBigInteger('value')->default(0);
            $table->timestamps();
        });

        Schema::create('audit_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('entity_type');
            $table->unsignedBigInteger('entity_id')->nullable();
            $table->string('action');
            $table->json('details')->nullable();
            $table->timestamps();
        });

        Schema::create('attendance', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users');
            $table->date('date');
            $table->string('expected_in')->nullable();
            $table->string('expected_out')->nullable();
            $table->string('actual_in')->nullable();
            $table->string('actual_out')->nullable();
            $table->integer('late_minutes')->default(0);
            $table->decimal('late_fine', 14, 2)->default(0);
            $table->unique(['user_id', 'date']);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('attendance');
        Schema::dropIfExists('audit_logs');
        Schema::dropIfExists('counters');
        Schema::dropIfExists('payments');
    }
};
