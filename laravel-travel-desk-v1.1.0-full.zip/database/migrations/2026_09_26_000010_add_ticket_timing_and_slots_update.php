<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run database update for existing MySQL installations.
     * Safely checks column existence so it can run repeatedly without error.
     */
    public function up(): void
    {
        if (Schema::hasTable('tours') && !Schema::hasColumn('tours', 'ticket_timing_type')) {
            Schema::table('tours', function (Blueprint $table) {
                $table->string('ticket_timing_type')->default('time_slotted')->after('product_type');
            });
        }

        if (Schema::hasTable('booking_items')) {
            Schema::table('booking_items', function (Blueprint $table) {
                if (!Schema::hasColumn('booking_items', 'ticket_timing_type')) {
                    $table->string('ticket_timing_type')->nullable()->after('drop_location');
                }
                if (!Schema::hasColumn('booking_items', 'ticket_time_slot')) {
                    $table->string('ticket_time_slot')->nullable()->after('ticket_timing_type');
                }
            });
        }
    }

    public function down(): void
    {
        // Safe additive migration; no rollback needed during live upgrades
    }
};
