<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('customers', function (Blueprint $table) {
            $table->id();
            $table->string('title')->default('Mr');
            $table->string('name');
            $table->string('hotel')->nullable();
            $table->string('room_number')->nullable();
            $table->string('phone')->nullable()->index();
            $table->json('contacts')->nullable();
            $table->string('email')->nullable();
            $table->text('notes')->nullable();
            $table->timestamps();
        });

        Schema::create('bookings', function (Blueprint $table) {
            $table->id();
            $table->string('receipt_number')->unique();
            $table->foreignId('customer_id')->constrained('customers');
            $table->unsignedBigInteger('travel_desk_id')->nullable();
            $table->string('travel_desk_name')->nullable();
            $table->foreignId('sales_person_id')->nullable()->constrained('users');
            $table->foreignId('created_by_id')->constrained('users');
            $table->string('status')->default('confirmed');
            $table->string('payment_status')->default('unpaid');
            $table->string('base_currency', 3)->default('AED');
            $table->decimal('standard_total', 14, 2)->default(0);
            $table->decimal('discount_total', 14, 2)->default(0);
            $table->decimal('total_amount', 14, 2)->default(0);
            $table->decimal('paid_amount', 14, 2)->default(0);
            $table->decimal('refunded_amount', 14, 2)->default(0);
            $table->decimal('balance_due', 14, 2)->default(0);
            $table->string('balance_collection')->default('travel_desk');
            $table->text('terms_override')->nullable();
            $table->text('customer_signature')->nullable();
            $table->text('agent_signature')->nullable();
            $table->text('notes')->nullable();
            $table->timestamp('issued_at')->useCurrent();
            $table->timestamp('last_emailed_at')->nullable();
            $table->timestamps();
        });

        Schema::create('booking_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('booking_id')->constrained('bookings')->cascadeOnDelete();
            $table->foreignId('tour_id')->constrained('tours');
            $table->foreignId('option_id')->nullable()->constrained('tour_options')->nullOnDelete();
            $table->string('tour_code')->unique();
            $table->string('tour_name');
            $table->string('option_name')->nullable();
            $table->string('product_type');
            $table->date('tour_date');
            $table->integer('adults')->default(0);
            $table->integer('children')->default(0);
            $table->integer('infants')->default(0);
            $table->string('transfer_type')->default('none');
            $table->string('transfer_direction')->nullable();
            $table->string('transfer_pricing')->nullable();
            $table->unsignedBigInteger('vehicle_id')->nullable();
            $table->string('vehicle_name')->nullable();
            $table->integer('vehicle_count')->default(0);
            $table->string('pickup_time')->nullable();
            $table->string('drop_time')->nullable();
            $table->string('pickup_location')->nullable();
            $table->string('drop_location')->nullable();
            $table->string('ticket_timing_type')->nullable(); // time_slotted | anytime
            $table->string('ticket_time_slot')->nullable(); // Entered slot e.g. 10:30, 16:30 Prime
            $table->json('breakdown')->nullable();
            $table->decimal('sold_adult_price', 14, 2)->nullable();
            $table->decimal('sold_child_price', 14, 2)->nullable();
            $table->decimal('sold_infant_price', 14, 2)->nullable();
            $table->decimal('min_total', 14, 2)->nullable();
            $table->foreignId('supplier_id')->nullable()->constrained('suppliers')->nullOnDelete();
            $table->decimal('supplier_cost', 14, 2)->default(0);
            $table->decimal('standard_price', 14, 2)->default(0);
            $table->decimal('discount', 14, 2)->default(0);
            $table->decimal('agreed_price', 14, 2)->nullable();
            $table->decimal('total', 14, 2)->default(0);
            $table->string('status')->default('active');
            $table->text('notes')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('booking_items');
        Schema::dropIfExists('bookings');
        Schema::dropIfExists('customers');
    }
};
