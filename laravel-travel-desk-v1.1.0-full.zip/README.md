# Luxury Attractions Tourism – Laravel Travel Desk System

Web-based offline-first travel-desk booking, receipt, payment, tour, supplier and staff management system built on **Laravel 11 & MySQL**.

### Features:
- Multi-currency booking engine (AED base, USD, EUR, GBP)
- Time-slotted tickets (Burj Khalifa with exact slot entry & prime hours)
- Flexible anytime admission tickets (Ski Dubai with all-day entry)
- Tours with shared, private and custom vehicle transfers
- Automatic receipt numbers and tour codes (`LA-YYYY-SEQ` format)
- Change calculation, split payments (cash/card), refunds and voids
- Thermal & A4 printable receipts with barcodes
- WhatsApp/Email Copy-Text generation
- Supplier price lists, auto-assignment, and ledger
- Staff check-in attendance, late fines and payroll
- One-click cPanel database updates under **Settings → System**

### Quick Install (cPanel):
1. Create a MySQL database and user in cPanel.
2. Upload and extract `laravel-travel-desk-v1.1.0-full.zip` to your subdomain folder (e.g. `traveldesk`).
3. Set your document root to `traveldesk/public`.
4. Copy `.env.example` to `.env` and enter your MySQL database credentials.
5. Open your site in the browser to sign in:
   - Admin: `admin` / `admin123`
   - Agent: `agent` / `agent123`
