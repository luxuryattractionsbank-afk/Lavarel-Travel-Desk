<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::get('/health', function () {
    return response()->json(['ok' => true, 'system' => 'Laravel Travel Desk', 'version' => config('app.version')]);
});
