<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use Illuminate\Http\Request;

class ReceiptController extends Controller
{
    public function show($id, Request $request)
    {
        $booking = Booking::with(['customer', 'items', 'payments', 'salesPerson'])->findOrFail($id);
        $layout = $request->query('layout', 'a4');
        return view('receipt.show', compact('booking', 'layout'));
    }
}
