<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;

class SystemController extends Controller
{
    public function index()
    {
        $version = config('app.version', '1.1.0');
        $migrations = DB::table('migrations')->count();
        return view('settings.system', compact('version', 'migrations'));
    }

    /**
     * Executes the "Run database update" button as instructed in the Upgrade Guide.
     */
    public function runDatabaseUpdate(Request $request)
    {
        try {
            Artisan::call('migrate', ['--force' => true]);
            $output = Artisan::output();
            return redirect()->route('settings.system')
                ->with('success', "Database update completed successfully! Log: " . $output);
        } catch (\Exception $e) {
            return redirect()->route('settings.system')
                ->with('error', "Database update failed: " . $e->getMessage());
        }
    }
}
