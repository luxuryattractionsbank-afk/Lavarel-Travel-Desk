<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use App\Models\BookingItem;
use App\Models\Customer;
use App\Models\Payment;
use App\Models\Tour;
use App\Models\Counter;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class BookingController extends Controller
{
    public function index(Request $request)
    {
        $query = Booking::with(['customer', 'items', 'salesPerson'])->latest();

        if ($request->filled('q')) {
            $q = $request->q;
            $query->where(function($b) use ($q) {
                $b->where('receipt_number', 'like', "%{$q}%")
                  ->orWhereHas('customer', function($c) use ($q) {
                      $c->where('name', 'like', "%{$q}%")
                        ->orWhere('phone', 'like', "%{$q}%")
                        ->orWhere('hotel', 'like', "%{$q}%");
                  });
            });
        }

        $bookings = $query->paginate(25);
        return view('bookings.index', compact('bookings'));
    }

    public function create()
    {
        $tours = Tour::with(['options', 'addons', 'pickupSlots'])->where('active', true)->get();
        return view('bookings.create', compact('tours'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'customer_name' => 'required|string|max:150',
            'phone' => 'required|string|max:50',
            'hotel' => 'nullable|string|max:150',
            'room' => 'nullable|string|max:30',
            'tour_id' => 'required|exists:tours,id',
            'tour_date' => 'required|date',
            'adults' => 'required|integer|min:0',
            'children' => 'nullable|integer|min:0',
            'amount_paid' => 'nullable|numeric|min:0',
            'payment_method' => 'nullable|in:cash,card',
            'ticket_time_slot' => 'nullable|string|max:80',
        ]);

        return DB::transaction(function() use ($request, $validated) {
            $customer = Customer::create([
                'title' => $request->title ?? 'Mr',
                'name' => $validated['customer_name'],
                'phone' => $validated['phone'],
                'hotel' => $validated['hotel'] ?? null,
                'room_number' => $validated['room'] ?? null,
                'contacts' => [['number' => $validated['phone'], 'channels' => ['whatsapp', 'call'], 'label' => 'Primary']],
            ]);

            // Receipt numbering
            $year = date('Y');
            $counterKey = "receipt:{$year}";
            $counter = Counter::firstOrCreate(['key' => $counterKey], ['value' => 10]);
            $counter->increment('value');
            $receiptNo = sprintf("LA-%s-%05d", $year, $counter->value);

            $tour = Tour::with('options')->findOrFail($validated['tour_id']);
            $option = $tour->options()->first();

            $adultPrice = $option ? (float)$option->adult_price : 150;
            $childPrice = $option ? (float)$option->child_price : 100;
            $adults = (int)$validated['adults'];
            $children = (int)($validated['children'] ?? 0);
            $total = ($adults * $adultPrice) + ($children * $childPrice);

            $paid = (float)($validated['amount_paid'] ?? 0);
            $balance = max(0, $total - $paid);
            $paymentStatus = $paid >= $total ? 'paid' : ($paid > 0 ? 'partially_paid' : 'unpaid');

            $booking = Booking::create([
                'receipt_number' => $receiptNo,
                'customer_id' => $customer->id,
                'sales_person_id' => Auth::id(),
                'created_by_id' => Auth::id(),
                'status' => 'confirmed',
                'payment_status' => $paymentStatus,
                'total_amount' => $total,
                'paid_amount' => $paid,
                'balance_due' => $balance,
                'balance_collection' => 'travel_desk',
            ]);

            // Tour code
            $tourCounter = Counter::firstOrCreate(['key' => "tour:{$tour->code_prefix}"], ['value' => 5]);
            $tourCounter->increment('value');
            $tourCode = sprintf("%s%03d", strtoupper($tour->code_prefix), $tourCounter->value);

            // Ticket timing handling
            $ticketTimeSlot = $tour->product_type === 'ticket' 
                ? ($tour->ticket_timing_type === 'anytime' 
                    ? 'Anytime on selected date (Flexible entry)' 
                    : ($request->ticket_time_slot ?: '10:30 Standard Slot'))
                : null;

            BookingItem::create([
                'booking_id' => $booking->id,
                'tour_id' => $tour->id,
                'option_id' => $option ? $option->id : null,
                'tour_code' => $tourCode,
                'tour_name' => $tour->name,
                'option_name' => $option ? $option->name : 'Standard',
                'product_type' => $tour->product_type,
                'tour_date' => $validated['tour_date'],
                'adults' => $adults,
                'children' => $children,
                'pickup_location' => $validated['hotel'] ?? 'Desk Pickup',
                'pickup_time' => $ticketTimeSlot,
                'ticket_timing_type' => $tour->ticket_timing_type,
                'ticket_time_slot' => $ticketTimeSlot,
                'standard_price' => $total,
                'total' => $total,
                'status' => 'active',
            ]);

            if ($paid > 0) {
                Payment::create([
                    'booking_id' => $booking->id,
                    'user_id' => Auth::id(),
                    'method' => $validated['payment_method'] ?? 'cash',
                    'currency' => 'AED',
                    'amount' => $paid,
                    'base_amount' => $paid,
                    'reference' => $request->reference ?? 'CASH-' . time(),
                    'status' => 'active',
                ]);
            }

            return redirect()->route('bookings.show', $booking->id)
                ->with('success', "Booking {$receiptNo} created successfully!");
        });
    }

    public function show($id)
    {
        $booking = Booking::with(['customer', 'items.tour', 'payments'])->findOrFail($id);
        return view('bookings.show', compact('booking'));
    }
}
