<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use App\Models\BookingItem;
use App\Models\Payment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public function index()
    {
        $today = now()->format('Y-m-d');
        $todayBookingsCount = Booking::whereDate('created_at', $today)->count();
        $todaySalesTotal = Booking::whereDate('created_at', $today)->sum('total_amount');
        $outstandingTotal = Booking::where('balance_due', '>', 0)->sum('balance_due');
        
        $upcomingItems = BookingItem::with(['booking.customer'])
            ->where('tour_date', '>=', $today)
            ->where('status', 'active')
            ->orderBy('tour_date')
            ->limit(8)
            ->get();

        $recentBookings = Booking::with('customer')
            ->latest()
            ->limit(8)
            ->get();

        return view('dashboard', compact(
            'todayBookingsCount', 'todaySalesTotal', 'outstandingTotal',
            'upcomingItems', 'recentBookings', 'today'
        ));
    }
}
