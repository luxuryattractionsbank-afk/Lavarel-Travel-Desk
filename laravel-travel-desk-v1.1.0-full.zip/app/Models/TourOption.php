<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TourOption extends Model
{
    protected $guarded = [];

    protected $casts = [
        'adult_allowed' => 'boolean',
        'child_allowed' => 'boolean',
        'infant_allowed' => 'boolean',
        'active' => 'boolean',
    ];

    public function tour()
    {
        return $this->belongsTo(Tour::class);
    }
}
