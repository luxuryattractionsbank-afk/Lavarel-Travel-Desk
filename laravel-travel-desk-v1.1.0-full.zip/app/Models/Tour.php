<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Tour extends Model
{
    protected $guarded = [];

    protected $casts = [
        'available_days' => 'array',
        'active' => 'boolean',
        'no_transfer_allowed' => 'boolean',
        'shared_available' => 'boolean',
        'private_available' => 'boolean',
        'requires_ticket' => 'boolean',
    ];

    public function options()
    {
        return $this->hasMany(TourOption::class)->orderBy('sort');
    }

    public function addons()
    {
        return $this->hasMany(Addon::class);
    }

    public function pickupSlots()
    {
        return $this->hasMany(PickupSlot::class);
    }

    public function supplier()
    {
        return $this->belongsTo(Supplier::class);
    }
}
