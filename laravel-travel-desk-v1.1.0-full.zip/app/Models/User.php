<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use Notifiable;

    protected $guarded = [];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    public function role()
    {
        return $this->belongsTo(Role::class);
    }

    public function hasPermission(string $perm): bool
    {
        if ($this->role && (in_array('*', $this->role->permissions ?? []) || in_array($perm, $this->role->permissions ?? []))) {
            return true;
        }
        return false;
    }
}
