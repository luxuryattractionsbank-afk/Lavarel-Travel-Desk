<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BookingItem extends Model
{
    protected $guarded = [];

    protected $casts = [
        'breakdown' => 'array',
        'tour_date' => 'date',
    ];

    public function booking()
    {
        return $this->belongsTo(Booking::class);
    }

    public function tour()
    {
        return $this->belongsTo(Tour::class);
    }

    public function option()
    {
        return $this->belongsTo(TourOption::class, 'option_id');
    }

    public function supplier()
    {
        return $this->belongsTo(Supplier::class);
    }
}
