@extends('layouts.app')

@section('content')
<div style="max-width: 800px; margin: 0 auto; display: flex; flex-direction: column; gap: 20px;">
    <h1 style="font-size: 22px; font-weight: 800; margin: 0;">Settings → System</h1>

    <div class="card space-y-4">
        <h3 style="margin-top: 0; font-size: 16px; font-weight: 700;">System Status & Database Updates</h3>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px;">
            <div style="background: #f8fafc; padding: 14px; border-radius: 8px; border: 1px solid #e2e8f0;">
                <div class="lbl">Installed Version</div>
                <div style="font-size: 20px; font-weight: 800; color: #0f1a33;">v{{ $version }}</div>
            </div>
            <div style="background: #f8fafc; padding: 14px; border-radius: 8px; border: 1px solid #e2e8f0;">
                <div class="lbl">Applied Migrations</div>
                <div style="font-size: 20px; font-weight: 800; color: #065f46;">{{ $migrations }} migrations</div>
            </div>
        </div>

        <div style="background: #f1f5f9; padding: 16px; border-radius: 8px; border-left: 4px solid #17223d;">
            <h4 style="margin: 0 0 6px 0; font-size: 14px;">Upgrade Guide Instructions:</h4>
            <p style="font-size: 13px; color: #475569; margin: 0;">
                After uploading the update zip and extracting it into <code>traveldesk</code>, click the button below to apply only new database changes. Existing records (bookings, payments, staff) are always preserved.
            </p>
        </div>

        <form action="{{ route('settings.system.update') }}" method="POST" style="margin-top: 16px;">
            @csrf
            <button type="submit" class="btn-primary" style="padding: 12px 24px; font-size: 14px;">
                ⚡ Run database update
            </button>
        </form>
    </div>
</div>
@endsection
