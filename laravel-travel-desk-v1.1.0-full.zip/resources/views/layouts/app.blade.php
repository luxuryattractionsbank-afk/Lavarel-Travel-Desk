<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Luxury Attractions Tourism – Travel Desk (Laravel)</title>
    <link rel="stylesheet" href="/css/app.css">
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background-color: #f1f5f9; color: #0f172a; margin: 0; }
        .btn-primary { background: #17223d; color: white; padding: 8px 16px; border-radius: 8px; font-weight: 600; text-decoration: none; display: inline-flex; align-items: center; justify-content: center; border: none; cursor: pointer; }
        .btn-primary:hover { background: #22305a; }
        .btn-gold { background: #c9a24a; color: #0f1a33; padding: 8px 16px; border-radius: 8px; font-weight: 700; text-decoration: none; display: inline-flex; align-items: center; justify-content: center; border: none; cursor: pointer; }
        .btn-gold:hover { background: #e3c26b; }
        .btn-outline { background: white; color: #1e293b; border: 1px solid #cbd5e1; padding: 8px 14px; border-radius: 8px; font-weight: 600; text-decoration: none; display: inline-flex; align-items: center; cursor: pointer; }
        .card { background: white; border: 1px solid #e2e8f0; border-radius: 12px; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
        .input { width: 100%; min-height: 40px; padding: 8px 12px; border-radius: 8px; border: 1px solid #cbd5e1; box-sizing: border-box; outline: none; font-size: 14px; }
        .lbl { font-size: 12px; font-weight: 700; text-transform: uppercase; color: #475569; margin-bottom: 4px; display: block; }
        .badge { display: inline-flex; align-items: center; padding: 2px 8px; border-radius: 9999px; font-size: 11px; font-weight: 700; }
    </style>
</head>
<body class="bg-slate-100 text-slate-900">
    <div style="display: flex; min-height: 100vh;">
        <!-- Sidebar -->
        <aside style="width: 256px; background: #0f1a33; color: white; display: flex; flex-direction: column;">
            <div style="padding: 20px; border-bottom: 1px solid #22305a; display: flex; align-items: center; gap: 12px;">
                <div style="width: 36px; height: 36px; background: #c9a24a; color: #0f1a33; display: grid; place-items: center; font-weight: 900; border-radius: 8px;">LA</div>
                <div>
                    <div style="font-weight: 800; font-size: 14px;">Luxury Attractions</div>
                    <div style="font-size: 11px; color: #e3c26b;">Laravel + MySQL</div>
                </div>
            </div>
            <nav style="flex: 1; padding: 12px; display: flex; flex-direction: column; gap: 4px;">
                <a href="{{ route('dashboard') }}" style="display: flex; align-items: center; gap: 10px; padding: 10px 14px; border-radius: 8px; color: #cbd5e1; text-decoration: none; font-size: 14px; font-weight: 500;">🏠 Dashboard</a>
                <a href="{{ route('bookings.create') }}" style="display: flex; align-items: center; gap: 10px; padding: 10px 14px; border-radius: 8px; background: #c9a24a; color: #0f1a33; text-decoration: none; font-size: 14px; font-weight: 700;">➕ New Booking</a>
                <a href="{{ route('bookings.index') }}" style="display: flex; align-items: center; gap: 10px; padding: 10px 14px; border-radius: 8px; color: #cbd5e1; text-decoration: none; font-size: 14px; font-weight: 500;">🧾 Bookings & Receipts</a>
                <a href="{{ route('settings.system') }}" style="display: flex; align-items: center; gap: 10px; padding: 10px 14px; border-radius: 8px; color: #cbd5e1; text-decoration: none; font-size: 14px; font-weight: 500;">⚙️ System & Updates</a>
            </nav>
            <div style="padding: 16px; border-top: 1px solid #22305a; font-size: 12px; color: #94a3b8;">
                <div style="margin-bottom: 8px;">User: <b style="color: white;">{{ Auth::user()->display_name ?? 'Admin' }}</b></div>
                <form action="{{ route('logout') }}" method="POST">
                    @csrf
                    <button type="submit" style="background: none; border: 1px solid #334155; color: #cbd5e1; width: 100%; padding: 6px; border-radius: 6px; cursor: pointer; font-size: 11px;">Sign out</button>
                </form>
            </div>
        </aside>

        <!-- Main Content -->
        <div style="flex: 1; display: flex; flex-direction: column;">
            <header style="background: white; border-bottom: 1px solid #e2e8f0; padding: 12px 24px; display: flex; align-items: center; justify-content: space-between;">
                <div style="font-weight: 700; color: #1e293b;">Luxury Attractions Tourism · Travel Desk</div>
                <div style="display: flex; align-items: center; gap: 12px;">
                    <a href="{{ route('bookings.create') }}" class="btn-gold" style="padding: 6px 14px; font-size: 12px;">+ New Booking</a>
                </div>
            </header>
            <main style="padding: 24px; max-width: 1200px; margin: 0 auto; width: 100%; box-sizing: border-box;">
                @if(session('success'))
                    <div style="background: #ecfdf5; border: 1px solid #a7f3d0; color: #065f46; padding: 12px 16px; border-radius: 8px; margin-bottom: 16px; font-size: 14px;">
                        ✓ {{ session('success') }}
                    </div>
                @endif
                @if(session('error'))
                    <div style="background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; padding: 12px 16px; border-radius: 8px; margin-bottom: 16px; font-size: 14px;">
                        ✕ {{ session('error') }}
                    </div>
                @endif
                @yield('content')
            </main>
        </div>
    </div>
</body>
</html>
