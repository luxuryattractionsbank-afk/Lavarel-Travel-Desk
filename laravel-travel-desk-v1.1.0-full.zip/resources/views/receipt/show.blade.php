<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Receipt {{ $booking->receipt_number }} – Luxury Attractions Tourism</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif; margin: 0; padding: 20px; background: #e2e8f0; color: #0f172a; }
        .receipt-container { max-width: 800px; margin: 0 auto; background: white; padding: 32px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        .no-print { margin-bottom: 20px; text-align: center; }
        .btn { background: #17223d; color: white; border: none; padding: 8px 18px; border-radius: 6px; font-weight: 700; cursor: pointer; text-decoration: none; display: inline-block; }
        .btn-gold { background: #c9a24a; color: #0f1a33; }
        table { width: 100%; border-collapse: collapse; margin-top: 16px; }
        th, td { padding: 8px 10px; text-align: left; }
        th { border-bottom: 2px solid #0f1a33; font-size: 12px; text-transform: uppercase; }
        td { border-bottom: 1px solid #e2e8f0; font-size: 13px; }
        @media print {
            body { background: white; padding: 0; }
            .no-print { display: none !important; }
            .receipt-container { box-shadow: none; padding: 0; max-width: 100%; }
        }
    </style>
</head>
<body>
    <div class="no-print">
        <button onclick="window.print()" class="btn btn-gold">🖨️ Print Receipt</button>
        <a href="{{ route('bookings.show', $booking->id) }}" class="btn">← Back to Booking</a>
    </div>

    <div class="receipt-container">
        <!-- Header -->
        <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 3px solid #c9a24a; padding-bottom: 16px;">
            <div>
                <h1 style="margin: 0; font-size: 24px; color: #0f1a33;">Luxury Attractions Tourism</h1>
                <div style="font-size: 13px; color: #64748b; margin-top: 4px;">Official Travel Desk Booking Receipt</div>
                <div style="font-size: 12px; color: #64748b;">+971 52 888 5145 · salesdesk@luxuryattractions.com</div>
            </div>
            <div style="text-align: right;">
                <div style="font-size: 18px; font-weight: 800; font-family: monospace;">{{ $booking->receipt_number }}</div>
                <div style="font-size: 12px; color: #64748b;">Date: {{ $booking->created_at->format('d M Y H:i') }}</div>
            </div>
        </div>

        <!-- Customer info -->
        <div style="margin-top: 16px; background: #f8fafc; padding: 12px; border-radius: 6px; font-size: 13px; display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
            <div><b>Customer:</b> {{ $booking->customer->title }} {{ $booking->customer->name }}</div>
            <div><b>Hotel / Room:</b> {{ $booking->customer->hotel ?? '-' }} / {{ $booking->customer->room_number ?? '-' }}</div>
            <div><b>Mobile:</b> {{ $booking->customer->phone }}</div>
            <div><b>Desk:</b> Atlantis The Palm Desk</div>
        </div>

        <!-- Items Table -->
        <table>
            <thead>
                <tr>
                    <th>Item / Description</th>
                    <th>Date</th>
                    <th>Pax</th>
                    <th>Timing / Entry Slot</th>
                    <th style="text-align: right;">Amount</th>
                </tr>
            </thead>
            <tbody>
                @foreach($booking->items as $item)
                <tr>
                    <td>
                        <b>{{ $item->tour_name }}</b>
                        <div style="font-size: 11px; color: #64748b;">{{ $item->option_name }} ({{ $item->tour_code }})</div>
                    </td>
                    <td>{{ $item->tour_date->format('d M Y') }}</td>
                    <td>{{ $item->adults }}A / {{ $item->children }}C</td>
                    <td>
                        @if($item->product_type === 'ticket')
                            @if($item->ticket_timing_type === 'anytime' || str_contains(strtolower($item->tour_name), 'ski'))
                                <span style="color: #065f46; font-weight: 700;">🎟️ Valid any time on date</span>
                            @else
                                <span style="color: #3730a3; font-weight: 700;">⏱️ Slot: {{ $item->ticket_time_slot ?: 'Standard' }}</span>
                            @endif
                        @else
                            {{ $item->pickup_time ?: '-' }}
                        @endif
                    </td>
                    <td style="text-align: right; font-weight: 700;">AED {{ number_format($item->total, 2) }}</td>
                </tr>
                @endforeach
            </tbody>
        </table>

        <!-- Totals -->
        <div style="margin-top: 20px; display: flex; justify-content: flex-end;">
            <div style="width: 260px; font-size: 14px;">
                <div style="display: flex; justify-content: space-between; padding: 4px 0;">
                    <span>Total Amount:</span>
                    <b>AED {{ number_format($booking->total_amount, 2) }}</b>
                </div>
                <div style="display: flex; justify-content: space-between; padding: 4px 0; color: #065f46;">
                    <span>Amount Paid:</span>
                    <b>AED {{ number_format($booking->paid_amount, 2) }}</b>
                </div>
                <div style="display: flex; justify-content: space-between; padding: 6px 0; border-top: 2px solid #0f1a33; font-size: 16px; font-weight: 800; color: #991b1b;">
                    <span>Balance Due:</span>
                    <span>AED {{ number_format($booking->balance_due, 2) }}</span>
                </div>
            </div>
        </div>

        <div style="margin-top: 32px; border-top: 1px dashed #cbd5e1; padding-top: 12px; font-size: 11px; text-align: center; color: #64748b;">
            Thank you for booking with Luxury Attractions Tourism. Computer generated official receipt.
        </div>
    </div>
</body>
</html>
