<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login – Luxury Attractions Tourism (Laravel)</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: linear-gradient(135deg, #0f1a33, #17223d, #22305a); min-height: 100vh; display: grid; place-items: center; margin: 0; color: #0f172a; }
        .card { background: white; border-radius: 16px; padding: 32px; width: 100%; max-width: 400px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.3); }
        .input { width: 100%; min-height: 44px; padding: 8px 12px; border-radius: 8px; border: 1px solid #cbd5e1; box-sizing: border-box; margin-bottom: 16px; font-size: 14px; }
        .btn-gold { background: #c9a24a; color: #0f1a33; width: 100%; min-height: 44px; border-radius: 8px; font-weight: 700; border: none; cursor: pointer; font-size: 15px; }
        .lbl { font-size: 12px; font-weight: 700; text-transform: uppercase; color: #475569; margin-bottom: 6px; display: block; }
    </style>
</head>
<body>
    <div class="card">
        <div style="text-align: center; margin-bottom: 24px;">
            <div style="width: 56px; height: 56px; background: #c9a24a; color: #0f1a33; display: grid; place-items: center; font-size: 24px; font-weight: 900; border-radius: 14px; margin: 0 auto 12px auto;">LA</div>
            <h2 style="margin: 0; font-size: 20px; color: #0f1a33;">Luxury Attractions Tourism</h2>
            <div style="font-size: 12px; color: #c9a24a; font-weight: 600;">Laravel 11 & MySQL Travel Desk</div>
        </div>

        @if($errors->any())
            <div style="background: #fef2f2; color: #991b1b; padding: 10px; border-radius: 6px; font-size: 13px; margin-bottom: 16px;">
                {{ $errors->first() }}
            </div>
        @endif

        <form action="{{ route('login') }}" method="POST">
            @csrf
            <div>
                <label class="lbl">Username or Email</label>
                <input name="username" class="input" value="admin" required autofocus>
            </div>
            <div>
                <label class="lbl">Password</label>
                <input type="password" name="password" class="input" value="admin123" required>
            </div>
            <button type="submit" class="btn-gold">Sign In</button>
        </form>

        <div style="margin-top: 20px; border-top: 1px solid #e2e8f0; padding-top: 16px; text-align: center; font-size: 12px; color: #64748b;">
            Default Credentials: <b>admin</b> / <b>admin123</b>
        </div>
    </div>
</body>
</html>
