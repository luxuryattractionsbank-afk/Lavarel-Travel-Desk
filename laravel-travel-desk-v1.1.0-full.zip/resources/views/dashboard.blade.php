@extends('layouts.app')

@section('content')
<div style="display: flex; flex-direction: column; gap: 20px;">
    <div style="display: flex; align-items: center; justify-content: space-between;">
        <h1 style="font-size: 24px; font-weight: 800; color: #0f172a; margin: 0;">Dashboard</h1>
        <div style="font-size: 13px; color: #64748b;">Date: <b>{{ $today }}</b></div>
    </div>

    <!-- Quick Stats -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px;">
        <div class="card" style="border-left: 4px solid #c9a24a;">
            <div class="lbl">Today's Bookings</div>
            <div style="font-size: 28px; font-weight: 800; color: #0f1a33;">{{ $todayBookingsCount }}</div>
        </div>
        <div class="card" style="border-left: 4px solid #10b981;">
            <div class="lbl">Today's Sales (AED)</div>
            <div style="font-size: 28px; font-weight: 800; color: #065f46;">AED {{ number_format($todaySalesTotal, 2) }}</div>
        </div>
        <div class="card" style="border-left: 4px solid #ef4444;">
            <div class="lbl">Outstanding Balance</div>
            <div style="font-size: 28px; font-weight: 800; color: #991b1b;">AED {{ number_format($outstandingTotal, 2) }}</div>
        </div>
    </div>

    <!-- Upcoming Tours & Tickets -->
    <div class="card">
        <h3 style="margin-top: 0; font-size: 16px; font-weight: 700;">Upcoming Tours & Tickets (Today & Ahead)</h3>
        <table style="width: 100%; border-collapse: collapse; font-size: 13px; text-align: left;">
            <thead>
                <tr style="border-bottom: 2px solid #e2e8f0; color: #64748b;">
                    <th style="padding: 10px;">Date</th>
                    <th style="padding: 10px;">Tour / Ticket</th>
                    <th style="padding: 10px;">Customer</th>
                    <th style="padding: 10px;">Entry Slot / Time</th>
                    <th style="padding: 10px;">Pax</th>
                    <th style="padding: 10px;">Receipt</th>
                </tr>
            </thead>
            <tbody>
                @forelse($upcomingItems as $item)
                <tr style="border-bottom: 1px solid #f1f5f9;">
                    <td style="padding: 10px; font-weight: 600;">{{ $item->tour_date->format('d M Y') }}</td>
                    <td style="padding: 10px;">
                        <b>{{ $item->tour_name }}</b>
                        <div style="font-size: 11px; color: #64748b;">{{ $item->option_name }}</div>
                    </td>
                    <td style="padding: 10px;">{{ $item->booking->customer->name ?? '-' }}</td>
                    <td style="padding: 10px;">
                        @if($item->product_type === 'ticket')
                            @if($item->ticket_timing_type === 'anytime' || str_contains(strtolower($item->tour_name), 'ski'))
                                <span class="badge" style="background: #d1fae5; color: #065f46;">🎟️ Anytime on date</span>
                            @else
                                <span class="badge" style="background: #e0e7ff; color: #3730a3;">⏱️ {{ $item->ticket_time_slot ?: 'Time Slot' }}</span>
                            @endif
                        @else
                            {{ $item->pickup_time ?: '-' }}
                        @endif
                    </td>
                    <td style="padding: 10px;">{{ $item->adults }}A / {{ $item->children }}C</td>
                    <td style="padding: 10px;">
                        <a href="{{ route('bookings.show', $item->booking_id) }}" style="color: #17223d; font-family: monospace; font-weight: 700;">
                            {{ $item->booking->receipt_number }}
                        </a>
                    </td>
                </tr>
                @empty
                <tr><td colspan="6" style="padding: 20px; text-align: center; color: #94a3b8;">No upcoming tours found.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
