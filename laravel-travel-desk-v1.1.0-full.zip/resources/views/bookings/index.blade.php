@extends('layouts.app')

@section('content')
<div style="display: flex; flex-direction: column; gap: 16px;">
    <div style="display: flex; align-items: center; justify-content: space-between;">
        <h1 style="font-size: 22px; font-weight: 800; margin: 0;">Bookings & Receipts</h1>
        <a href="{{ route('bookings.create') }}" class="btn-gold">+ New Booking</a>
    </div>

    <div class="card">
        <form method="GET" action="{{ route('bookings.index') }}" style="display: flex; gap: 10px; margin-bottom: 16px;">
            <input name="q" value="{{ request('q') }}" class="input" placeholder="Search receipt number, guest name, phone, hotel...">
            <button type="submit" class="btn-outline">Search</button>
        </form>

        <table style="width: 100%; border-collapse: collapse; font-size: 13px; text-align: left;">
            <thead>
                <tr style="border-bottom: 2px solid #e2e8f0; color: #64748b;">
                    <th style="padding: 10px;">Receipt No.</th>
                    <th style="padding: 10px;">Guest</th>
                    <th style="padding: 10px;">Items</th>
                    <th style="padding: 10px;">Total (AED)</th>
                    <th style="padding: 10px;">Paid</th>
                    <th style="padding: 10px;">Balance</th>
                    <th style="padding: 10px;">Status</th>
                    <th style="padding: 10px;">Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($bookings as $b)
                <tr style="border-bottom: 1px solid #f1f5f9;">
                    <td style="padding: 10px; font-family: monospace; font-weight: 700;">
                        <a href="{{ route('bookings.show', $b->id) }}" style="color: #17223d;">{{ $b->receipt_number }}</a>
                    </td>
                    <td style="padding: 10px;">
                        <b>{{ $b->customer->name ?? '-' }}</b>
                        <div style="font-size: 11px; color: #64748b;">{{ $b->customer->hotel ?? '' }}</div>
                    </td>
                    <td style="padding: 10px;">
                        @foreach($b->items as $it)
                        <div style="font-size: 12px;">
                            • {{ $it->tour_name }} ({{ $it->tour_code }})
                            @if($it->ticket_time_slot)
                            <span style="color: #4338ca; font-size: 11px;">[{{ $it->ticket_time_slot }}]</span>
                            @endif
                        </div>
                        @endforeach
                    </td>
                    <td style="padding: 10px; font-weight: 700;">{{ number_format($b->total_amount, 2) }}</td>
                    <td style="padding: 10px; color: #065f46;">{{ number_format($b->paid_amount, 2) }}</td>
                    <td style="padding: 10px; color: {{ $b->balance_due > 0 ? '#991b1b' : '#64748b' }}; font-weight: {{ $b->balance_due > 0 ? '700' : 'normal' }};">
                        {{ number_format($b->balance_due, 2) }}
                    </td>
                    <td style="padding: 10px;">
                        <span class="badge" style="background: {{ $b->payment_status === 'paid' ? '#d1fae5' : '#fee2e2' }}; color: {{ $b->payment_status === 'paid' ? '#065f46' : '#991b1b' }};">
                            {{ ucfirst($b->payment_status) }}
                        </span>
                    </td>
                    <td style="padding: 10px; display: flex; gap: 6px;">
                        <a href="{{ route('bookings.show', $b->id) }}" class="btn-outline" style="padding: 4px 8px; font-size: 11px;">View</a>
                        <a href="{{ route('receipt.show', $b->id) }}" target="_blank" class="btn-gold" style="padding: 4px 8px; font-size: 11px;">Print</a>
                    </td>
                </tr>
                @empty
                <tr><td colspan="8" style="padding: 20px; text-align: center; color: #94a3b8;">No bookings found.</td></tr>
                @endforelse
            </tbody>
        </table>

        <div style="margin-top: 16px;">
            {{ $bookings->links() }}
        </div>
    </div>
</div>
@endsection
