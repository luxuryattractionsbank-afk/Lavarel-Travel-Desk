@extends('layouts.app')

@section('content')
<div style="max-width: 900px; margin: 0 auto; display: flex; flex-direction: column; gap: 20px;">
    <div style="display: flex; align-items: center; justify-content: space-between;">
        <div>
            <h1 style="font-size: 22px; font-weight: 800; margin: 0;">Booking {{ $booking->receipt_number }}</h1>
            <div style="font-size: 13px; color: #64748b;">Created {{ $booking->created_at->format('d M Y, H:i') }}</div>
        </div>
        <div style="display: flex; gap: 8px;">
            <a href="{{ route('receipt.show', $booking->id) }}" target="_blank" class="btn-gold">🖨️ Print Receipt</a>
            <a href="{{ route('receipt.show', [$booking->id, 'layout' => 'thermal']) }}" target="_blank" class="btn-outline">Thermal Receipt</a>
        </div>
    </div>

    <!-- Customer Card -->
    <div class="card">
        <h3 style="margin-top: 0; font-size: 15px; font-weight: 700;">Customer Information</h3>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 12px; font-size: 13px;">
            <div><b>Name:</b> {{ $booking->customer->title }} {{ $booking->customer->name }}</div>
            <div><b>Phone / WhatsApp:</b> {{ $booking->customer->phone }}</div>
            <div><b>Hotel:</b> {{ $booking->customer->hotel ?? '-' }}</div>
            <div><b>Room:</b> {{ $booking->customer->room_number ?? '-' }}</div>
        </div>
    </div>

    <!-- Items -->
    @foreach($booking->items as $item)
    <div class="card" style="border-left: 4px solid #c9a24a;">
        <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px;">
            <div>
                <h3 style="margin: 0; font-size: 16px; font-weight: 700;">{{ $item->tour_name }} <span style="font-weight: 400; color: #64748b;">– {{ $item->option_name }}</span></h3>
                <div style="font-size: 12px; color: #64748b;">Date: {{ $item->tour_date->format('d M Y') }} · Pax: {{ $item->adults }} Adult, {{ $item->children }} Child</div>
            </div>
            <div style="text-align: right;">
                <div style="font-family: monospace; font-size: 16px; font-weight: 800; color: #c9a24a;">{{ $item->tour_code }}</div>
                <div style="font-size: 15px; font-weight: 700;">AED {{ number_format($item->total, 2) }}</div>
            </div>
        </div>

        @if($item->product_type === 'ticket')
            <div style="margin-top: 10px; padding: 10px; border-radius: 8px; {{ $item->ticket_timing_type === 'anytime' || str_contains(strtolower($item->tour_name), 'ski') ? 'background: #ecfdf5; border: 1px solid #a7f3d0; color: #065f46;' : 'background: #eef2ff; border: 1px solid #c7d2fe; color: #1e1b4b;' }}">
                @if($item->ticket_timing_type === 'anytime' || str_contains(strtolower($item->tour_name), 'ski'))
                    <b>🎟️ Admission:</b> Any time on selected date (Flexible All-Day Access during venue hours)
                @else
                    <b>⏱️ Ticket Entry Slot:</b> <span style="text-decoration: underline; font-weight: 800;">{{ $item->ticket_time_slot ?: 'Standard Slot' }}</span>
                @endif
            </div>
        @endif
    </div>
    @endforeach

    <!-- Payment Breakdown -->
    <div class="card" style="align-self: flex-end; width: 100%; max-width: 360px;">
        <table style="width: 100%; font-size: 14px;">
            <tr><td>Total Amount:</td><td style="text-align: right; font-weight: 700;">AED {{ number_format($booking->total_amount, 2) }}</td></tr>
            <tr><td>Paid:</td><td style="text-align: right; color: #065f46;">AED {{ number_format($booking->paid_amount, 2) }}</td></tr>
            <tr style="border-top: 1px solid #e2e8f0; font-size: 16px; font-weight: 800;">
                <td style="color: #991b1b;">Balance Due:</td>
                <td style="text-align: right; color: #991b1b;">AED {{ number_format($booking->balance_due, 2) }}</td>
            </tr>
        </table>
    </div>
</div>
@endsection
