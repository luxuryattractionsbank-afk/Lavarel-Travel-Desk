@extends('layouts.app')

@section('content')
<div style="max-width: 900px; margin: 0 auto;">
    <h1 style="font-size: 22px; font-weight: 800; margin-bottom: 16px;">New Booking</h1>

    <form action="{{ route('bookings.store') }}" method="POST" style="display: flex; flex-direction: column; gap: 20px;">
        @csrf

        <!-- Customer Card -->
        <div class="card">
            <h3 style="margin-top: 0; font-size: 16px; font-weight: 700; margin-bottom: 12px;">Customer Details</h3>
            <div style="display: grid; grid-template-columns: 80px 1fr 1fr; gap: 12px; margin-bottom: 12px;">
                <div>
                    <label class="lbl">Title</label>
                    <select name="title" class="input"><option>Mr</option><option>Mrs</option><option>Ms</option></select>
                </div>
                <div>
                    <label class="lbl">Full Name *</label>
                    <input name="customer_name" required class="input" placeholder="e.g. John Doe">
                </div>
                <div>
                    <label class="lbl">WhatsApp / Mobile *</label>
                    <input name="phone" required class="input" placeholder="e.g. +971 50 123 4567">
                </div>
            </div>
            <div style="display: grid; grid-template-columns: 1fr 120px; gap: 12px;">
                <div>
                    <label class="lbl">Hotel / Accommodation</label>
                    <input name="hotel" class="input" placeholder="e.g. Atlantis The Palm">
                </div>
                <div>
                    <label class="lbl">Room No.</label>
                    <input name="room" class="input" placeholder="e.g. 1402">
                </div>
            </div>
        </div>

        <!-- Tour Item Card -->
        <div class="card" style="border-top: 4px solid #c9a24a;">
            <h3 style="margin-top: 0; font-size: 16px; font-weight: 700; margin-bottom: 12px;">Select Tour / Ticket</h3>

            <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 12px; margin-bottom: 16px;">
                <div>
                    <label class="lbl">Tour / Ticket Product *</label>
                    <select name="tour_id" id="tour_select" class="input" onchange="handleTourChange(this)">
                        @foreach($tours as $t)
                        <option value="{{ $t->id }}" 
                            data-type="{{ $t->product_type }}" 
                            data-timing="{{ $t->ticket_timing_type }}"
                            data-hours="{{ $t->operating_hours }}">
                            [{{ $t->code_prefix }}] {{ $t->name }} ({{ $t->product_type === 'ticket' ? ($t->ticket_timing_type === 'anytime' ? '🎟️ Anytime' : '⏱️ Time-slotted') : 'Tour' }})
                        </option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <label class="lbl">Date *</label>
                    <input type="date" name="tour_date" required class="input" value="{{ date('Y-m-d') }}">
                </div>
            </div>

            <!-- Ticket Timing Info / Input -->
            <div id="time_slotted_box" style="background: #eef2ff; border: 2px solid #c7d2fe; padding: 14px; border-radius: 8px; margin-bottom: 16px;">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px;">
                    <div style="font-weight: 700; color: #1e1b4b; font-size: 14px;">⏱️ Time-Slotted Ticket Entry</div>
                    <span class="badge" style="background: #c7d2fe; color: #1e1b4b;">Specific Slot Required</span>
                </div>
                <p style="font-size: 12px; color: #3730a3; margin: 0 0 10px 0;">This ticket is for a specific time slot that the sales agent enters when making the booking (e.g. Burj Khalifa).</p>
                
                <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 10px; align-items: center;">
                    <div>
                        <label class="lbl" style="color: #1e1b4b;">Entry Time Slot *</label>
                        <input name="ticket_time_slot" id="slot_input" class="input" placeholder="e.g. 10:30, 16:30 (Prime)">
                    </div>
                    <div>
                        <div class="lbl" style="color: #1e1b4b;">Quick Slot Presets</div>
                        <div style="display: flex; flex-wrap: gap; gap: 6px;">
                            <button type="button" class="btn-outline" style="padding: 4px 8px; font-size: 11px;" onclick="setSlot('10:30')">10:30</button>
                            <button type="button" class="btn-outline" style="padding: 4px 8px; font-size: 11px;" onclick="setSlot('14:00')">14:00</button>
                            <button type="button" class="btn-outline" style="padding: 4px 8px; font-size: 11px; background: #fef3c7; border-color: #f59e0b; color: #78350f;" onclick="setSlot('16:30 (Prime)')">16:30 (Prime)</button>
                            <button type="button" class="btn-outline" style="padding: 4px 8px; font-size: 11px; background: #fef3c7; border-color: #f59e0b; color: #78350f;" onclick="setSlot('17:30 (Prime)')">17:30 (Prime)</button>
                            <button type="button" class="btn-outline" style="padding: 4px 8px; font-size: 11px;" onclick="setSlot('19:00')">19:00</button>
                        </div>
                    </div>
                </div>
            </div>

            <div id="anytime_box" style="display: none; background: #ecfdf5; border: 2px solid #a7f3d0; padding: 14px; border-radius: 8px; margin-bottom: 16px;">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 6px;">
                    <div style="font-weight: 700; color: #064e3b; font-size: 14px;">🎟️ Flexible Admission Ticket</div>
                    <span class="badge" style="background: #a7f3d0; color: #064e3b;">Valid Anytime on Selected Date</span>
                </div>
                <p style="font-size: 12px; color: #065f46; margin: 0;">This ticket grants admission to the venue at <b>any time on the selected date</b> (e.g. Ski Dubai, 10:00 – 23:00). No specific time slot is required.</p>
            </div>

            <!-- Passengers -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                <div>
                    <label class="lbl">Adults (Pax)</label>
                    <input type="number" min="1" name="adults" value="2" class="input">
                </div>
                <div>
                    <label class="lbl">Children</label>
                    <input type="number" min="0" name="children" value="0" class="input">
                </div>
            </div>
        </div>

        <!-- Payment Card -->
        <div class="card">
            <h3 style="margin-top: 0; font-size: 16px; font-weight: 700; margin-bottom: 12px;">Payment Details</h3>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                <div>
                    <label class="lbl">Amount to Pay Now (AED)</label>
                    <input type="number" step="0.01" name="amount_paid" class="input" placeholder="Leave blank or 0 for Unpaid">
                </div>
                <div>
                    <label class="lbl">Payment Method</label>
                    <select name="payment_method" class="input">
                        <option value="cash">Cash (AED)</option>
                        <option value="card">Card (POS Terminal)</option>
                    </select>
                </div>
            </div>
        </div>

        <div>
            <button type="submit" class="btn-gold" style="width: 100%; min-height: 48px; font-size: 16px;">✓ Confirm & Save Booking</button>
        </div>
    </form>
</div>

<script>
function setSlot(s) {
    document.getElementById('slot_input').value = s;
}

function handleTourChange(select) {
    const opt = select.options[select.selectedIndex];
    const type = opt.getAttribute('data-type');
    const timing = opt.getAttribute('data-timing');
    
    const timeBox = document.getElementById('time_slotted_box');
    const anyBox = document.getElementById('anytime_box');

    if (type === 'ticket') {
        if (timing === 'anytime') {
            timeBox.style.display = 'none';
            anyBox.style.display = 'block';
        } else {
            timeBox.style.display = 'block';
            anyBox.style.display = 'none';
        }
    } else {
        timeBox.style.display = 'none';
        anyBox.style.display = 'none';
    }
}

document.addEventListener('DOMContentLoaded', () => {
    handleTourChange(document.getElementById('tour_select'));
});
</script>
@endsection
