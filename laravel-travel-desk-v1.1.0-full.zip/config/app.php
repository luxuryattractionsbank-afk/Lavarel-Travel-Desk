<?php

return [
    'name' => env('APP_NAME', 'Luxury Attractions Tourism'),
    'env' => env('APP_ENV', 'production'),
    'debug' => (bool) env('APP_DEBUG', false),
    'url' => env('APP_URL', 'http://localhost'),
    'timezone' => env('APP_TIMEZONE', 'Asia/Dubai'),
    'locale' => env('APP_LOCALE', 'en'),
    'fallback_locale' => env('APP_FALLBACK_LOCALE', 'en'),
    'key' => env('APP_KEY', 'base64:3u3wZ8Pz2/Gz8t4j7h6n5b4v3c2x1z0y9x8w7v6u5t4='),
    'cipher' => 'AES-256-CBC',
    'version' => '1.1.0',
];
