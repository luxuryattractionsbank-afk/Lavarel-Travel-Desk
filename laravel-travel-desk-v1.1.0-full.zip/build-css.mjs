/**
 * Build Tailwind CSS for Laravel Travel Desk
 */
import { execSync } from "node:child_process";
import fs from "node:fs";

console.log("Building Tailwind CSS for Laravel views...");
try {
  execSync("npx @tailwindcss/cli -i resources/css/app.css -o public/css/app.css --minify", { stdio: "inherit" });
  console.log("Tailwind CSS built successfully -> public/css/app.css");
} catch (e) {
  console.log("Copying bundled CSS fallback...");
  fs.copyFileSync("public/css/app.css", "public/css/app.min.css");
}
