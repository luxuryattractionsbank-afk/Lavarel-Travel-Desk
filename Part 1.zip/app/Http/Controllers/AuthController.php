<?php

namespace App\Http\Controllers;

use App\Support\Audit;
use App\Support\PasswordResetService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class AuthController extends Controller
{
    public function show() { return Auth::check() ? redirect()->route('dashboard') : view('auth.login'); }

    public function forgotPassword() { return view('auth.forgot-password'); }

    /** Always return the same response so account existence is not disclosed. */
    public function sendResetLink(Request $r)
    {
        $d = $r->validate(['identity' => 'required|string|max:120']);
        $identity = trim($d['identity']);
        $needle = strtolower($identity);
        $user = DB::table('users')->where('status', 'active')->where(function ($q) use ($needle) {
            $q->whereRaw('LOWER(email) = ?', [$needle])->orWhereRaw('LOWER(username) = ?', [$needle]);
        })->first();

        if ($user && filter_var($user->email, FILTER_VALIDATE_EMAIL)) {
            try {
                PasswordResetService::send($user);
            } catch (\Throwable) {
                // Keep the public response identical whether the account exists or delivery succeeds.
            }
        }

        return back()->with('ok', 'If an active account matches that username or email, password reset instructions have been sent to its registered email. If they do not arrive, ask an administrator to send a reset link.');
    }

    public function resetForm(string $token)
    {
        $reset = PasswordResetService::findValid($token);
        return response()->view('auth.reset-password', ['token' => $token, 'email' => $reset->email ?? null, 'valid' => (bool) $reset], 200,
            ['Referrer-Policy' => 'no-referrer', 'Cache-Control' => 'no-store, private']);
    }

    public function resetPassword(Request $r)
    {
        $d = $r->validate(['token' => ['required', 'string', 'size:64', 'regex:/^[a-f0-9]{64}$/'], 'password' => 'required|string|min:8|confirmed']);
        try {
            $userId = PasswordResetService::reset($d['token'], $d['password']);
        } catch (\RuntimeException $e) {
            return redirect()->route('password.reset', ['token' => $d['token']])->withErrors(['token' => $e->getMessage()]);
        }
        Audit::log('user', $userId, 'password_reset_completed');
        return redirect()->route('login')->with('ok', 'Your password has been reset. Sign in with your new password.');
    }

    public function login(Request $r)
    {
        $d = $r->validate(['username' => 'required|string|max:120', 'password' => 'required|string|max:200']);
        $field = str_contains($d['username'], '@') ? 'email' : 'username';
        if (! Auth::attempt([$field => strtolower($d['username']), 'password' => $d['password'], 'status' => 'active'], true)) {
            return back()->withInput(['username' => $d['username']])->with('error', 'Invalid username or password, or the account is inactive.');
        }
        $r->session()->regenerate();
        Audit::log('user', Auth::id(), 'login');
        return redirect()->intended(route('dashboard'));
    }

    public function logout(Request $r)
    {
        Auth::logout();
        $r->session()->invalidate();
        $r->session()->regenerateToken();
        return redirect()->route('login');
    }
}
