<?php

namespace App\Http\Controllers;

use App\Support\Settings;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class FileController extends Controller
{
    /** Private files (tickets, payment slips) – only for users who can see the booking. */
    public function show(string $type, int $id)
    {
        $row = match ($type) { 'ticket' => DB::table('tickets')->where('id', $id)->first(), 'slip' => DB::table('payments')->where('id', $id)->first(), default => null };
        abort_unless($row, 404);
        $b = DB::table('bookings')->where('id', $row->booking_id)->first();
        abort_unless(BookingController::allowed($b) || can('tickets.manage'), 403);
        $path = $type === 'ticket' ? $row->file_path : $row->slip_path;
        $name = $type === 'ticket' ? $row->file_name : $row->slip_name;
        abort_unless($path && Storage::disk('local')->exists($path), 404);
        return Storage::disk('local')->response($path, $name, ['Cache-Control' => 'private, no-store', 'X-Content-Type-Options' => 'nosniff']);
    }

    public function branding(string $kind)
    {
        $c = Settings::get('company');
        $f = $kind === 'favicon' ? ($c['favicon'] ?: $c['logo']) : $c['logo'];
        if ($f && Storage::disk('public')->exists($f)) return Storage::disk('public')->response($f, null, ['Cache-Control' => 'public, max-age=300']);
        $svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="14" fill="#17223d"/><text x="32" y="42" font-family="Arial" font-weight="700" font-size="26" text-anchor="middle" fill="#e3c26b">LA</text></svg>';
        return response($svg, 200, ['Content-Type' => 'image/svg+xml', 'Cache-Control' => 'public, max-age=300']);
    }

    /** Web App Manifest so Android/Chrome "Add to Home Screen" uses a proper name and icon. */
    public function manifest()
    {
        $c = Settings::get('company');
        $name = $c['name'] ?: 'Travel Desk';
        $data = [
            'name' => $name,
            'short_name' => \Illuminate\Support\Str::limit($name, 12, ''),
            'description' => $c['description'] ?? 'Travel Desk Management System',
            'start_url' => '/dashboard',
            'scope' => '/',
            'display' => 'standalone',
            'orientation' => 'portrait-primary',
            'background_color' => '#0f1a33',
            'theme_color' => '#17223d',
            'icons' => [
                ['src' => url('/branding/icon/192'), 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any'],
                ['src' => url('/branding/icon/512'), 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'any'],
                ['src' => url('/branding/icon/192/maskable'), 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'maskable'],
                ['src' => url('/branding/icon/512/maskable'), 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'maskable'],
            ],
        ];
        return response()->json($data, 200, [
            'Content-Type' => 'application/manifest+json',
            'Cache-Control' => 'public, max-age=300',
        ]);
    }

    /**
     * Home-screen icon as a real PNG. Renders the uploaded company logo centred on a
     * navy square at the requested size. "maskable" variant pads the logo into the
     * central safe zone so Android can mask it to any shape. Falls back to a shipped
     * PNG badge if GD is unavailable or no raster logo is set.
     */
    public function icon(int $size, string $variant = '')
    {
        $size = max(48, min(1024, $size));
        $maskable = $variant === 'maskable';
        $c = Settings::get('company');
        $logoRel = $c['logo'] ?: null;

        // Fallback file (shipped) matching the closest size.
        $fallbackSize = $size >= 384 ? 512 : ($size >= 180 ? 192 : 180);
        $fallback = public_path("icons/icon-$fallbackSize.png");
        $serveFallback = function () use ($fallback, $size) {
            if (! is_file($fallback)) abort(404);
            return response(file_get_contents($fallback), 200, ['Content-Type' => 'image/png', 'Cache-Control' => 'public, max-age=300']);
        };

        if (! function_exists('imagecreatetruecolor')) return $serveFallback();

        // Load the uploaded logo (raster only).
        $src = null;
        if ($logoRel && Storage::disk('public')->exists($logoRel)) {
            $bytes = Storage::disk('public')->get($logoRel);
            $src = @imagecreatefromstring($bytes);
        }

        $canvas = imagecreatetruecolor($size, $size);
        imagealphablending($canvas, true);
        imagesavealpha($canvas, true);
        $navy = imagecolorallocate($canvas, 0x17, 0x22, 0x3d);
        imagefilledrectangle($canvas, 0, 0, $size, $size, $navy);

        if ($src) {
            $sw = imagesx($src); $sh = imagesy($src);
            // "contain" the logo; maskable uses ~72% safe zone, normal ~86%.
            $box = (int) round($size * ($maskable ? 0.72 : 0.86));
            $scale = min($box / $sw, $box / $sh);
            $dw = max(1, (int) round($sw * $scale));
            $dh = max(1, (int) round($sh * $scale));
            $dx = (int) round(($size - $dw) / 2);
            $dy = (int) round(($size - $dh) / 2);
            imagealphablending($canvas, true);
            imagecopyresampled($canvas, $src, $dx, $dy, 0, 0, $dw, $dh, $sw, $sh);
            imagedestroy($src);
        } else {
            // No raster logo: draw the "LA" badge using the bundled DejaVu font.
            $gold = imagecolorallocate($canvas, 0xe3, 0xc2, 0x6b);
            $font = base_path('vendor/dompdf/dompdf/lib/fonts/DejaVuSans-Bold.ttf');
            if (is_file($font) && function_exists('imagettftext')) {
                $fs = $size * 0.42;
                $bb = imagettfbbox($fs, 0, $font, 'LA');
                $tw = $bb[2] - $bb[0]; $th = $bb[1] - $bb[7];
                $x = (int) round(($size - $tw) / 2 - $bb[0]);
                $y = (int) round(($size - $th) / 2 - $bb[7]);
                imagettftext($canvas, $fs, 0, $x, $y, $gold, $font, 'LA');
            } else {
                imagedestroy($canvas);
                return $serveFallback();
            }
        }

        ob_start();
        imagepng($canvas);
        $png = ob_get_clean();
        imagedestroy($canvas);
        return response($png, 200, ['Content-Type' => 'image/png', 'Cache-Control' => 'public, max-age=300']);
    }

}
