<?php

namespace App\Http\Controllers;

use App\Support\Audit;
use App\Support\Settings;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

class PasswordController extends Controller
{
    /** Minutes a reset link stays valid. */
    private const TTL = 60;

    public function showForgot()
    {
        return view('auth.forgot');
    }

    /**
     * Create a reset token for the account matching the username or email and
     * email the link to that account's registered address. Always shows the
     * same message so the form cannot be used to discover which accounts exist.
     */
    public function forgot(Request $r)
    {
        $r->validate(['login' => 'required|string|max:150']);
        $login = strtolower(trim($r->login));
        $user = DB::table('users')
            ->where('status', 'active')
            ->where(fn ($q) => $q->where('username', $login)->orWhere('email', $login))
            ->first();

        $done = 'If an account matches, a password reset link has been sent to its registered email address.';
        if (! $user || ! filter_var($user->email, FILTER_VALIDATE_EMAIL)) {
            return back()->with('ok', $done);
        }

        [$sent, $error] = self::issueAndSend($user);
        if (! $sent) {
            return back()->with('error', 'Could not send the reset email: '.$error);
        }
        return back()->with('ok', $done);
    }

    public function showReset(string $token, Request $r)
    {
        return view('auth.reset', ['token' => $token, 'email' => (string) $r->query('email', '')]);
    }

    public function reset(Request $r)
    {
        $d = $r->validate([
            'email' => 'required|email',
            'token' => 'required|string',
            'password' => 'required|string|min:8|confirmed',
        ], ['password.confirmed' => 'The two passwords do not match.']);

        $email = strtolower(trim($d['email']));
        $row = DB::table('password_reset_tokens')->where('email', $email)->first();
        if (! $row || ! Hash::check($d['token'], $row->token)) {
            return back()->withInput(['email' => $email])->with('error', 'This reset link is invalid. Please request a new one.');
        }
        if (\Illuminate\Support\Carbon::parse($row->created_at)->addMinutes(self::TTL)->isPast()) {
            DB::table('password_reset_tokens')->where('email', $email)->delete();
            return back()->with('error', 'This reset link has expired. Please request a new one.');
        }
        $user = DB::table('users')->where('email', $email)->first();
        if (! $user) {
            return back()->with('error', 'Account not found.');
        }

        DB::table('users')->where('id', $user->id)->update(['password' => Hash::make($d['password']), 'updated_at' => now()]);
        DB::table('password_reset_tokens')->where('email', $email)->delete();
        Audit::log('user', (int) $user->id, 'password_reset', ['via' => 'self_service']);

        return redirect()->route('login')->with('ok', 'Your password has been reset. Please sign in.');
    }

    /**
     * Generate a fresh token for a user, store its hash, and email the link.
     * Returns [bool $sent, ?string $error]. Reusable by admin-triggered resets.
     */
    public static function issueAndSend(object $user, ?string $intro = null): array
    {
        $email = strtolower(trim((string) $user->email));
        if (! filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return [false, 'The account has no valid email address.'];
        }
        $token = Str::random(64);
        DB::table('password_reset_tokens')->updateOrInsert(
            ['email' => $email],
            ['token' => Hash::make($token), 'created_at' => now()]
        );

        $company = Settings::get('company');
        $link = route('password.reset', $token).'?email='.urlencode($email);
        $name = $user->display_name ?? $user->full_name ?? $email;
        $body = ($intro ? $intro."\n\n" : '')
            ."Hello {$name},\n\n"
            ."We received a request to reset the password for your ".($company['name'] ?? 'Travel Desk')." account (username: {$user->username}).\n\n"
            ."Reset your password using this link (valid for ".self::TTL." minutes):\n{$link}\n\n"
            ."If you did not request this, you can ignore this email - your password will not change.\n";
        $subject = 'Reset your '.($company['name'] ?? 'Travel Desk').' password';

        $status = 'sent'; $error = null;
        try {
            MailConfig::apply();
            Mail::raw($body, function ($m) use ($email, $subject) {
                $m->to($email)->subject($subject);
            });
        } catch (\Throwable $e) {
            $status = 'failed'; $error = $e->getMessage();
        }
        DB::table('email_logs')->insert(['booking_id' => null, 'template' => 'password_reset', 'recipient' => $email, 'subject' => $subject, 'status' => $status, 'error' => $error, 'user_id' => auth()->id(), 'created_at' => now()]);
        return [$status === 'sent', $error];
    }
}
