<?php

namespace App\Support;

/**
 * Pricing engine (server-side, authoritative). Mirrors public/js/pricing.js used for the live preview.
 * All amounts in base currency.
 *
 * $tour, $option: arrays (DB rows). $in: item input array. $ctx: ['addons'=>[], 'vehicles'=>[], 'slots'=>[]] (arrays keyed by id or list).
 */
class Pricing
{
    public static function calculate(array $tour, ?array $option, array $in, array $ctx): array
    {
        $errors = []; $warnings = []; $lines = []; $approval = []; $categoryFix = null;
        $r2 = fn ($n) => round((float) $n, 2);
        $adults = max(0, (int) ($in['adults'] ?? 0)); $children = max(0, (int) ($in['children'] ?? 0)); $infants = max(0, (int) ($in['infants'] ?? 0));
        $pax = $adults + $children + $infants;
        $date = $in['tour_date'] ?? '';
        $dir = ($in['transfer_direction'] ?? 'two_way') === 'one_way' ? 'one_way' : 'two_way';

        if (! $date) $errors[] = 'Tour date is required.';
        else {
            $days = $tour['available_days'] ?? [0, 1, 2, 3, 4, 5, 6];
            if (count($days) < 7 && ! in_array((int) date('w', strtotime($date)), $days)) $errors[] = "{$tour['name']} does not operate on the selected weekday.";
        }
        if ($pax < 1) $errors[] = 'At least one passenger is required.';
        if ($adults + $children < 1 && $infants > 0) $errors[] = 'Infants must be accompanied by an adult or child.';
        if (! $option) $errors[] = 'Select an option/category.';

        // Ticket time-slot category enforcement: the entered time must match the chosen option's category.
        if ($option && ($tour['product_type'] ?? '') === 'ticket' && ($tour['ticket_timing'] ?? 'anytime') === 'time_slot') {
            $slots = $tour['ticket_slots'] ?? [];
            $norm = fn ($v) => strtolower(trim((string) $v));
            $start = trim((string) ($in['entry_time'] ?? ''));
            $optCat = $norm($option['ticket_category'] ?? '');
            // Category of the entered time = category of a listed slot with the same time (non-empty category).
            $timeCat = null; $timeCatLabel = null;
            foreach ($slots as $sl) {
                if ($start !== '' && trim((string) $sl['slot_time']) === $start && trim((string) ($sl['category'] ?? '')) !== '') { $timeCat = $norm($sl['category']); $timeCatLabel = trim((string) $sl['category']); break; }
            }
            if ($start !== '' && $timeCat !== null && $optCat !== '' && $timeCat !== $optCat) {
                // Suggest the sibling option whose category matches the entered time.
                $suggest = null;
                foreach (($tour['options'] ?? []) as $o2) {
                    if (($o2['active'] ?? true) && $norm($o2['ticket_category'] ?? '') === $timeCat) { $suggest = $o2['name']; break; }
                }
                $enforce = false;
                try { $enforce = ! empty(\App\Support\Settings::get('booking')['enforce_ticket_category_time']); } catch (\Throwable $e) {}
                $msg = "The selected time $start is a \"$timeCatLabel\" slot but the chosen option is \"".($option['ticket_category'] ?? '')."\".".($suggest ? " Switch to \"$suggest\"." : ' Choose the matching option or a valid time.');
                $categoryFix = ['time_category' => $timeCatLabel, 'suggest' => $suggest];
                if ($enforce) $errors[] = $msg; else $warnings[] = $msg;
            }
        }

        $listBase = 0; $soldBase = 0; $minBase = 0; $sold = ['adult' => null, 'child' => null, 'infant' => null];
        $num = fn ($v) => ($v === null || $v === '' || ! is_numeric($v)) ? null : $r2($v);

        if ($option) {
            foreach ([['adult', $adults, 'Adults'], ['child', $children, 'Children'], ['infant', $infants, 'Infants']] as [$k, $q, $nm]) {
                if ($q > 0 && ! $option["{$k}_allowed"]) $errors[] = trim("{$nm} are not sold under \"{$option['name']}\". ".($option['restriction_note'] ?? ''));
            }
            if ($option['pricing_method'] === 'per_person') {
                foreach ([['adult', $adults, 'Adult'], ['child', $children, 'Child'], ['infant', $infants, 'Infant']] as [$k, $q, $nm]) {
                    if (! $q) continue;
                    $list = (float) $option["{$k}_price"];
                    $lines[] = ['label' => "{$option['name']} – $nm", 'qty' => $q, 'unit' => $list, 'total' => $r2($q * $list), 'kind' => 'base'];
                    $custom = $num($in["{$k}_price"] ?? null);
                    if ($custom !== null && $custom < 0) $errors[] = "$nm price cannot be negative.";
                    $unit = $custom ?? $list;
                    if ($custom !== null && abs($custom - $list) > 0.004) $sold[$k] = $custom;
                    $floor = min($option["min_{$k}_price"] !== null ? (float) $option["min_{$k}_price"] : $list, $list);
                    $listBase += $q * $list; $soldBase += $q * $unit; $minBase += $q * $floor;
                    if ($unit < $floor - 0.004) $approval[] = "$nm ".number_format($unit, 2)." is below the minimum ".number_format($floor, 2);
                }
            } elseif ($option['pricing_method'] === 'per_group' || ($option['pricing_method'] === 'per_vehicle' && ((float) $option['group_price'] > 0 || (float) ($option['group_oneway_price'] ?? 0) > 0))) {
                $isVeh = $option['pricing_method'] === 'per_vehicle';
                $count = $isVeh ? max(1, (int) ($in['vehicle_count'] ?? 1)) : 1;
                $gp2 = (float) $option['group_price'];
                $gpOne = (float) ($option['group_oneway_price'] ?? 0);
                $gp = ($isVeh && $dir === 'one_way' && $gpOne > 0) ? $gpOne : $gp2;
                $minTwo = $option['min_group_price'] !== null ? (float) $option['min_group_price'] : $gp2;
                $minOne = ($option['min_group_oneway'] ?? null) !== null ? (float) $option['min_group_oneway'] : ($gpOne > 0 ? $gpOne : $minTwo);
                $floorG = min(($isVeh && $dir === 'one_way') ? $minOne : $minTwo, $gp);
                $dirLbl = $isVeh ? ' ('.($dir === 'one_way' ? 'One Way' : 'Two Way').')' : '';
                $lines[] = ['label' => "{$option['name']} – ".($isVeh ? 'Per Vehicle'.$dirLbl : 'Group Charge'), 'qty' => $count, 'unit' => $gp, 'total' => $r2($count * $gp), 'kind' => 'base'];
                $listBase += $count * $gp; $soldBase += $count * $gp; $minBase += $count * $floorG;
            }
            elseif ($option['pricing_method'] === 'per_hour') {
                $rate = (float) ($option['hourly_rate'] ?? 0);
                $primeRate = (float) ($option['prime_hourly_rate'] ?? 0);
                $primeStart = $option['prime_start'] ?? null; $primeEnd = $option['prime_end'] ?? null;
                $minFloorRate = ($option['min_hourly_rate'] ?? null) !== null ? (float) $option['min_hourly_rate'] : null;
                $cap = ($option['capacity'] ?? null) !== null ? (int) $option['capacity'] : null;
                $minHours = max((int) ($option['min_hours'] ?? 0), (int) ($tour['min_booking_hours'] ?? 0));
                $hours = (int) ($in['booking_hours'] ?? 0);
                $start = trim((string) ($in['entry_time'] ?? ''));

                if ($cap !== null && $pax > $cap) {
                    if (! empty($tour['allow_over_capacity'])) $warnings[] = "Passengers ($pax) exceed {$option['name']} capacity of $cap.";
                    else $errors[] = "Passengers ($pax) exceed {$option['name']} maximum capacity of $cap.";
                }
                if ($start === '') $errors[] = 'Yacht start time is required.';
                if ($hours < 1) $errors[] = 'Enter the number of hours.';
                elseif ($minHours > 0 && $hours < $minHours) $errors[] = "Minimum booking is $minHours hour(s) for {$option['name']}.";

                $toMin = function ($t) { return preg_match('/^(\d{1,2}):(\d{2})/', (string) $t, $m) ? ((int) $m[1]) * 60 + (int) $m[2] : null; };
                $ps = $toMin($primeStart); $pe = $toMin($primeEnd); $st = $toMin($start);
                $normalHours = 0; $primeHours = 0;
                if ($hours > 0) {
                    for ($h = 0; $h < $hours; $h++) {
                        $isPrime = false;
                        if ($primeRate > 0 && $ps !== null && $pe !== null && $st !== null) {
                            $seg = ($st + $h * 60) % 1440;
                            $isPrime = $pe > $ps ? ($seg >= $ps && $seg < $pe) : ($seg >= $ps || $seg < $pe);
                        }
                        if ($isPrime) $primeHours++; else $normalHours++;
                    }
                }
                if ($normalHours > 0) {
                    $lines[] = ['label' => "{$option['name']} – {$normalHours} hr @ ".number_format($rate, 2), 'qty' => $normalHours, 'unit' => $rate, 'total' => $r2($normalHours * $rate), 'kind' => 'base'];
                    $floorN = $minFloorRate !== null ? min($minFloorRate, $rate) : $rate;
                    $listBase += $normalHours * $rate; $soldBase += $normalHours * $rate; $minBase += $normalHours * $floorN;
                }
                if ($primeHours > 0) {
                    $lines[] = ['label' => "{$option['name']} – {$primeHours} prime hr @ ".number_format($primeRate, 2), 'qty' => $primeHours, 'unit' => $primeRate, 'total' => $r2($primeHours * $primeRate), 'kind' => 'base'];
                    $floorP = $minFloorRate !== null ? min($minFloorRate, $primeRate) : $primeRate;
                    $listBase += $primeHours * $primeRate; $soldBase += $primeHours * $primeRate; $minBase += $primeHours * $floorP;
                }
            }
            elseif ($option['pricing_method'] === 'per_unit') {
                $unitPrice = (float) ($option['unit_price'] ?? 0);
                $unitMin = ($option['min_unit_price'] ?? null) !== null ? (float) $option['min_unit_price'] : null;
                $mins = (int) ($option['unit_minutes'] ?? 0);
                $cap = ($option['capacity'] ?? null) !== null ? (int) $option['capacity'] : null;
                $units = (int) ($in['booking_units'] ?? 0);
                if ($units < 1) $errors[] = 'Enter the number of units.';
                if ($cap !== null && $cap > 0 && $pax > $cap * max(1, $units)) {
                    if (! empty($tour['allow_over_capacity'])) $warnings[] = "Passengers ($pax) exceed {$option['name']} capacity.";
                    else $errors[] = "Passengers ($pax) exceed capacity of ".($cap * max(1, $units))." for $units unit(s) of {$option['name']}.";
                }
                if ($units > 0) {
                    $lbl = $mins > 0 ? "{$mins} min" : 'unit';
                    $lines[] = ['label' => "{$option['name']} – {$units} × {$lbl} @ ".number_format($unitPrice, 2), 'qty' => $units, 'unit' => $unitPrice, 'total' => $r2($units * $unitPrice), 'kind' => 'base'];
                    $floorU = $unitMin !== null ? min($unitMin, $unitPrice) : $unitPrice;
                    $listBase += $units * $unitPrice; $soldBase += $units * $unitPrice; $minBase += $units * $floorU;
                }
            }
        }

        // Transfer
        $privateRequired = $option && $option['pricing_method'] === 'per_vehicle';
        $type = $privateRequired ? 'private' : ($in['transfer_type'] ?? 'none');
        $dir = ($in['transfer_direction'] ?? 'two_way') === 'one_way' ? 'one_way' : 'two_way';
        $transferPricing = null; $pickup = trim((string) ($in['pickup_time'] ?? '')) ?: null; $drop = null;
        if ($type === 'none' && ! $tour['no_transfer_allowed'] && $tour['product_type'] === 'tour') $errors[] = 'This tour requires a transfer (shared or private).';
        if ($type === 'shared') {
            if (! $tour['shared_available']) $errors[] = 'Shared transfer is not available for this product.';
            $transferPricing = $tour['shared_transfer_pricing'];
            $slot = null;
            foreach ($ctx['slots'] as $s) if ((int) $s['id'] === (int) ($in['slot_id'] ?? 0)) $slot = $s;
            if (count($ctx['slots']) && ! $slot) $errors[] = 'Select a pickup time window.';
            if ($slot) {
                $pickup = "{$slot['pickup_start']}–{$slot['pickup_end']}";
                if ($dir === 'two_way') {
                    if ($slot['drop_start']) $drop = "{$slot['drop_start']}–".($slot['drop_end'] ?: $slot['drop_start']);
                    elseif ($tour['duration_minutes']) $drop = Fmt::addMinutes($slot['pickup_start'], $tour['duration_minutes']).'–'.Fmt::addMinutes($slot['pickup_end'], $tour['duration_minutes']);
                }
            }
            if ($tour['shared_transfer_pricing'] === 'extra') {
                $twoway = $dir === 'two_way';
                $price = (float) ($twoway ? ($tour['shared_twoway_price'] ?? 0) : ($tour['shared_oneway_price'] ?? 0));
                $minRef = $twoway ? ($tour['shared_twoway_min'] ?? null) : ($tour['shared_oneway_min'] ?? null);
                $floorT = min($minRef !== null ? (float) $minRef : $price, $price);
                if ($price > 0) {
                    $q = $adults + $children;
                    $lines[] = ['label' => 'Shared Transfer ('.($twoway ? 'Two Way' : 'One Way').') – per person', 'qty' => $q, 'unit' => $price, 'total' => $r2($q * $price), 'kind' => 'transfer'];
                    $listBase += $q * $price; $soldBase += $q * $price; $minBase += $q * $floorT;
                }
            }
        }
        $vehicle = null;
        if ($type === 'private') {
            if (! $tour['private_available'] && ! $privateRequired) $errors[] = 'Private transfer is not available for this product.';
            $transferPricing = 'extra';
            foreach ($ctx['vehicles'] as $v) if ((int) $v['id'] === (int) ($in['vehicle_id'] ?? 0)) $vehicle = $v;
            $count = max(1, (int) ($in['vehicle_count'] ?? 1));
            if (! $vehicle) $errors[] = 'Select a private vehicle.';
            else {
                if ($pax > $vehicle['capacity'] * $count) {
                    if ($tour['allow_over_capacity']) $warnings[] = "Passengers ($pax) exceed {$vehicle['name']} capacity.";
                    else $errors[] = "Passengers ($pax) exceed {$vehicle['name']} capacity of ".($vehicle['capacity'] * $count).'. Choose a larger vehicle or add vehicles.';
                }
                $lines[] = ['label' => "Private Transfer – {$vehicle['name']} – Group Charge", 'qty' => $count, 'unit' => (float) $vehicle['price'], 'total' => $r2($count * $vehicle['price']), 'kind' => 'vehicle'];
            }
            if ($dir === 'two_way') {
                $manualDrop = trim((string) ($in['drop_time'] ?? ''));
                if ($manualDrop !== '') $drop = $manualDrop;
                elseif (! empty($tour['closing_time'])) $drop = $tour['closing_time'];
                elseif ($pickup && $tour['duration_minutes'] && preg_match('/^\d{1,2}:\d{2}$/', $pickup)) $drop = Fmt::addMinutes($pickup, $tour['duration_minutes']);
            }
        }

        // Add-ons
        $addonLines = [];
        foreach ($in['addons'] ?? [] as $a) {
            $def = null;
            foreach ($ctx['addons'] as $x) if ((int) $x['id'] === (int) ($a['addon_id'] ?? 0)) $def = $x;
            $q = (int) ($a['quantity'] ?? 0);
            if (! $def || $q <= 0) continue;
            $qty = $def['pricing_method'] === 'per_group' ? 1 : $q;
            if ($def['pricing_method'] === 'per_person' && $q > $pax) $errors[] = "{$def['name']}: quantity ($q) cannot exceed passengers ($pax).";
            $custom = $num($a['price'] ?? null);
            $list = (float) $def['price'];
            $unit = $custom ?? $list;
            $floor = min($def['min_price'] !== null ? (float) $def['min_price'] : $list, $list);
            $listBase += $qty * $list; $soldBase += $qty * $unit; $minBase += $qty * $floor;
            if ($unit < $floor - 0.004) $approval[] = "{$def['name']} ".number_format($unit, 2).' is below the minimum '.number_format($floor, 2);
            $lbl = ['per_person' => 'per person', 'per_unit' => 'per unit', 'per_vehicle' => 'per vehicle', 'per_group' => 'group'][$def['pricing_method']] ?? $def['pricing_method'];
            $lines[] = ['label' => "Add-on: {$def['name']} ($lbl)".($custom !== null && abs($custom - $list) > 0.004 ? ' – agreed '.number_format($unit, 2) : ''), 'qty' => $qty, 'unit' => $list, 'total' => $r2($qty * $list), 'kind' => 'addon'];
            $addonLines[] = ['addon_id' => $def['id'], 'name' => $def['name'], 'pricing_method' => $def['pricing_method'], 'quantity' => $qty, 'unit_price' => $unit, 'total' => $r2($qty * $unit)];
        }

        $standard = $r2(array_sum(array_column($lines, 'total')));
        $sub = $r2($standard - $listBase + $soldBase);
        $minTotal = $r2($standard - $listBase + $minBase);
        $agreed = $num($in['agreed_price'] ?? null);
        $discount = $r2(max(0, (float) ($in['discount'] ?? 0)));
        $total = $sub;
        if ($agreed !== null) {
            if ($agreed < 0) $errors[] = 'Agreed price cannot be negative.';
            $total = $agreed;
        } elseif ($discount > 0) {
            if ($discount > $sub) $errors[] = 'Discount cannot exceed the price.';
            $total = $r2($sub - $discount);
        }
        if ($agreed !== null) $approval = [];
        if ($total < $minTotal - 0.004) $approval[] = 'Total '.number_format($total, 2).' is below the minimum allowed '.number_format($minTotal, 2);

        return [
            'lines' => $lines, 'standard' => $standard, 'discount' => $r2($standard - $total), 'agreed' => $agreed, 'total' => $r2($total), 'min_total' => $minTotal,
            'requires_approval' => count($approval) > 0, 'approval_reasons' => array_values(array_unique($approval)), 'sold' => $sold,
            'errors' => $errors, 'warnings' => $warnings, 'pax' => $pax, 'pickup_time' => $pickup, 'drop_time' => $drop, 'hours' => (($option['pricing_method'] ?? '') === 'per_hour' ? max(0, (int) ($in['booking_hours'] ?? 0)) : null), 'units' => (($option['pricing_method'] ?? '') === 'per_unit' ? max(0, (int) ($in['booking_units'] ?? 0)) : null), 'transfer_type' => $type,
            'transfer_direction' => $type === 'none' ? null : $dir, 'transfer_pricing' => $transferPricing, 'vehicle' => $vehicle, 'addon_lines' => $addonLines, 'category_fix' => $categoryFix,
        ];
    }

    public static function paymentStatus(float $total, float $paid, float $refunded, bool $cancelled): string
    {
        $net = round($paid - $refunded, 2);
        if ($refunded > 0 && $net <= 0.004) return 'refunded';
        if ($cancelled) return $refunded > 0 ? 'partially_refunded' : 'cancelled';
        if ($refunded > 0) return 'partially_refunded';
        if ($total > 0 && $net >= $total - 0.004) return 'paid';
        if ($total <= 0 && $net >= 0) return $paid > 0 ? 'paid' : 'unpaid';
        return $net > 0 ? 'partially_paid' : 'unpaid';
    }

    /** Cash/card settlement: how much of a tendered payment applies and how change is handled. No limits on change. */
    public static function settle(string $method, float $amount, float $rate, float $balance, ?string $changeCur, ?float $changeRate, $changeAmount, float $tolerance, string $base): array
    {
        $r2 = fn ($n) => round((float) $n, 2);
        $errors = [];
        $tendered = $r2($amount * $rate);
        $balance = $r2(max(0, $balance));
        if (! ($amount > 0)) $errors[] = 'Enter a payment amount.';
        if ($balance <= 0.004) $errors[] = 'Nothing is due on this booking.';
        $applied = $r2(min($tendered, $balance));
        $over = $r2(max(0, $tendered - $applied));
        $cc = null; $cr = null; $ca = 0.0; $cb = 0.0;
        if ($over > 0 && $balance > 0.004) {
            $cc = $changeCur ?: $base; $cr = ($changeRate && $changeRate > 0) ? $changeRate : 1.0;
            $suggest = $r2($over / $cr);
            $ca = ($changeAmount === null || $changeAmount === '') ? ($over <= $tolerance + 0.0001 ? 0 : $suggest) : $r2($changeAmount);
            if ($ca < 0) $errors[] = 'Change amount cannot be negative.';
            $cb = $r2(max(0, $ca) * $cr);
        }
        return ['tendered' => $tendered, 'applied' => $applied, 'over' => $over, 'change_currency' => $ca > 0 ? $cc : null, 'change_amount' => $ca, 'change_base' => $cb, 'rounding' => $r2($over - $cb), 'errors' => $errors];
    }
}
