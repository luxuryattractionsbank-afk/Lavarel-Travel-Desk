<?php

namespace App\Support;

use App\Http\Controllers\MailConfig;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use RuntimeException;

class PasswordResetService
{
    private const LIFETIME_MINUTES = 60;
    private const RESEND_DELAY_SECONDS = 60;

    /** Send a short-lived, one-time reset link to the staff account's registered email. */
    public static function send(object $user): void
    {
        $email = strtolower(trim((string) ($user->email ?? '')));
        if (! filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new RuntimeException('This account does not have a valid registered email address.');
        }

        $existing = DB::table('account_password_resets')->where('user_id', (int) $user->id)->first();
        if ($existing && $existing->created_at && \Illuminate\Support\Carbon::parse($existing->created_at)->greaterThan(now()->subSeconds(self::RESEND_DELAY_SECONDS))) {
            throw new RuntimeException('A reset email was sent recently. Please wait one minute before requesting another.');
        }

        $token = bin2hex(random_bytes(32));
        $tokenHash = hash('sha256', $token);
        DB::table('account_password_resets')->updateOrInsert(
            ['user_id' => (int) $user->id],
            ['token_hash' => $tokenHash, 'expires_at' => now()->addMinutes(self::LIFETIME_MINUTES), 'created_at' => now(), 'updated_at' => now()]
        );

        $url = route('password.reset', ['token' => $token]);
        $company = Settings::get('company')['name'] ?? 'Travel Desk';
        $body = "Hello ".($user->full_name ?: 'there').",\n\n".
            "A password reset was requested for your Travel Desk account (username: {$user->username}).\n\n".
            "Use the link below to choose a new password. This one-time link expires in ".self::LIFETIME_MINUTES." minutes:\n\n".
            "$url\n\nIf you did not request this change, you can ignore this email. Your current password will remain unchanged.\n\n$company";

        try {
            MailConfig::apply();
            Mail::raw($body, function ($message) use ($email, $company) {
                $message->to($email)->subject("Reset your Travel Desk password – $company");
            });
        } catch (\Throwable $e) {
            DB::table('account_password_resets')->where('user_id', (int) $user->id)->where('token_hash', $tokenHash)->delete();
            throw new RuntimeException('The reset email could not be sent. Check the SMTP settings and try again.', 0, $e);
        }
    }

    /** Return only the account details needed to render a valid reset form. */
    public static function findValid(string $token): ?object
    {
        if (! preg_match('/^[a-f0-9]{64}$/', $token)) return null;
        return DB::table('account_password_resets as resets')
            ->join('users', 'users.id', '=', 'resets.user_id')
            ->where('resets.token_hash', hash('sha256', $token))
            ->where('resets.expires_at', '>', now())
            ->select('users.email', 'users.full_name')
            ->first();
    }

    /** Validate and consume a one-time reset token atomically. Returns the account ID. */
    public static function reset(string $token, string $password): int
    {
        if (! preg_match('/^[a-f0-9]{64}$/', $token)) {
            throw new RuntimeException('This password reset link is invalid or has expired. Request a new link.');
        }

        return DB::transaction(function () use ($token, $password) {
            $reset = DB::table('account_password_resets')
                ->where('token_hash', hash('sha256', $token))
                ->lockForUpdate()
                ->first();
            if (! $reset || now()->greaterThanOrEqualTo($reset->expires_at)) {
                throw new RuntimeException('This password reset link is invalid or has expired. Request a new link.');
            }

            $user = DB::table('users')->where('id', $reset->user_id)->lockForUpdate()->first();
            if (! $user) throw new RuntimeException('This password reset link is no longer valid. Request a new link.');

            DB::table('users')->where('id', $user->id)->update([
                'password' => Hash::make($password),
                'remember_token' => bin2hex(random_bytes(30)),
                'updated_at' => now(),
            ]);
            DB::table('account_password_resets')->where('user_id', $user->id)->delete();
            return (int) $user->id;
        });
    }
}
