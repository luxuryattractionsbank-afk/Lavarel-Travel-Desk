<?php

namespace App\Support;

use Illuminate\Support\Facades\DB;

class Catalog
{
    public static function rows($q): array { return array_map(fn ($r) => (array) $r, $q->get()->all()); }

    /** One tour with its options, add-ons, vehicles (own or global) and slots – arrays for the pricing engine. */
    public static function tour(int $id): ?array
    {
        $t = DB::table('tours')->where('id', $id)->first();
        if (! $t) return null;
        $t = (array) $t;
        $t['available_days'] = json_decode($t['available_days'], true) ?: [0, 1, 2, 3, 4, 5, 6];
        foreach (['active', 'no_transfer_allowed', 'shared_available', 'private_available', 'requires_ticket', 'allow_over_capacity'] as $b) $t[$b] = (bool) $t[$b];
        $t['options'] = array_map(function ($o) {
            foreach (['adult_allowed', 'child_allowed', 'infant_allowed', 'active'] as $b) $o[$b] = (bool) $o[$b];
            foreach (['adult_price', 'child_price', 'infant_price', 'group_price', 'group_oneway_price', 'hourly_rate', 'prime_hourly_rate', 'unit_price'] as $m) $o[$m] = (float) ($o[$m] ?? 0);
            foreach (['min_adult_price', 'min_child_price', 'min_infant_price', 'min_group_price', 'min_group_oneway', 'min_hourly_rate', 'min_unit_price'] as $m) $o[$m] = (! array_key_exists($m, $o) || $o[$m] === null) ? null : (float) $o[$m];
            foreach (['capacity', 'min_hours', 'unit_minutes'] as $m) $o[$m] = (! array_key_exists($m, $o) || $o[$m] === null || $o[$m] === '') ? null : (int) $o[$m];
            return $o;
        }, self::rows(DB::table('tour_options')->where('tour_id', $id)->where('active', true)->orderBy('sort')->orderBy('id')));
        $t['addons'] = array_map(fn ($a) => ['price' => (float) $a['price'], 'min_price' => $a['min_price'] === null ? null : (float) $a['min_price']] + $a, self::rows(DB::table('addons')->where('tour_id', $id)->where('active', true)));
        $own = self::rows(DB::table('vehicles')->where('tour_id', $id)->where('active', true)->orderBy('capacity'));
        $t['vehicles'] = array_map(fn ($v) => ['price' => (float) $v['price']] + $v, $own ?: self::rows(DB::table('vehicles')->whereNull('tour_id')->where('active', true)->orderBy('capacity')));
        $t['slots'] = self::rows(DB::table('pickup_slots')->where('tour_id', $id)->where('active', true)->orderBy('pickup_start'));
        $t['ticket_timing'] = ($t['ticket_timing'] ?? 'anytime') === 'time_slot' ? 'time_slot' : 'anytime';
        $t['ticket_slots'] = self::rows(DB::table('ticket_slots')->where('tour_id', $id)->where('active', true)->orderBy('sort')->orderBy('slot_time'));
        $t['shared_transfer_price'] = (float) $t['shared_transfer_price'];
        foreach (['shared_twoway_price', 'shared_oneway_price'] as $m) $t[$m] = (float) ($t[$m] ?? 0);
        foreach (['shared_twoway_min', 'shared_oneway_min'] as $m) $t[$m] = (! array_key_exists($m, $t) || $t[$m] === null) ? null : (float) $t[$m];
        return $t;
    }

    public static function all(): array
    {
        return array_values(array_filter(array_map(fn ($id) => self::tour($id), DB::table('tours')->orderBy('product_type')->orderBy('name')->pluck('id')->all())));
    }
}
