<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * v1.3 - Directional transfer pricing.
 *
 * Shared transfers can now have distinct One-way and Two-way prices (each with a
 * minimum for the approval floor). Private per-vehicle options can have a separate
 * One-way price + minimum. Additive & data-preserving: existing bookings untouched;
 * existing per-way shared price is migrated so current totals are unchanged.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('tours')) {
            Schema::table('tours', function (Blueprint $t) {
                if (! Schema::hasColumn('tours', 'shared_twoway_price')) $t->decimal('shared_twoway_price', 14, 2)->default(0)->after('shared_transfer_price');
                if (! Schema::hasColumn('tours', 'shared_twoway_min'))   $t->decimal('shared_twoway_min', 14, 2)->nullable()->after('shared_twoway_price');
                if (! Schema::hasColumn('tours', 'shared_oneway_price'))  $t->decimal('shared_oneway_price', 14, 2)->default(0)->after('shared_twoway_min');
                if (! Schema::hasColumn('tours', 'shared_oneway_min'))    $t->decimal('shared_oneway_min', 14, 2)->nullable()->after('shared_oneway_price');
            });
            // Preserve current behaviour: old value was per-person / per-way.
            // Two-way total = old x 2, One-way total = old.
            DB::statement('update tours set shared_twoway_price = coalesce(shared_transfer_price,0) * 2 where coalesce(shared_twoway_price,0) = 0');
            DB::statement('update tours set shared_oneway_price = coalesce(shared_transfer_price,0) where coalesce(shared_oneway_price,0) = 0');
        }

        if (Schema::hasTable('tour_options')) {
            Schema::table('tour_options', function (Blueprint $t) {
                if (! Schema::hasColumn('tour_options', 'group_oneway_price')) $t->decimal('group_oneway_price', 14, 2)->default(0)->after('group_price');
                if (! Schema::hasColumn('tour_options', 'min_group_oneway'))   $t->decimal('min_group_oneway', 14, 2)->nullable()->after('min_group_price');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('tour_options')) {
            Schema::table('tour_options', function (Blueprint $t) {
                foreach (['group_oneway_price', 'min_group_oneway'] as $c) if (Schema::hasColumn('tour_options', $c)) $t->dropColumn($c);
            });
        }
        if (Schema::hasTable('tours')) {
            Schema::table('tours', function (Blueprint $t) {
                foreach (['shared_twoway_price', 'shared_twoway_min', 'shared_oneway_price', 'shared_oneway_min'] as $c) if (Schema::hasColumn('tours', $c)) $t->dropColumn($c);
            });
        }
    }
};
