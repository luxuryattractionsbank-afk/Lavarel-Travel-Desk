<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * v1.7 - Per-unit (jet ski) pricing.
 *
 * Adds a "per_unit" option pricing method for products like jet skis that are
 * sold in fixed duration blocks (e.g. 20 or 30 minutes) with a number of units.
 * Each option defines its block length (unit_minutes) and a price per unit; the
 * agent enters how many units. Different durations are separate options, so an
 * agent can add "2 x 20 min" on one line and "1 x 30 min" on another. Additive.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('tour_options')) {
            Schema::table('tour_options', function (Blueprint $t) {
                if (! Schema::hasColumn('tour_options', 'unit_minutes'))   $t->unsignedInteger('unit_minutes')->nullable()->after('min_hours');
                if (! Schema::hasColumn('tour_options', 'unit_price'))     $t->decimal('unit_price', 14, 2)->default(0)->after('unit_minutes');
                if (! Schema::hasColumn('tour_options', 'min_unit_price')) $t->decimal('min_unit_price', 14, 2)->nullable()->after('min_hourly_rate');
            });
        }

        if (Schema::hasTable('booking_items') && ! Schema::hasColumn('booking_items', 'booking_units')) {
            Schema::table('booking_items', function (Blueprint $t) {
                $t->unsignedInteger('booking_units')->nullable()->after('booking_hours');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('booking_items') && Schema::hasColumn('booking_items', 'booking_units')) {
            Schema::table('booking_items', fn (Blueprint $t) => $t->dropColumn('booking_units'));
        }
        if (Schema::hasTable('tour_options')) {
            Schema::table('tour_options', function (Blueprint $t) {
                foreach (['unit_minutes', 'unit_price', 'min_unit_price'] as $c) if (Schema::hasColumn('tour_options', $c)) $t->dropColumn($c);
            });
        }
    }
};
