<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * v1.1 – Ticket timing.
 *
 * Some tickets are time-slotted (e.g. Burj Khalifa: the guest is admitted at a
 * specific entry time the agent chooses at booking). Others grant admission at
 * any time on the selected date (e.g. Ski Dubai). This migration is additive –
 * existing bookings, payments and staff records are untouched.
 */
return new class extends Migration
{
    public function up(): void
    {
        // How a ticket is timed: 'anytime' (default, same as before) or 'time_slot'.
        if (Schema::hasTable('tours') && ! Schema::hasColumn('tours', 'ticket_timing')) {
            Schema::table('tours', function (Blueprint $t) {
                $t->string('ticket_timing', 12)->default('anytime')->after('product_type');
            });
        }

        // Optional predefined admission times for time-slotted tickets (e.g. "Prime Hours 18:30").
        if (! Schema::hasTable('ticket_slots')) {
            Schema::create('ticket_slots', function (Blueprint $t) {
                $t->id();
                $t->foreignId('tour_id')->constrained()->cascadeOnDelete();
                $t->string('label')->nullable();       // e.g. "Prime Hours"
                $t->string('slot_time', 5);            // "HH:MM" entry time
                $t->boolean('is_prime')->default(false);
                $t->boolean('active')->default(true);
                $t->integer('sort')->default(0);
            });
        }

        // The specific admission time chosen on a booking line (time-slotted tickets only).
        if (Schema::hasTable('booking_items')) {
            Schema::table('booking_items', function (Blueprint $t) {
                if (! Schema::hasColumn('booking_items', 'entry_time')) {
                    $t->string('entry_time', 20)->nullable()->after('drop_time');
                }
                if (! Schema::hasColumn('booking_items', 'entry_slot_id')) {
                    $t->unsignedBigInteger('entry_slot_id')->nullable()->after('entry_time');
                }
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('booking_items')) {
            Schema::table('booking_items', function (Blueprint $t) {
                if (Schema::hasColumn('booking_items', 'entry_slot_id')) $t->dropColumn('entry_slot_id');
                if (Schema::hasColumn('booking_items', 'entry_time')) $t->dropColumn('entry_time');
            });
        }
        Schema::dropIfExists('ticket_slots');
        if (Schema::hasTable('tours') && Schema::hasColumn('tours', 'ticket_timing')) {
            Schema::table('tours', function (Blueprint $t) { $t->dropColumn('ticket_timing'); });
        }
    }
};
