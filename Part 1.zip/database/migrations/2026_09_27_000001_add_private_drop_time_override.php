<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /** Store an agent-selected drop-back time separately from the computed default. */
    public function up(): void
    {
        if (! Schema::hasTable('booking_items')) {
            throw new RuntimeException('Travel Desk booking_items table is missing.');
        }

        if (! Schema::hasColumn('booking_items', 'drop_time_override')) {
            Schema::table('booking_items', function (Blueprint $table) {
                $table->string('drop_time_override', 5)->nullable();
            });
        }
    }

    public function down(): void
    {
        // Preserve booking timing data if an update is rolled back.
    }
};
