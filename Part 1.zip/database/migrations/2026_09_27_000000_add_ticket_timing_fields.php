<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /** Add ticket entry rules without changing existing booking data. */
    public function up(): void
    {
        if (! Schema::hasTable('tours') || ! Schema::hasTable('booking_items')) {
            throw new RuntimeException('Travel Desk tables are missing. Run this update only after the existing Travel Desk database is installed.');
        }

        if (! Schema::hasColumn('tours', 'ticket_timing_type')) {
            Schema::table('tours', function (Blueprint $table) {
                // Existing ticket products safely default to timed entry until reviewed by an admin.
                $table->string('ticket_timing_type', 20)->default('time_slotted');
            });
        }

        if (! Schema::hasColumn('booking_items', 'ticket_timing_type')) {
            Schema::table('booking_items', function (Blueprint $table) {
                $table->string('ticket_timing_type', 20)->nullable();
            });
        }

        if (! Schema::hasColumn('booking_items', 'ticket_time_slot')) {
            Schema::table('booking_items', function (Blueprint $table) {
                $table->string('ticket_time_slot', 80)->nullable();
            });
        }
    }

    public function down(): void
    {
        // Keep additive fields on rollback so historical booking records are never discarded.
    }
};
