<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * v1.4 - Hourly (yacht) pricing.
 *
 * Adds a "per_hour" option pricing method for products like private yachts:
 * a per-hour rate, an optional higher prime-hours rate within a time window,
 * a per-yacht maximum capacity (Adults + Children + Infants), and a minimum
 * number of booking hours (general default on the product, plus a per-option
 * override). Additive & data-preserving.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('tour_options')) {
            Schema::table('tour_options', function (Blueprint $t) {
                if (! Schema::hasColumn('tour_options', 'capacity'))          $t->unsignedInteger('capacity')->nullable()->after('pricing_method');
                if (! Schema::hasColumn('tour_options', 'hourly_rate'))       $t->decimal('hourly_rate', 14, 2)->default(0)->after('group_oneway_price');
                if (! Schema::hasColumn('tour_options', 'prime_hourly_rate')) $t->decimal('prime_hourly_rate', 14, 2)->default(0)->after('hourly_rate');
                if (! Schema::hasColumn('tour_options', 'prime_start'))       $t->string('prime_start', 5)->nullable()->after('prime_hourly_rate');
                if (! Schema::hasColumn('tour_options', 'prime_end'))         $t->string('prime_end', 5)->nullable()->after('prime_start');
                if (! Schema::hasColumn('tour_options', 'min_hours'))         $t->unsignedInteger('min_hours')->nullable()->after('prime_end');
                if (! Schema::hasColumn('tour_options', 'min_hourly_rate'))   $t->decimal('min_hourly_rate', 14, 2)->nullable()->after('min_group_oneway');
            });
        }

        if (Schema::hasTable('tours') && ! Schema::hasColumn('tours', 'min_booking_hours')) {
            Schema::table('tours', function (Blueprint $t) {
                $t->unsignedInteger('min_booking_hours')->nullable()->after('duration_minutes');
            });
        }

        if (Schema::hasTable('booking_items') && ! Schema::hasColumn('booking_items', 'booking_hours')) {
            Schema::table('booking_items', function (Blueprint $t) {
                $t->unsignedInteger('booking_hours')->nullable()->after('entry_slot_id');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('booking_items') && Schema::hasColumn('booking_items', 'booking_hours')) {
            Schema::table('booking_items', fn (Blueprint $t) => $t->dropColumn('booking_hours'));
        }
        if (Schema::hasTable('tours') && Schema::hasColumn('tours', 'min_booking_hours')) {
            Schema::table('tours', fn (Blueprint $t) => $t->dropColumn('min_booking_hours'));
        }
        if (Schema::hasTable('tour_options')) {
            Schema::table('tour_options', function (Blueprint $t) {
                foreach (['capacity', 'hourly_rate', 'prime_hourly_rate', 'prime_start', 'prime_end', 'min_hours', 'min_hourly_rate'] as $c) {
                    if (Schema::hasColumn('tour_options', $c)) $t->dropColumn($c);
                }
            });
        }
    }
};
