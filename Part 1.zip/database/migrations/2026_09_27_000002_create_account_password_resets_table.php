<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /** Store a hashed, one-time reset token per user; never store usable tokens. */
    public function up(): void
    {
        if (! Schema::hasTable('account_password_resets')) {
            Schema::create('account_password_resets', function (Blueprint $table) {
                $table->id();
                $table->foreignId('user_id')->unique()->constrained('users')->cascadeOnDelete();
                $table->char('token_hash', 64)->unique();
                $table->timestamp('expires_at')->index();
                $table->timestamps();
            });
        }
    }

    public function down(): void
    {
        // Keep reset metadata on rollback; it contains hashes only and is safe to retain.
    }
};
