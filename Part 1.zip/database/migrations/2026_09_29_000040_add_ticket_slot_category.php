<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * v1.5 - Link ticket admission times to an option/ticket category.
 *
 * Each admission time can be tagged with a category (matching an option's
 * "Ticket category"). On the booking, when an agent picks an option the entry
 * times are filtered to that option's category (times with no category show for
 * all options). Additive & data-preserving.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('ticket_slots') && ! Schema::hasColumn('ticket_slots', 'category')) {
            Schema::table('ticket_slots', function (Blueprint $t) {
                $t->string('category', 80)->nullable()->after('label');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('ticket_slots') && Schema::hasColumn('ticket_slots', 'category')) {
            Schema::table('ticket_slots', fn (Blueprint $t) => $t->dropColumn('category'));
        }
    }
};
