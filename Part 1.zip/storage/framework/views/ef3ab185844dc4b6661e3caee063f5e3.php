<?php $__env->startSection('title', 'Price approvals'); ?>
<?php use App\Support\Fmt; ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.header', ['title' => can('pricing.approve') ? 'Price approvals' : 'My price approval requests', 'subtitle' => 'Sales below the minimum price need approval from another authorised user. Approvals are valid for 24 hours and one booking.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<div x-data x-init="setInterval(() => { if (!document.querySelector('input:focus')) location.reload() }, 15000)"></div>
<?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <?php $live = $a->status === 'pending' && now()->lt($a->expires_at); ?>
  <div class="card mb-3 <?php echo e($live ? 'border-2 border-amber-300' : ''); ?>">
    <div class="flex flex-wrap justify-between gap-2"><div><div class="font-semibold">#<?php echo e($a->id); ?> · <?php echo e($a->tour_name); ?> <span class="font-normal text-slate-500">– <?php echo e($a->option_name); ?></span></div><div class="text-xs text-slate-500">By <b><?php echo e($a->agent); ?></b> · <?php echo e(Fmt::dt($a->created_at)); ?> · <?php echo e($a->customer_name); ?> · <?php echo e($a->adults); ?>A/<?php echo e($a->children); ?>C/<?php echo e($a->infants); ?>I</div></div><?php echo badge($live || $a->status !== 'pending' ? $a->status : 'expired'); ?></div>
    <div class="mt-2 grid gap-1 text-sm sm:grid-cols-3"><div>Listed: <b><?php echo e(money($a->standard_total)); ?></b></div><div>Minimum: <b><?php echo e(money($a->min_total)); ?></b></div><div class="text-red-700">Requested: <b><?php echo e(money($a->requested_total)); ?></b></div></div>
    <?php if($a->reason): ?><p class="mt-2 rounded bg-slate-50 p-2 text-xs"><?php echo e($a->reason); ?></p><?php endif; ?>
    <?php if($a->decided_at): ?><p class="mt-2 text-xs"><?php echo e(Fmt::label($a->status)); ?> by <b><?php echo e($a->decider); ?></b> · <?php echo e(Fmt::dt($a->decided_at)); ?> <?php echo e($a->decision_note ? '– “'.$a->decision_note.'”' : ''); ?></p><?php endif; ?>
    <?php if(can('pricing.approve') && $live): ?>
      <?php if($a->requested_by_id == auth()->id()): ?><p class="mt-3 rounded bg-slate-100 p-2 text-xs">Your own request – must be approved by another user from their login.</p>
      <?php else: ?><form method="post" action="<?php echo e(route('approvals.decide', $a->id)); ?>" class="mt-3 flex flex-wrap gap-2"><?php echo csrf_field(); ?><input name="note" placeholder="Note (required to reject)" class="input flex-1"><button name="decision" value="approved" class="btn bg-emerald-600 text-white">✓ Approve</button><button name="decision" value="rejected" class="btn-danger">✕ Reject</button></form><?php endif; ?>
    <?php endif; ?>
    <div class="mt-2"><?php echo $__env->make('partials.delete', ['entity' => 'approval', 'id' => $a->id, 'what' => 'approval #'.$a->id], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><div class="card text-center text-slate-500">No requests</div><?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u384871713/domains/luxuryattractions.com/public_html/traveldesk/resources/views/approvals.blade.php ENDPATH**/ ?>