<div class="mb-5 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
    <div><h1 class="text-xl font-bold text-navy-900 sm:text-2xl"><?php echo e($title); ?></h1><?php if(isset($subtitle)): ?><p class="mt-1 text-sm text-slate-500"><?php echo $subtitle; ?></p><?php endif; ?></div>
    <?php if(isset($actions)): ?><div class="flex flex-wrap gap-2"><?php echo $actions; ?></div><?php endif; ?>
</div>
<?php /**PATH /home/u384871713/domains/luxuryattractions.com/public_html/traveldesk/resources/views/partials/header.blade.php ENDPATH**/ ?>