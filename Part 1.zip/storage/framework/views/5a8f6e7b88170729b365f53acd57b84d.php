
<link rel="manifest" href="<?php echo e(url('/manifest.webmanifest')); ?>">
<meta name="theme-color" content="#17223d">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="<?php echo e((\App\Support\Settings::get('company')['name'] ?? 'Travel Desk')); ?>">
<link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(url('/branding/icon/180')); ?>">
<link rel="icon" type="image/png" sizes="192x192" href="<?php echo e(url('/branding/icon/192')); ?>">
<link rel="icon" type="image/png" sizes="512x512" href="<?php echo e(url('/branding/icon/512')); ?>">
<?php /**PATH /home/u384871713/domains/luxuryattractions.com/public_html/traveldesk/resources/views/partials/pwa-head.blade.php ENDPATH**/ ?>