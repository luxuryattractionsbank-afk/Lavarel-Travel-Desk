<?php $__env->startSection('title', 'My profile'); ?>
<?php $__env->startSection('content'); ?>
<?php $u = auth()->user(); ?>
<?php echo $__env->make('partials.header', ['title' => 'My profile', 'subtitle' => $u->full_name.' · '.$u->roleName().' · '.$u->email], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<div class="grid gap-5 lg:grid-cols-2">
  <form method="post" action="<?php echo e(route('profile.save')); ?>" class="card" onsubmit="const c = document.getElementById('my-sig'); this.signature.value = c.dataset.signed === '1' ? c.toDataURL('image/png') : ''"><?php echo csrf_field(); ?><div class="card-title">My digital signature</div>
    <p class="mb-2 text-sm text-slate-500">Automatically used as the sales agent signature on new receipts.</p><input type="hidden" name="signature">
    <canvas id="my-sig" data-src="<?php echo e($u->signature); ?>" x-data x-init="sigPad($el)" class="h-36 w-full touch-none rounded-lg border-2 border-dashed bg-white"></canvas>
    <div class="mt-3 flex gap-2"><button class="btn-primary">Save signature</button><button type="button" class="btn-outline" onclick="document.getElementById('my-sig').clear()">Clear</button></div></form>
  <form method="post" action="<?php echo e(route('profile.save')); ?>" class="card space-y-3"><?php echo csrf_field(); ?><div class="card-title">Change password</div>
    <div><label class="lbl">Current password</label><input type="password" name="current" required class="input"></div><div><label class="lbl">New password (min 8)</label><input type="password" name="password" minlength="8" required class="input"></div>
    <div><label class="lbl">Repeat new password</label><input type="password" name="password_confirmation" minlength="8" required class="input"></div><button class="btn-primary">Update password</button></form>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?><script src="<?php echo e(asset('js/booking.js')); ?>"></script><?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u384871713/domains/luxuryattractions.com/public_html/traveldesk/resources/views/profile.blade.php ENDPATH**/ ?>