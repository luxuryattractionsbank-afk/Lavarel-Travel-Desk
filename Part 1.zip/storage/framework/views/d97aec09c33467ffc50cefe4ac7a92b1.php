<?php $__env->startSection('title', 'Bookings'); ?>
<?php $__env->startSection('content'); ?>
<?php $qs = http_build_query(request()->except('view')); ?>
<?php echo $__env->make('partials.header', ['title' => 'Bookings & Receipts', 'subtitle' => $rows->count().' receipt(s) · Total '.money($rows->where('status', '!=', 'cancelled')->sum('total_amount')).' · Outstanding '.money($rows->sum('balance_due')),
  'actions' => '<div class="flex overflow-hidden rounded-lg border border-slate-300"><a href="'.route('bookings').'?'.$qs.'" class="btn-sm btn rounded-none '.(!$table ? 'bg-navy-800 text-white' : 'bg-white').'">🧾 Receipts</a><a href="'.route('bookings').'?'.$qs.'&view=table" class="btn-sm btn rounded-none '.($table ? 'bg-navy-800 text-white' : 'bg-white').'">📋 Table view</a></div>'
  .($table ? '<a href="'.route('bookings.export').'?'.$qs.'" class="btn-outline btn-sm">⬇ Excel (CSV)</a>' : '').(can('bookings.create') ? '<a href="'.route('bookings.create').'" class="btn-gold">+ New Booking</a>' : '')], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<form class="card mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-6">
  <?php if($table): ?><input type="hidden" name="view" value="table"><?php endif; ?>
  <input name="q" value="<?php echo e(request('q')); ?>" placeholder="Receipt, tour code, name, phone, hotel, room…" class="input lg:col-span-2">
  <select name="pay" class="input"><option value="">Any payment status</option><option value="outstanding" <?php if(request('pay') === 'outstanding'): echo 'selected'; endif; ?>>Outstanding</option><?php $__currentLoopData = ['unpaid','partially_paid','paid','refunded','partially_refunded','cancelled']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($s); ?>" <?php if(request('pay') === $s): echo 'selected'; endif; ?>><?php echo e(lbl($s)); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
  <select name="status" class="input"><option value="">Any booking status</option><?php $__currentLoopData = ['draft','confirmed','partially_paid','paid','pending','cancelled','refunded','completed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($s); ?>" <?php if(request('status') === $s): echo 'selected'; endif; ?>><?php echo e(lbl($s)); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
  <select name="desk" class="input"><option value="">Any travel desk</option><?php $__currentLoopData = $desks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option <?php if(request('desk') === $d): echo 'selected'; endif; ?>><?php echo e($d); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
  <?php if($agents->count()): ?><select name="agent" class="input"><option value="">Any sales agent</option><?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($a->id); ?>" <?php if(request('agent') == $a->id): echo 'selected'; endif; ?>><?php echo e($a->full_name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select><?php else: ?><span></span><?php endif; ?>
  <label class="text-xs text-slate-500">Issued from<input type="date" name="from" value="<?php echo e(request('from')); ?>" class="input"></label>
  <label class="text-xs text-slate-500">Issued to<input type="date" name="to" value="<?php echo e(request('to')); ?>" class="input"></label>
  <label class="text-xs text-slate-500">Tour date from<input type="date" name="tour_from" value="<?php echo e(request('tour_from')); ?>" class="input"></label>
  <label class="text-xs text-slate-500">Tour date to<input type="date" name="tour_to" value="<?php echo e(request('tour_to')); ?>" class="input"></label>
  <select name="collection" class="input self-end"><option value="">Any collection</option><option value="travel_desk" <?php if(request('collection') === 'travel_desk'): echo 'selected'; endif; ?>>Travel desk</option><option value="driver" <?php if(request('collection') === 'driver'): echo 'selected'; endif; ?>>Driver</option></select>
  <div class="flex items-end gap-2"><button class="btn-primary flex-1">Filter</button><a href="<?php echo e(route('bookings')); ?><?php echo e($table ? '?view=table' : ''); ?>" class="btn-outline">Reset</a></div>
</form>

<?php if(!$table): ?>
  <div class="overflow-x-auto rounded-xl border border-slate-200 bg-white">
    <table class="tbl"><thead><tr><th>Receipt</th><th>Issued</th><th>Customer</th><th>Tours</th><th>Desk / Agent</th><th class="text-right">Total</th><th class="text-right">Balance</th><th>Status</th></tr></thead><tbody>
    <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <tr class="hover:bg-slate-50"><td><a href="<?php echo e(route('bookings.show', $r->id)); ?>" class="font-mono font-semibold text-navy-700 underline"><?php echo e($r->receipt_number); ?></a></td>
        <td class="whitespace-nowrap text-xs"><?php echo e(\App\Support\Fmt::dt($r->issued_at)); ?></td><td><?php echo e($r->cust); ?><div class="text-xs text-slate-500"><?php echo e($r->phone); ?> · <?php echo e($r->hotel); ?><?php echo e($r->room_number ? ' #'.$r->room_number : ''); ?></div></td>
        <td class="max-w-xs text-xs"><?php echo e($tours->get($r->id, collect())->map(fn ($i) => $i->tour_code.' '.$i->tour_name)->implode(', ')); ?></td>
        <td class="text-xs"><?php echo e($r->travel_desk ?: '-'); ?><div class="text-slate-500"><?php echo e($r->agent); ?></div></td>
        <td class="text-right"><?php echo e(money($r->total_amount, $r->base_currency)); ?></td><td class="text-right font-semibold text-red-600"><?php echo e($r->balance_due > 0 ? money($r->balance_due, $r->base_currency) : '-'); ?></td>
        <td><?php echo badge($r->status); ?><br><?php echo badge($r->payment_status); ?></td></tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="8" class="p-6 text-center text-slate-500">No bookings found</td></tr><?php endif; ?>
    </tbody></table></div>
<?php else: ?>
  <?php
    $cols = [['created','Booking Creation Date'],['desk','Travel Desk'],['agent','Travel Agent'],['receipt','Receipt No.'],['code','Tour Code'],['tour_date','Tour Date'],['tour','Tour / Ticket Name'],['transfer','Transfer'],['addons','Add Ons'],['guest','Guest Name'],['pickup','Hotel / Pick Up Location'],['room','Room No.'],['contacts','Contact Number'],['copy','Copy Text'],['pax','Pax'],['item_total','Item Total'],['receipt_total','Receipt Total'],['paid','Paid'],['balance','Balance Due'],['cash','Cash'],['card','Card'],['driver','Driver'],['payments','Payment Details'],['pay_status','Payment Status'],['collection','Balance Collection'],['status','Booking Status']];
  ?>
  <div class="rounded-xl border border-slate-200 bg-white" x-data="excelTable(<?php echo \Illuminate\Support\Js::from($lines->values())->toHtml() ?>, <?php echo \Illuminate\Support\Js::from($cols)->toHtml() ?>)">
    <div class="flex flex-wrap items-center gap-3 border-b px-3 py-2 text-xs text-slate-600">
      <span><b x-text="view.length"></b> of <?php echo e($lines->count()); ?> line(s)</span>
      <span>Lines total <b x-text="view.reduce((s, r) => s + r.item_total, 0).toFixed(2)"></b></span>
      <span class="ml-auto flex gap-2"><button type="button" x-show="Object.keys(filters).length || sort" @click="filters = {}; sort = null" class="btn-outline btn-sm text-red-600">✕ Clear filters</button>
        <button type="button" @click="copyText(view.map(r => r.copy).join('\n\n'), $event.target)" class="btn-sm btn bg-navy-800 text-white" x-text="'📋 Copy all ' + view.length + ' copy texts'"></button></span>
    </div>
    <div class="max-h-[75vh] overflow-auto">
      <table class="min-w-[2400px] text-xs"><thead><tr>
        <template x-for="[k, h] in cols" :key="k"><th class="sticky top-0 z-20 whitespace-nowrap border-b px-2 py-2 text-left text-[11px] font-semibold uppercase text-slate-600" :class="['receipt_total','paid','balance','cash','card','driver','payments','pay_status','collection','status'].includes(k) ? 'bg-amber-100' : 'bg-slate-100'">
          <div class="relative flex items-center gap-1"><span x-text="h"></span>
            <button type="button" @click="open = open === k ? null : k; search = ''" class="grid h-6 min-w-6 place-items-center rounded border px-1 text-[10px]" :class="filters[k] ? 'bg-navy-800 text-white' : (sort?.k === k ? 'bg-gold-400/40' : 'bg-white')" x-text="filters[k] ? '⏷' : (sort?.k === k ? (sort.dir > 0 ? '↑' : '↓') : '▾')"></button>
            <div x-show="open === k" x-cloak @click.outside="open = null" class="absolute top-full z-30 mt-1 w-72 rounded-lg border bg-white p-2 text-left text-xs font-normal normal-case text-slate-800 shadow-2xl">
              <button type="button" class="block w-full rounded px-2 py-1.5 text-left hover:bg-slate-100" @click="sort = {k, dir: 1}; open = null">↑ Sort A → Z / smallest first</button>
              <button type="button" class="block w-full rounded px-2 py-1.5 text-left hover:bg-slate-100" @click="sort = {k, dir: -1}; open = null">↓ Sort Z → A / largest first</button>
              <template x-if="k !== 'copy'"><div><div class="my-1 border-t"></div>
                <button type="button" class="block w-full rounded px-2 py-1.5 text-left text-red-600 hover:bg-red-50" @click="delete filters[k]; filters = {...filters}; open = null">✕ Clear filter</button>
                <input x-model="search" placeholder="Search…" class="input mt-1 min-h-9 py-1 text-xs">
                <div class="mt-1 max-h-56 overflow-auto rounded border p-1">
                  <template x-for="v in values(k).filter(v => v.toLowerCase().includes(search.toLowerCase()))" :key="v"><label class="flex cursor-pointer items-start gap-2 rounded px-1 py-1 hover:bg-slate-50"><input type="checkbox" :checked="!filters[k] || filters[k].includes(v)" @change="toggle(k, v)"><span x-text="v.length > 70 ? v.slice(0, 70) + '…' : v"></span></label></template>
                </div></div></template>
            </div></div></th></template>
      </tr></thead><tbody>
        <template x-for="(r, i) in view" :key="i"><tr class="hover:bg-slate-50" :class="i === 0 || view[i-1].booking_id !== r.booking_id ? 'border-t-2 border-slate-200' : ''">
          <template x-for="[k] in cols" :key="k"><td class="border-b border-slate-100 px-2 py-1.5 align-top" :class="{'text-right font-semibold': ['item_total','receipt_total','paid','balance','cash','card','driver'].includes(k), 'min-w-72': k === 'copy', 'min-w-56': ['tour','pickup','contacts'].includes(k), 'bg-amber-50/40': ['receipt_total','paid','balance','cash','card','driver','payments','pay_status','collection','status'].includes(k), 'whitespace-nowrap': ['created','tour_date','receipt','code','pax','guest'].includes(k)}">
            <template x-if="k === 'receipt'"><a :href="'<?php echo e(url('/bookings')); ?>/' + r.booking_id" class="font-mono font-semibold text-navy-700 underline" x-text="r.receipt"></a></template>
            <template x-if="k === 'copy'"><div class="group relative"><pre class="max-h-16 overflow-hidden whitespace-pre-wrap rounded border bg-slate-50 p-1.5 pr-16 font-mono text-[10px] group-hover:max-h-none" x-text="r.copy"></pre><button type="button" @click="copyText(r.copy, $event.target)" class="absolute right-1 top-1 rounded bg-navy-800 px-2 py-1 text-[10px] font-bold text-white">📋 Copy</button></div></template>
            <template x-if="k !== 'receipt' && k !== 'copy'"><span x-text="typeof r[k] === 'number' ? (r[k] ? r[k].toFixed(2) : '-') : r[k]"></span></template>
          </td></template>
        </tr></template>
        <tr x-show="!view.length"><td :colspan="cols.length" class="p-6 text-center text-slate-500">No rows match</td></tr>
      </tbody></table>
    </div>
    <p class="border-t px-3 py-2 text-[11px] text-slate-500">Click ▾ on a column to sort or filter it like Excel. Shaded payment columns are per receipt.</p>
  </div>
  <?php $__env->startPush('scripts'); ?><script>
  function excelTable(rows, cols) { return { rows, cols, filters: {}, sort: null, open: null, search: '',
    str(r, k) { const v = r[k]; return (typeof v === 'number' ? v.toFixed(2) : (v || '')) || '(Blanks)' },
    values(k) { return [...new Set(this.rows.filter(r => Object.entries(this.filters).every(([f, s]) => f === k || s.includes(this.str(r, f)))).map(r => this.str(r, k)))].sort((a, b) => a.localeCompare(b, undefined, {numeric: true})) },
    toggle(k, v) { const all = this.values(k); let s = this.filters[k] ? [...this.filters[k]] : [...all]; s = s.includes(v) ? s.filter(x => x !== v) : [...s, v]; if (s.length === all.length) delete this.filters[k]; else this.filters[k] = s; this.filters = {...this.filters} },
    get view() { let v = this.rows.filter(r => Object.entries(this.filters).every(([f, s]) => s.includes(this.str(r, f)))); if (this.sort) { const {k, dir} = this.sort, key = k === 'tour_date' ? 'tour_sort' : k; v = [...v].sort((a, b) => { const x = a[key], y = b[key]; return (typeof x === 'number' ? x - y : String(x).localeCompare(String(y), undefined, {numeric: true})) * dir }) } return v } } }
  </script><?php $__env->stopPush(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u384871713/domains/luxuryattractions.com/public_html/traveldesk/resources/views/bookings/index.blade.php ENDPATH**/ ?>