<?php $company = \App\Support\Settings::get('company'); ?>
<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Sign in – <?php echo e($company['name']); ?></title>
<link rel="icon" href="<?php echo e(url('/branding/favicon')); ?>"><link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <?php echo $__env->make('partials.pwa-head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></head>
<body class="grid min-h-screen place-items-center bg-gradient-to-br from-navy-900 via-navy-800 to-navy-700 px-4">
<div class="w-full max-w-md">
    <div class="mb-6 text-center text-white">
        <img src="<?php echo e(url('/branding/logo')); ?>" alt="" class="mx-auto mb-3 h-16 w-16 rounded-2xl bg-white object-contain">
        <h1 class="text-2xl font-bold"><?php echo e($company['name']); ?></h1><p class="text-sm text-gold-400">Travel Desk Management System</p>
    </div>
    <form method="post" action="/login" class="card space-y-4"><?php echo csrf_field(); ?>
        <?php if(session('ok')): ?><p class="rounded-lg bg-emerald-50 p-3 text-sm text-emerald-800">✓ <?php echo e(session('ok')); ?></p><?php endif; ?>
        <?php if(session('error')): ?><p class="rounded-lg bg-red-50 p-2 text-sm text-red-700"><?php echo e(session('error')); ?></p><?php endif; ?>
        <?php if($errors->any()): ?><p class="rounded-lg bg-red-50 p-2 text-sm text-red-700"><?php echo e($errors->first()); ?></p><?php endif; ?>
        <div><label class="lbl">Username or email</label><input name="username" value="<?php echo e(old('username')); ?>" class="input" required autofocus autocomplete="username"></div>
        <div><label class="lbl">Password</label><input name="password" type="password" class="input" required autocomplete="current-password"></div>
        <button class="btn-primary w-full">Sign in</button>
        <p class="text-center text-sm"><a href="<?php echo e(route('password.request')); ?>" class="text-navy-700 underline">Forgot your password?</a></p>
    </form>
    <p class="mt-4 text-center text-xs text-slate-300"><?php echo e($company['phone']); ?> · <?php echo e($company['email']); ?></p>
</div></body></html>
<?php /**PATH /home/u384871713/domains/luxuryattractions.com/public_html/traveldesk/resources/views/auth/login.blade.php ENDPATH**/ ?>