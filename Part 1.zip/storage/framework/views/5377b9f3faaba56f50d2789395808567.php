<?php if(can('records.delete')): ?>
<form method="post" action="<?php echo e(route('delete', [$entity, $id])); ?>" class="inline" onsubmit="<?php echo e(!empty($heavy) ? "if (prompt('Permanently delete ".e($what)."? Everything linked to it is deleted too. A copy is kept in the audit log.\\n\\nType DELETE to confirm:') !== 'DELETE') return false;" : "if (!confirm('Permanently delete ".e($what)."? A copy is kept in the audit log.')) return false;"); ?> this.reason.value = prompt('Reason (optional):') || ''; return true;">
    <?php echo csrf_field(); ?><input type="hidden" name="reason"><input type="hidden" name="back" value="<?php echo e($back ?? url()->current()); ?>">
    <button class="btn-sm btn border border-red-200 bg-white text-red-600 hover:bg-red-50">🗑 Delete</button>
</form>
<?php endif; ?>
<?php /**PATH /home/u384871713/domains/luxuryattractions.com/public_html/traveldesk/resources/views/partials/delete.blade.php ENDPATH**/ ?>