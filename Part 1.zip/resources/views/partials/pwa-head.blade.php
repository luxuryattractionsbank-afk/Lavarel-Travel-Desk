{{-- Android/Chrome "Add to Home Screen" + iOS home-screen support --}}
<link rel="manifest" href="{{ url('/manifest.webmanifest') }}">
<meta name="theme-color" content="#17223d">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="{{ (\App\Support\Settings::get('company')['name'] ?? 'Travel Desk') }}">
<link rel="apple-touch-icon" sizes="180x180" href="{{ url('/branding/icon/180') }}">
<link rel="icon" type="image/png" sizes="192x192" href="{{ url('/branding/icon/192') }}">
<link rel="icon" type="image/png" sizes="512x512" href="{{ url('/branding/icon/512') }}">
