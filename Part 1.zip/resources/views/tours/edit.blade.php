@extends('layouts.app')
@section('title', $t->name ?? 'New product')
@section('content')
@php $chk = fn ($n, $v, $l) => '<label class="flex min-h-11 items-center gap-2 text-sm"><input type="checkbox" name="'.$n.'" value="1" '.($v ? 'checked' : '').' class="h-5 w-5"> '.$l.'</label>'; $days = $t ? json_decode($t->available_days, true) : [0,1,2,3,4,5,6]; @endphp
<div class="mb-5 flex items-end justify-between"><div><h1 class="text-2xl font-bold text-navy-900">{{ $t->name ?? 'New product' }}</h1><a href="{{ route('tours') }}" class="text-sm underline">← All products</a></div>
  @if($t)@include('partials.delete', ['entity' => 'tour', 'id' => $t->id, 'what' => 'product '.$t->name, 'heavy' => true, 'back' => route('tours')])@endif</div>
<form method="post" action="{{ route('tours.save', $t->id ?? null) }}" class="card grid gap-3 sm:grid-cols-4">@csrf
  <label class="text-xs sm:col-span-2">Name<input name="name" value="{{ old('name', $t->name ?? '') }}" required class="input"></label>
  <label class="text-xs">Tour code prefix<input name="code_prefix" value="{{ old('code_prefix', $t->code_prefix ?? '') }}" required maxlength="6" class="input font-mono uppercase" placeholder="DS"></label>
  <label class="text-xs">Product type<select name="product_type" class="input"><option value="tour" @selected(($t->product_type ?? 'tour') === 'tour')>Tour (usually with transport)</option><option value="ticket" @selected(($t->product_type ?? '') === 'ticket')>Ticket (admission)</option></select></label>
  <label class="text-xs">Ticket timing<select name="ticket_timing" class="input"><option value="anytime" @selected(($t->ticket_timing ?? 'anytime') === 'anytime')>Anytime on date (e.g. Ski Dubai)</option><option value="time_slot" @selected(($t->ticket_timing ?? '') === 'time_slot')>Specific time slot (e.g. Burj Khalifa)</option></select><span class="mt-1 block text-[11px] text-slate-500">Only used for Ticket products.</span></label>
  <label class="text-xs sm:col-span-4">Description<textarea name="description" class="input">{{ $t->description ?? '' }}</textarea></label>
  <label class="text-xs">Default supplier (auto-assign)<select name="supplier_id" class="input"><option value="">None – assign per booking</option>@foreach($suppliers as $s)<option value="{{ $s->id }}" @selected(($t->supplier_id ?? null) == $s->id)>{{ $s->name }}</option>@endforeach</select></label>
  <label class="text-xs">Duration (minutes)<input name="duration_minutes" type="number" value="{{ $t->duration_minutes ?? 0 }}" class="input"></label>
  <label class="text-xs">Min booking hours (yacht, general)<input name="min_booking_hours" type="number" min="0" value="{{ $t->min_booking_hours ?? '' }}" class="input" placeholder="e.g. 2"></label>
  <label class="text-xs">Opening time<input name="opening_time" type="time" value="{{ $t->opening_time ?? '' }}" class="input"></label><label class="text-xs">Closing time<input name="closing_time" type="time" value="{{ $t->closing_time ?? '' }}" class="input"></label>
  <label class="text-xs sm:col-span-2">Operating hours (display)<input name="operating_hours" value="{{ $t->operating_hours ?? '' }}" class="input"></label><label class="text-xs sm:col-span-2">Validity<input name="validity" value="{{ $t->validity ?? '' }}" class="input"></label>
  <div class="rounded-lg border p-3 sm:col-span-4"><div class="lbl">Suppliers who offer this product (quick select)</div><div class="flex flex-wrap gap-2">@foreach($suppliers as $s)<label class="flex min-h-11 items-center gap-2 rounded-lg border px-3 text-sm"><input type="checkbox" name="supplier_ids[]" value="{{ $s->id }}" @checked(in_array($s->id, $linked)) class="h-5 w-5"> {{ $s->name }}</label>@endforeach</div>
    @if($linked)<p class="mt-2 text-xs">Supplier price lists: @foreach($suppliers->whereIn('id', $linked) as $s)<a class="text-navy-700 underline" href="{{ route('suppliers.show', $s->id) }}">{{ $s->name }}</a> @endforeach</p>@endif</div>
  <div class="sm:col-span-4"><div class="lbl">Available days</div><div class="flex flex-wrap gap-3">@foreach(['Sun','Mon','Tue','Wed','Thu','Fri','Sat'] as $i => $dn)<label class="flex min-h-11 items-center gap-2 text-sm"><input type="checkbox" name="available_days[]" value="{{ $i }}" @checked(in_array($i, $days)) class="h-5 w-5"> {{ $dn }}</label>@endforeach</div></div>
  <div class="grid gap-2 rounded-lg bg-slate-50 p-3 sm:col-span-4 sm:grid-cols-3"><div class="lbl sm:col-span-3">Transfer configuration</div>
    {!! $chk('no_transfer_allowed', $t->no_transfer_allowed ?? false, 'No transfer allowed (ticket only)') !!}{!! $chk('shared_available', $t->shared_available ?? true, 'Shared transfer available') !!}{!! $chk('private_available', $t->private_available ?? false, 'Private transfer available') !!}
    <label class="text-xs">Shared transfer pricing<select name="shared_transfer_pricing" class="input"><option value="included">Included in tour price</option><option value="extra" @selected(($t->shared_transfer_pricing ?? '') === 'extra')>Extra charge</option></select></label>
    <label class="text-xs">Default direction<select name="default_direction" class="input"><option value="two_way">Two way</option><option value="one_way" @selected(($t->default_direction ?? '') === 'one_way')>One way</option></select></label>
    <div class="sm:col-span-3 grid gap-2 rounded-lg border border-slate-200 bg-white p-2 sm:grid-cols-4">
      <div class="lbl sm:col-span-4 mb-0">Shared extra price per person (used when pricing = Extra charge)</div>
      <label class="text-xs">Two-way price<input name="shared_twoway_price" type="number" step="0.01" value="{{ $t->shared_twoway_price ?? 0 }}" class="input"></label>
      <label class="text-xs">Two-way min (no approval)<input name="shared_twoway_min" type="number" step="0.01" value="{{ $t->shared_twoway_min ?? '' }}" class="input" placeholder="blank = price"></label>
      <label class="text-xs">One-way price<input name="shared_oneway_price" type="number" step="0.01" value="{{ $t->shared_oneway_price ?? 0 }}" class="input"></label>
      <label class="text-xs">One-way min (no approval)<input name="shared_oneway_min" type="number" step="0.01" value="{{ $t->shared_oneway_min ?? '' }}" class="input" placeholder="blank = price"></label>
      <p class="sm:col-span-4 text-[11px] text-slate-500">Per person, total for the trip. The agent can switch the customer's direction on the booking (default set above).</p>
    </div>
    {!! $chk('allow_over_capacity', $t->allow_over_capacity ?? false, 'Allow exceeding vehicle capacity') !!}{!! $chk('requires_ticket', $t->requires_ticket ?? false, 'Ticket upload required') !!}{!! $chk('active', $t->active ?? true, 'Product active') !!}</div>
  <label class="text-xs sm:col-span-2">Pick-up rules<textarea name="pickup_rules" class="input">{{ $t->pickup_rules ?? '' }}</textarea></label><label class="text-xs sm:col-span-2">Drop-back rules<textarea name="drop_rules" class="input">{{ $t->drop_rules ?? '' }}</textarea></label>
  <label class="text-xs sm:col-span-2">Internal notes (shown to agents)<textarea name="notes" class="input">{{ $t->notes ?? '' }}</textarea></label><label class="text-xs sm:col-span-2">Product terms<textarea name="terms" class="input">{{ $t->terms ?? '' }}</textarea></label>
  <div class="sm:col-span-4"><button class="btn-gold">{{ $t ? 'Save product' : 'Create product' }}</button></div></form>
@if($t)
<section class="card mt-5 space-y-3"><div class="card-title">Options / categories, prices & minimum prices</div>
  @foreach($options->concat([null]) as $o)<form method="post" action="{{ route('tours.option', $t->id) }}" class="grid gap-2 rounded-lg border p-3 sm:grid-cols-6 {{ $o ? '' : 'border-dashed border-gold-500' }}">@csrf<input type="hidden" name="option_id" value="{{ $o->id ?? '' }}">
    <label class="text-xs sm:col-span-3">Option name<input name="name" value="{{ $o->name ?? '' }}" required class="input"></label>
    <label class="text-xs sm:col-span-2">Pricing method<select name="pricing_method" class="input">@foreach(['per_person' => 'Per person (adult/child/infant)', 'per_vehicle' => 'Per vehicle (private)', 'per_group' => 'Per group (flat)', 'per_hour' => 'Per hour (yacht)', 'per_unit' => 'Per unit (jet ski)'] as $k => $l)<option value="{{ $k }}" @selected(($o->pricing_method ?? 'per_person') === $k)>{{ $l }}</option>@endforeach</select></label>
    <label class="text-xs">Sort<input name="sort" type="number" value="{{ $o->sort ?? 0 }}" class="input"></label>
    @foreach(['adult' => 'Adult', 'child' => 'Child', 'infant' => 'Infant', 'group' => 'Group / per-vehicle extra'] as $k => $l)<label class="text-xs">{{ $l }} price<input name="{{ $k }}_price" type="number" step="0.01" value="{{ $o->{$k.'_price'} ?? 0 }}" class="input"></label>@endforeach
    <label class="text-xs">Per-vehicle one-way price<input name="group_oneway_price" type="number" step="0.01" value="{{ $o->group_oneway_price ?? 0 }}" class="input" placeholder="0 = same as two-way"></label>
    <div class="sm:col-span-6 grid gap-2 rounded-lg border border-sky-200 bg-sky-50 p-2 sm:grid-cols-6"><div class="text-xs font-semibold text-sky-900 sm:col-span-6">Hourly (yacht) settings — used when Pricing method = Per hour (yacht)</div><label class="text-xs">Max capacity (A+C+I)<input name="capacity" type="number" min="0" value="{{ $o->capacity ?? '' }}" class="input" placeholder="e.g. 12"></label><label class="text-xs">Hourly rate<input name="hourly_rate" type="number" step="0.01" value="{{ $o->hourly_rate ?? 0 }}" class="input"></label><label class="text-xs">Prime hourly rate<input name="prime_hourly_rate" type="number" step="0.01" value="{{ $o->prime_hourly_rate ?? 0 }}" class="input" placeholder="0 = no prime"></label><label class="text-xs">Prime start<input name="prime_start" type="time" value="{{ $o->prime_start ?? '' }}" class="input"></label><label class="text-xs">Prime end<input name="prime_end" type="time" value="{{ $o->prime_end ?? '' }}" class="input"></label><label class="text-xs">Min hours (this yacht)<input name="min_hours" type="number" min="0" value="{{ $o->min_hours ?? '' }}" class="input" placeholder="blank = product default"></label><p class="sm:col-span-6 text-[11px] text-slate-500">Charged per hour. Prime hours (e.g. 17:00–19:00) use the prime rate. Capacity counts Adults + Children + Infants.</p></div>
    <div class="sm:col-span-6 grid gap-2 rounded-lg border border-teal-200 bg-teal-50 p-2 sm:grid-cols-6"><div class="text-xs font-semibold text-teal-900 sm:col-span-6">Per-unit (jet ski) settings — used when Pricing method = Per unit (jet ski)</div>
      <label class="text-xs">Block minutes<input name="unit_minutes" type="number" min="0" value="{{ $o->unit_minutes ?? '' }}" class="input" placeholder="e.g. 20 or 30"></label>
      <label class="text-xs">Price per unit<input name="unit_price" type="number" step="0.01" value="{{ $o->unit_price ?? 0 }}" class="input"></label>
      <label class="text-xs">Capacity per unit (A+C+I)<input name="capacity" type="number" min="0" value="{{ $o->capacity ?? '' }}" class="input" placeholder="optional"></label>
      <p class="sm:col-span-6 text-[11px] text-slate-500">Sold in fixed blocks (e.g. 20 min). The agent enters the number of units; total = units × price. Make one option per duration (20 min, 30 min). Capacity, if set, is per unit.</p></div>
    <label class="text-xs">Ticket type<input name="ticket_type" value="{{ $o->ticket_type ?? '' }}" class="input"></label><label class="text-xs">Ticket category<input name="ticket_category" value="{{ $o->ticket_category ?? '' }}" class="input"></label>
    <div class="grid gap-2 rounded-lg bg-amber-50 p-2 sm:col-span-6 sm:grid-cols-4"><div class="text-xs font-semibold text-amber-900 sm:col-span-4">Lowest price allowed without approval (blank = listed price)</div>
      @foreach(['adult', 'child', 'infant', 'group'] as $k)<label class="text-xs">Min {{ $k }}<input name="min_{{ $k }}_price" type="number" step="0.01" value="{{ $o->{'min_'.$k.'_price'} ?? '' }}" class="input"></label>@endforeach<label class="text-xs">Min one-way (per vehicle)<input name="min_group_oneway" type="number" step="0.01" value="{{ $o->min_group_oneway ?? '' }}" class="input"></label><label class="text-xs">Min hourly rate (yacht)<input name="min_hourly_rate" type="number" step="0.01" value="{{ $o->min_hourly_rate ?? '' }}" class="input"></label><label class="text-xs">Min price per unit (jet ski)<input name="min_unit_price" type="number" step="0.01" value="{{ $o->min_unit_price ?? '' }}" class="input"></label></div>
    <div class="flex flex-wrap items-center gap-4 sm:col-span-6"><span class="lbl mb-0">Allowed:</span>@foreach(['adult' => 'Adults', 'child' => 'Children', 'infant' => 'Infants'] as $k => $l)<label class="flex items-center gap-2 text-sm"><input type="checkbox" name="{{ $k }}_allowed" value="1" @checked($o->{$k.'_allowed'} ?? true)> {{ $l }}</label>@endforeach<label class="flex items-center gap-2 text-sm"><input type="checkbox" name="active" value="1" @checked($o->active ?? true)> Active</label></div>
    <label class="text-xs sm:col-span-3">Description<input name="description" value="{{ $o->description ?? '' }}" class="input"></label><label class="text-xs sm:col-span-3">Restriction instruction (shown to agent)<input name="restriction_note" value="{{ $o->restriction_note ?? '' }}" class="input"></label>
    <div class="flex gap-2 sm:col-span-6"><button class="{{ $o ? 'btn-outline' : 'btn-gold' }} btn-sm">{{ $o ? 'Save option' : '+ Add option' }}</button>@if($o)@include('partials.delete', ['entity' => 'option', 'id' => $o->id, 'what' => 'option '.$o->name])@endif</div></form>@endforeach
</section>
<section class="card mt-5 space-y-2"><div class="card-title">Add-ons</div>
  @foreach($addons->concat([null]) as $a)<form method="post" action="{{ route('tours.addon', $t->id) }}" class="grid items-end gap-2 rounded-lg border p-2 sm:grid-cols-7 {{ $a ? '' : 'border-dashed border-gold-500' }}">@csrf<input type="hidden" name="addon_id" value="{{ $a->id ?? '' }}">
    <label class="text-xs sm:col-span-2">Add-on<input name="name" value="{{ $a->name ?? '' }}" required class="input"></label>
    <label class="text-xs">Pricing<select name="pricing_method" class="input">@foreach(['per_person','per_unit','per_vehicle','per_group'] as $m)<option value="{{ $m }}" @selected(($a->pricing_method ?? 'per_unit') === $m)>{{ lbl($m) }}</option>@endforeach</select></label>
    <label class="text-xs">Price<input name="price" type="number" step="0.01" value="{{ $a->price ?? 0 }}" class="input"></label><label class="text-xs">Min price (no approval)<input name="min_price" type="number" step="0.01" value="{{ $a->min_price ?? '' }}" class="input"></label>
    <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="active" value="1" @checked($a->active ?? true)> Active</label>
    <div class="flex gap-1"><button class="btn-outline btn-sm">{{ $a ? 'Save' : '+ Add' }}</button>@if($a)@include('partials.delete', ['entity' => 'addon', 'id' => $a->id, 'what' => 'add-on '.$a->name])@endif</div></form>@endforeach
</section>
@if(($t->product_type ?? '') === 'ticket')
<section class="card mt-5 space-y-2" x-data="{ timed: '{{ $t->ticket_timing ?? 'anytime' }}' }">
  <div class="card-title">Ticket admission times</div>
  <p class="text-sm text-slate-600">Set the product's <b>Ticket timing</b> above and save first. For <b>Specific time slot</b> tickets you may list the selectable entry times below (agents can also type a custom time when booking). <b>Anytime</b> tickets need no times – admission is valid any time on the chosen date.</p>
  @if(($t->ticket_timing ?? 'anytime') === 'time_slot')
    <datalist id="opt-cats-{{ $t->id }}">@foreach($options->pluck('ticket_category')->filter()->unique() as $cat)<option value="{{ $cat }}"></option>@endforeach</datalist>
    @foreach($ticketSlots->concat([null]) as $s)<form method="post" action="{{ route('tours.ticketslot', $t->id) }}" class="grid items-end gap-2 rounded-lg border p-2 sm:grid-cols-7 {{ $s ? '' : 'border-dashed border-gold-500' }}">@csrf<input type="hidden" name="ticket_slot_id" value="{{ $s->id ?? '' }}">
      <label class="text-xs">Entry time<input name="slot_time" type="time" value="{{ $s->slot_time ?? '' }}" required class="input"></label>
      <label class="text-xs sm:col-span-2">Label (optional)<input name="label" value="{{ $s->label ?? '' }}" placeholder="e.g. Prime Hours" class="input"></label>
      <label class="text-xs">Category<input name="category" value="{{ $s->category ?? '' }}" list="opt-cats-{{ $t->id }}" placeholder="match option" class="input"></label>
      <label class="text-xs">Sort<input name="sort" type="number" value="{{ $s->sort ?? 0 }}" class="input"></label>
      <label class="flex min-h-11 items-center gap-2 text-sm"><input type="checkbox" name="is_prime" value="1" @checked($s->is_prime ?? false) class="h-5 w-5"> Prime</label>
      <div class="flex items-center gap-2"><label class="flex min-h-11 items-center gap-2 text-sm"><input type="checkbox" name="active" value="1" @checked($s->active ?? true) class="h-5 w-5"> Active</label>
        <button class="{{ $s ? 'btn-outline' : 'btn-gold' }} btn-sm">{{ $s ? 'Save' : '+ Add time' }}</button>@if($s)@include('partials.delete', ['entity' => 'ticket_slot', 'id' => $s->id, 'what' => 'entry time '.$s->slot_time])@endif</div>
    </form>@endforeach
  @else
    <p class="rounded-lg bg-slate-50 p-3 text-sm text-slate-600">This ticket is set to <b>Anytime</b>. No entry times are needed. Change <b>Ticket timing</b> to <b>Specific time slot</b> and save to add entry times.</p>
  @endif
</section>
@endif

<section class="card mt-5 space-y-2"><div class="card-title">Shared transfer pick-up / drop-back windows</div>
  @foreach($slots->concat([null]) as $s)<form method="post" action="{{ route('tours.slot', $t->id) }}" class="grid items-end gap-2 rounded-lg border p-2 sm:grid-cols-6 {{ $s ? '' : 'border-dashed border-gold-500' }}">@csrf<input type="hidden" name="slot_id" value="{{ $s->id ?? '' }}">
    @foreach(['pickup_start' => 'Pick-up from', 'pickup_end' => 'Pick-up to', 'drop_start' => 'Drop-back from', 'drop_end' => 'Drop-back to'] as $k => $l)<label class="text-xs">{{ $l }}<input type="time" name="{{ $k }}" value="{{ $s->$k ?? '' }}" class="input"></label>@endforeach
    <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="active" value="1" @checked($s->active ?? true)> Active</label>
    <div class="flex gap-1"><button class="btn-outline btn-sm">{{ $s ? 'Save' : '+ Add slot' }}</button>@if($s)@include('partials.delete', ['entity' => 'slot', 'id' => $s->id, 'what' => 'this time slot'])@endif</div></form>@endforeach
</section>
<section class="card mt-5"><div class="card-title">Product-specific private vehicles (otherwise the default list is used)</div>@foreach($vehicles->concat([null]) as $v)@include('tours.vehicle', ['v' => $v, 'tourId' => $t->id])@endforeach</section>
@endif
@endsection
