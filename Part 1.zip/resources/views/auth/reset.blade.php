@php $company = \App\Support\Settings::get('company'); @endphp
<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Reset password – {{ $company['name'] }}</title>
<link rel="icon" href="{{ url('/branding/favicon') }}"><link rel="stylesheet" href="{{ asset('css/app.css') }}">
    @include('partials.pwa-head')</head>
<body class="grid min-h-screen place-items-center bg-gradient-to-br from-navy-900 via-navy-800 to-navy-700 px-4">
<div class="w-full max-w-md">
    <div class="mb-6 text-center text-white">
        <img src="{{ url('/branding/logo') }}" alt="" class="mx-auto mb-3 h-16 w-16 rounded-2xl bg-white object-contain">
        <h1 class="text-2xl font-bold">{{ $company['name'] }}</h1><p class="text-sm text-gold-400">Choose a new password</p>
    </div>
    <form method="post" action="{{ route('password.update') }}" class="card space-y-4">@csrf
        <input type="hidden" name="token" value="{{ $token }}">
        @if(session('error'))<p class="rounded-lg bg-red-50 p-2 text-sm text-red-700">{{ session('error') }}</p>@endif
        @if($errors->any())<p class="rounded-lg bg-red-50 p-2 text-sm text-red-700">{{ $errors->first() }}</p>@endif
        <div><label class="lbl">Email</label><input name="email" type="email" value="{{ old('email', $email) }}" class="input" required></div>
        <div><label class="lbl">New password</label><input name="password" type="password" minlength="8" class="input" required autocomplete="new-password"></div>
        <div><label class="lbl">Confirm new password</label><input name="password_confirmation" type="password" minlength="8" class="input" required autocomplete="new-password"></div>
        <button class="btn-primary w-full">Reset password</button>
        <p class="text-center text-sm"><a href="{{ route('login') }}" class="text-navy-700 underline">← Back to sign in</a></p>
    </form>
</div></body></html>
