@php $company = \App\Support\Settings::get('company'); @endphp
<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Forgot password – {{ $company['name'] }}</title>
<link rel="icon" href="{{ url('/branding/favicon') }}"><link rel="manifest" href="{{ asset('manifest.webmanifest') }}?v=1.1.3-hostinger"><meta name="theme-color" content="#111c37"><link rel="apple-touch-icon" sizes="180x180" href="{{ asset('icons/apple-touch-icon.png') }}"><link rel="icon" type="image/png" sizes="192x192" href="{{ asset('icons/icon-192.png') }}"><link rel="stylesheet" href="{{ asset('css/app.css') }}"></head>
<body class="grid min-h-screen place-items-center bg-gradient-to-br from-navy-900 via-navy-800 to-navy-700 px-4">
<div class="w-full max-w-md">
  <div class="mb-6 text-center text-white"><img src="{{ url('/branding/logo') }}" alt="" class="mx-auto mb-3 h-16 w-16 rounded-2xl bg-white object-contain"><h1 class="text-2xl font-bold">{{ $company['name'] }}</h1><p class="text-sm text-gold-400">Password recovery</p></div>
  <form method="post" action="{{ route('password.email') }}" class="card space-y-4">@csrf
    <div><h2 class="text-lg font-semibold">Forgot your password?</h2><p class="mt-1 text-sm text-slate-600">Enter your staff username or registered email. If it matches an active account, we’ll send a one-time reset link to the email on file.</p></div>
    @if(session('ok'))<p class="rounded-lg bg-emerald-50 p-3 text-sm text-emerald-800">{{ session('ok') }}</p>@endif
    @if(session('error'))<p class="rounded-lg bg-red-50 p-2 text-sm text-red-700">{{ session('error') }}</p>@endif
    @if($errors->any())<p class="rounded-lg bg-red-50 p-2 text-sm text-red-700">{{ $errors->first() }}</p>@endif
    <div><label class="lbl">Username or registered email</label><input name="identity" value="{{ old('identity') }}" class="input" required autofocus autocomplete="username"></div>
    <button class="btn-primary w-full">Email me a reset link</button>
    <p class="text-center text-sm"><a class="text-navy-700 underline" href="{{ route('login') }}">Back to sign in</a></p>
  </form>
  <p class="mt-4 text-center text-xs text-slate-300">{{ $company['phone'] }} · {{ $company['email'] }}</p>
</div></body></html>
