@php $company = \App\Support\Settings::get('company'); @endphp
<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="referrer" content="no-referrer"><title>Reset password – {{ $company['name'] }}</title>
<link rel="icon" href="{{ url('/branding/favicon') }}"><link rel="manifest" href="{{ asset('manifest.webmanifest') }}?v=1.1.3-hostinger"><meta name="theme-color" content="#111c37"><link rel="apple-touch-icon" sizes="180x180" href="{{ asset('icons/apple-touch-icon.png') }}"><link rel="icon" type="image/png" sizes="192x192" href="{{ asset('icons/icon-192.png') }}"><link rel="stylesheet" href="{{ asset('css/app.css') }}"></head>
<body class="grid min-h-screen place-items-center bg-gradient-to-br from-navy-900 via-navy-800 to-navy-700 px-4">
<div class="w-full max-w-md">
  <div class="mb-6 text-center text-white"><img src="{{ url('/branding/logo') }}" alt="" class="mx-auto mb-3 h-16 w-16 rounded-2xl bg-white object-contain"><h1 class="text-2xl font-bold">{{ $company['name'] }}</h1><p class="text-sm text-gold-400">Set a new password</p></div>
  <div class="card space-y-4">
    @if(!$valid)
      <div class="rounded-lg bg-red-50 p-3 text-sm text-red-700">This reset link is invalid, expired, or already used. Request a new link to continue.</div>
      <a class="btn-primary w-full" href="{{ route('password.request') }}">Request a new reset link</a>
    @else
      <div><h2 class="text-lg font-semibold">Choose a new password</h2><p class="mt-1 text-sm text-slate-600">Resetting the account for <b>{{ $email }}</b>. The link can only be used once.</p></div>
      @if($errors->any())<p class="rounded-lg bg-red-50 p-2 text-sm text-red-700">{{ $errors->first() }}</p>@endif
      <form method="post" action="{{ route('password.update') }}" class="space-y-4">@csrf<input type="hidden" name="token" value="{{ $token }}">
        <div><label class="lbl">New password (minimum 8 characters)</label><input type="password" name="password" minlength="8" required class="input" autocomplete="new-password"></div>
        <div><label class="lbl">Confirm new password</label><input type="password" name="password_confirmation" minlength="8" required class="input" autocomplete="new-password"></div>
        <button class="btn-primary w-full">Reset password</button>
      </form>
    @endif
    <p class="text-center text-sm"><a class="text-navy-700 underline" href="{{ route('login') }}">Back to sign in</a></p>
  </div>
</div></body></html>
