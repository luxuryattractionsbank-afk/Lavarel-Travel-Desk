/* Live price preview (mirrors app/Support/Pricing.php – the server recalculates on save). */
const r2 = (n) => Math.round((Number(n) + Number.EPSILON) * 100) / 100;
const num = (v) => (v === '' || v === null || v === undefined || isNaN(Number(v))) ? null : r2(v);
function addMin(t, m) { const x = /^(\d{1,2}):(\d{2})/.exec(t || ''); if (!x) return ''; const v = (((+x[1] * 60 + +x[2] + m) % 1440) + 1440) % 1440; return String(Math.floor(v / 60)).padStart(2, '0') + ':' + String(v % 60).padStart(2, '0'); }

function laCalc(tour, option, it) {
  const errors = [], lines = [], approval = [];
  const adults = Math.max(0, +it.adults || 0), children = Math.max(0, +it.children || 0), infants = Math.max(0, +it.infants || 0), pax = adults + children + infants;
  if (!it.tour_date) errors.push('Tour date is required.');
  else if ((tour.available_days || []).length < 7 && !tour.available_days.includes(new Date(it.tour_date + 'T00:00:00Z').getUTCDay())) errors.push(tour.name + ' does not operate on the selected weekday.');
  let entry = null, categoryFix = null;
  if (tour.product_type === 'ticket' && tour.ticket_timing === 'time_slot') {
    entry = (it.entry_time || '').trim();
    if (!entry) errors.push('This ticket needs a specific entry time (time slot).');
  }
  const dir = it.transfer_direction === 'one_way' ? 'one_way' : 'two_way';
  if (pax < 1) errors.push('At least one passenger is required.');
  if (adults + children < 1 && infants > 0) errors.push('Infants must be accompanied by an adult or child.');
  if (!option) errors.push('Select an option/category.');
  let listB = 0, soldB = 0, minB = 0;
  if (option) {
    [['adult', adults, 'Adults'], ['child', children, 'Children'], ['infant', infants, 'Infants']].forEach(([k, q, n]) => { if (q > 0 && !option[k + '_allowed']) errors.push(`${n} are not sold under "${option.name}". ${option.restriction_note || ''}`.trim()); });
    if (option.pricing_method === 'per_person') {
      [['adult', adults, 'Adult'], ['child', children, 'Child'], ['infant', infants, 'Infant']].forEach(([k, q, n]) => {
        if (!q) return; const list = +option[k + '_price']; lines.push({ label: `${option.name} – ${n}`, qty: q, unit: list, total: r2(q * list) });
        const c = num(it[k + '_price']); const unit = c ?? list; const floor = Math.min(option['min_' + k + '_price'] ?? list, list);
        listB += q * list; soldB += q * unit; minB += q * floor; if (unit < floor - 0.004) approval.push(`${n} ${unit.toFixed(2)} is below the minimum ${floor.toFixed(2)}`);
      });
    } else if (option.pricing_method === 'per_group' || (option.pricing_method === 'per_vehicle' && (+option.group_price > 0 || +(option.group_oneway_price || 0) > 0))) {
      const isVeh = option.pricing_method === 'per_vehicle';
      const cnt = isVeh ? Math.max(1, +it.vehicle_count || 1) : 1;
      const gp2 = +option.group_price, gpOne = +(option.group_oneway_price || 0);
      const gp = (isVeh && dir === 'one_way' && gpOne > 0) ? gpOne : gp2;
      const minTwo = option.min_group_price ?? gp2;
      const minOne = (option.min_group_oneway ?? null) !== null ? option.min_group_oneway : (gpOne > 0 ? gpOne : minTwo);
      const floorG = Math.min((isVeh && dir === 'one_way') ? minOne : minTwo, gp);
      const dirLbl = isVeh ? ' (' + (dir === 'one_way' ? 'One Way' : 'Two Way') + ')' : '';
      lines.push({ label: option.name + (isVeh ? ' – Per Vehicle' + dirLbl : ' – Group Charge'), qty: cnt, unit: gp, total: r2(cnt * gp) });
      listB += cnt * gp; soldB += cnt * gp; minB += cnt * floorG;
    }
    else if (option.pricing_method === 'per_hour') {
      const rate = +(option.hourly_rate || 0), primeRate = +(option.prime_hourly_rate || 0);
      const cap = (option.capacity ?? null); const minFloor = (option.min_hourly_rate ?? null);
      const minHours = Math.max(+(option.min_hours || 0), +(tour.min_booking_hours || 0));
      const hours = Math.max(0, parseInt(it.booking_hours || 0, 10) || 0);
      const start = (it.entry_time || '').trim();
      if (cap !== null && cap !== undefined && pax > +cap) { if (!tour.allow_over_capacity) errors.push(`Passengers (${pax}) exceed ${option.name} maximum capacity of ${cap}.`); }
      if (!start) errors.push('Yacht start time is required.');
      if (hours < 1) errors.push('Enter the number of hours.');
      else if (minHours > 0 && hours < minHours) errors.push(`Minimum booking is ${minHours} hour(s) for ${option.name}.`);
      const toMin = (t) => { const m = /^(\d{1,2}):(\d{2})/.exec(t || ''); return m ? (+m[1]) * 60 + (+m[2]) : null; };
      const ps = toMin(option.prime_start), pe = toMin(option.prime_end), st = toMin(start);
      let normalHours = 0, primeHours = 0;
      for (let h = 0; h < hours; h++) {
        let isPrime = false;
        if (primeRate > 0 && ps !== null && pe !== null && st !== null) { const seg = (st + h * 60) % 1440; isPrime = pe > ps ? (seg >= ps && seg < pe) : (seg >= ps || seg < pe); }
        if (isPrime) primeHours++; else normalHours++;
      }
      if (normalHours > 0) { lines.push({ label: `${option.name} – ${normalHours} hr @ ${rate.toFixed(2)}`, qty: normalHours, unit: rate, total: r2(normalHours * rate) }); const fN = minFloor !== null && minFloor !== undefined ? Math.min(+minFloor, rate) : rate; listB += normalHours * rate; soldB += normalHours * rate; minB += normalHours * fN; }
      if (primeHours > 0) { lines.push({ label: `${option.name} – ${primeHours} prime hr @ ${primeRate.toFixed(2)}`, qty: primeHours, unit: primeRate, total: r2(primeHours * primeRate) }); const fP = minFloor !== null && minFloor !== undefined ? Math.min(+minFloor, primeRate) : primeRate; listB += primeHours * primeRate; soldB += primeHours * primeRate; minB += primeHours * fP; }
    }
    else if (option.pricing_method === 'per_unit') {
      const unitPrice = +(option.unit_price || 0), unitMin = (option.min_unit_price ?? null), mins = +(option.unit_minutes || 0);
      const cap = (option.capacity ?? null);
      const units = Math.max(0, parseInt(it.booking_units || 0, 10) || 0);
      if (units < 1) errors.push('Enter the number of units.');
      if (cap !== null && cap !== undefined && +cap > 0 && pax > +cap * Math.max(1, units)) { if (!tour.allow_over_capacity) errors.push(`Passengers (${pax}) exceed capacity of ${+cap * Math.max(1, units)} for ${units} unit(s) of ${option.name}.`); }
      if (units > 0) { const lbl = mins > 0 ? `${mins} min` : 'unit'; lines.push({ label: `${option.name} – ${units} × ${lbl} @ ${unitPrice.toFixed(2)}`, qty: units, unit: unitPrice, total: r2(units * unitPrice) }); const fU = unitMin !== null && unitMin !== undefined ? Math.min(+unitMin, unitPrice) : unitPrice; listB += units * unitPrice; soldB += units * unitPrice; minB += units * fU; }
    }
  }
  if (option && tour.product_type === 'ticket' && tour.ticket_timing === 'time_slot') {
    const norm = (v) => String(v || '').trim().toLowerCase();
    const start = (it.entry_time || '').trim();
    const optCat = norm(option.ticket_category);
    let timeCat = null, timeCatLabel = null;
    (tour.ticket_slots || []).forEach((sl) => { if (!timeCat && start && String(sl.slot_time).trim() === start && String(sl.category || '').trim()) { timeCat = norm(sl.category); timeCatLabel = String(sl.category).trim(); } });
    if (start && timeCat && optCat && timeCat !== optCat) {
      let suggest = null; (tour.options || []).forEach((o2) => { if (!suggest && (o2.active === undefined || o2.active) && norm(o2.ticket_category) === timeCat) suggest = { id: o2.id, name: o2.name }; });
      categoryFix = { time_category: timeCatLabel, suggest };
      const msg = `The selected time ${start} is a "${timeCatLabel}" slot but the chosen option is "${option.ticket_category || ''}".` + (suggest ? ` Switch to "${suggest.name}".` : ' Choose the matching option or a valid time.');
      if (window.__enforceTimeCat) errors.push(msg); else categoryFix.warn = msg;
    }
  }
  const privReq = option && option.pricing_method === 'per_vehicle', type = privReq ? 'private' : it.transfer_type;
  let pickup = it.pickup_time || null, drop = null;
  if (type === 'none' && !tour.no_transfer_allowed && tour.product_type === 'tour') errors.push('This tour requires a transfer (shared or private).');
  if (type === 'shared') {
    const s = tour.slots.find((x) => +x.id === +it.slot_id); if (tour.slots.length && !s) errors.push('Select a pickup time window.');
    if (s) { pickup = s.pickup_start + '–' + s.pickup_end; if (dir === 'two_way') drop = s.drop_start ? s.drop_start + '–' + (s.drop_end || s.drop_start) : (tour.duration_minutes ? addMin(s.pickup_start, tour.duration_minutes) + '–' + addMin(s.pickup_end, tour.duration_minutes) : null); }
    if (tour.shared_transfer_pricing === 'extra') {
      const twoway = dir === 'two_way';
      const price = +(twoway ? (tour.shared_twoway_price || 0) : (tour.shared_oneway_price || 0));
      const minRef = twoway ? tour.shared_twoway_min : tour.shared_oneway_min;
      const floorT = Math.min((minRef ?? null) !== null ? minRef : price, price);
      if (price > 0) { const q = adults + children; lines.push({ label: 'Shared Transfer (' + (twoway ? 'Two Way' : 'One Way') + ') – per person', qty: q, unit: price, total: r2(q * price) }); listB += q * price; soldB += q * price; minB += q * floorT; }
    }
  }
  if (type === 'private') {
    const v = tour.vehicles.find((x) => +x.id === +it.vehicle_id), cnt = Math.max(1, +it.vehicle_count || 1);
    if (!v) errors.push('Select a private vehicle.');
    else { if (pax > v.capacity * cnt && !tour.allow_over_capacity) errors.push(`Passengers (${pax}) exceed ${v.name} capacity of ${v.capacity * cnt}.`); lines.push({ label: `Private Transfer – ${v.name} – Group Charge`, qty: cnt, unit: +v.price, total: r2(cnt * v.price) }); }
    if (dir === 'two_way') {
      const manualDrop = (it.drop_time || '').trim();
      if (manualDrop) drop = manualDrop;
      else if (tour.closing_time) drop = tour.closing_time;
      else if (pickup && tour.duration_minutes && /^\d{1,2}:\d{2}$/.test(pickup)) drop = addMin(pickup, tour.duration_minutes);
    }
  }
  (tour.addons || []).forEach((a) => {
    const q = +(it.addons[a.id] || 0); if (q <= 0) return; const qty = a.pricing_method === 'per_group' ? 1 : q;
    if (a.pricing_method === 'per_person' && q > pax) errors.push(`${a.name}: quantity (${q}) cannot exceed passengers (${pax}).`);
    const list = +a.price, c = num(it.addon_prices[a.id]), unit = c ?? list, floor = Math.min(a.min_price ?? list, list);
    listB += qty * list; soldB += qty * unit; minB += qty * floor; if (unit < floor - 0.004) approval.push(`${a.name} ${unit.toFixed(2)} is below the minimum ${floor.toFixed(2)}`);
    lines.push({ label: 'Add-on: ' + a.name + (c !== null && Math.abs(c - list) > 0.004 ? ' – agreed ' + unit.toFixed(2) : ''), qty, unit: list, total: r2(qty * list) });
  });
  const standard = r2(lines.reduce((s, l) => s + l.total, 0)), sub = r2(standard - listB + soldB), min = r2(standard - listB + minB);
  const agreed = num(it.agreed_price), disc = Math.max(0, +it.discount || 0); let total = sub, appr = approval;
  if (agreed !== null) { total = agreed; appr = []; } else if (disc > 0) { if (disc > sub) errors.push('Discount cannot exceed the price.'); total = r2(sub - disc); }
  if (total < min - 0.004) appr.push(`Total ${total.toFixed(2)} is below the minimum allowed ${min.toFixed(2)}`);
  return { lines, standard, total: r2(total), min, discount: r2(standard - total), errors, approval: appr, pickup, drop, pax, type, entry, categoryFix };
}

function bookingForm(D) {
  const blankItem = () => ({ key: Math.random(), id: null, tour_id: '', option_id: '', tour_date: D.today, adults: 2, children: 0, infants: 0, transfer_type: 'shared', transfer_direction: 'two_way', vehicle_id: '', vehicle_count: 1, slot_id: '', entry_time: '', entry_slot_id: '', booking_hours: '', booking_units: '', pickup_time: '', drop_time: '', pickup_location: '', drop_location: '', addons: {}, addon_prices: {}, adult_price: '', child_price: '', infant_price: '', discount: '', agreed_price: '', notes: '', approval_id: null, approval: null, search: '', open: false });
  window.__enforceTimeCat = !!D.enforceTimeCat;
  return {
    D, saving: false, error: '', payError: '',
    customer: D.initial?.customer || { title: 'Mr', name: '', hotel: '', room_number: '', email: '', notes: '', contacts: [{ number: '', call: true, whatsapp: true, telegram: false, viber: false, other: '' }] },
    travel_desk: D.initial?.travel_desk ?? (D.desks[0] || ''), sales_person_id: D.initial?.sales_person_id || D.me.id, balance_collection: D.initial?.balance_collection || 'travel_desk',
    notes: D.initial?.notes || '', terms_id: D.initial?.terms_id || (D.terms.find((t) => t.is_default)?.id ?? ''), terms_override: D.initial?.terms_override || '',
    items: (D.initial?.items || [null]).map((x) => Object.assign(blankItem(), x || {})), pays: [],
    draft: { method: 'cash', currency: D.base, amount: '', reference: '', provider: D.pay.providers[0] || '', card_type: '', is_deposit: false, item_index: '', change_currency: D.base, change_amount: '', notes: '' },
    newItem() { return blankItem() },
    tourOf(it) { return D.catalog.find((t) => +t.id === +it.tour_id) },
    optionOf(it) { const t = this.tourOf(it); return t ? t.options.find((o) => +o.id === +it.option_id) : null },
    slotsFor(it) { const t = this.tourOf(it); if (!t) return []; const all = t.ticket_slots || []; const o = this.optionOf(it); const cat = (o && o.ticket_category ? String(o.ticket_category).trim().toLowerCase() : ''); if (!cat) return all; const m = all.filter((s) => String(s.category || '').trim().toLowerCase() === cat); const generic = all.filter((s) => !String(s.category || '').trim()); return m.length ? m.concat(generic) : all; },
    res(it) { const t = this.tourOf(it); return t ? laCalc(t, this.optionOf(it), it) : null },
    get grand() { return r2(this.items.reduce((s, it) => s + (this.res(it)?.total || 0), 0)) },
    rate(c) { return +(D.currencies.find((x) => x.code === c)?.rate_to_base || 1) },
    settle(p, bal) { const tendered = r2(p.amount * this.rate(p.currency)), applied = r2(Math.min(tendered, Math.max(0, bal))), over = r2(Math.max(0, tendered - applied)); let ca = 0, cb = 0; if (over > 0) { const cr = this.rate(p.change_currency || D.base), sug = r2(over / cr); ca = p.change_amount === '' ? (over <= D.pay.tolerance + 0.0001 ? 0 : sug) : r2(p.change_amount); cb = r2(ca * cr); return { tendered, applied, over, sug, ca, cb, kept: r2(over - cb) } } return { tendered, applied, over, sug: 0, ca: 0, cb: 0, kept: 0 } },
    get paid() { let run = r2(this.grand - (D.initial?.paid || 0)), tot = 0; this.pays.forEach((p) => { const s = this.settle(p, run); run = r2(run - s.applied); tot += s.applied }); return r2(tot + (D.initial?.paid || 0)) },
    get balance() { return r2(Math.max(0, this.grand - this.paid)) },
    balIn(c) { return r2(Math.ceil(this.balance / this.rate(c) * 100 - 1e-6) / 100) },
    get draftSettle() { return this.settle({ ...this.draft, amount: +this.draft.amount || 0 }, this.balance) },
    matches(it) { const q = it.search.trim().toLowerCase(); const list = D.catalog.filter((t) => t.active || +t.id === +it.tour_id); if (!q) return list; const w = q.split(/\s+/); return list.filter((t) => w.every((x) => (t.name + ' ' + t.code_prefix + ' ' + t.options.map((o) => o.name).join(' ')).toLowerCase().includes(x))).sort((a, b) => (a.code_prefix.toLowerCase() === q ? -1 : 0) - (b.code_prefix.toLowerCase() === q ? -1 : 0)) },
    pickTour(it, t) { const o = t.options[0]; it.tour_id = t.id; it.option_id = o?.id || ''; it.search = ''; it.open = false; it.addons = {}; it.addon_prices = {}; it.adult_price = it.child_price = it.infant_price = ''; it.approval = null; it.approval_id = null;
      it.transfer_type = o?.pricing_method === 'per_vehicle' ? 'private' : (t.product_type === 'tour' ? (t.shared_available ? 'shared' : 'private') : (t.no_transfer_allowed ? 'none' : (t.shared_available ? 'shared' : 'private')));
      it.transfer_direction = t.default_direction; it.slot_id = t.slots[0]?.id || ''; it.vehicle_id = ''; it.pickup_location = it.drop_location = this.customer.hotel;
      it.entry_slot_id = ''; it.entry_time = (t.product_type === 'ticket' && t.ticket_timing === 'time_slot' && t.ticket_slots && t.ticket_slots[0]) ? t.ticket_slots[0].slot_time : '';
      it.booking_hours = (o && o.pricing_method === 'per_hour') ? Math.max(+(o.min_hours || 0), +(t.min_booking_hours || 0), 1) : '';
      it.booking_units = (o && o.pricing_method === 'per_unit') ? 1 : ''; },
    sig(it) { return [it.tour_id, it.option_id, it.adults, it.children, it.infants].join('|') },
    approvalOk(it) { const r = this.res(it); if (!r?.approval.length || D.canOverride) return true; if (it.id && D.initial && it.approval === null && it.approval_id) return true; return it.approval?.status === 'approved' && it.approval.sig === this.sig(it) && r.total >= it.approval.total - 0.01 },
    async requestApproval(it, reason) {
      this.error = ''; const r = await fetch(D.urls.approval, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': D.csrf, Accept: 'application/json' }, body: JSON.stringify({ item: this.payloadItem(it), customer_name: this.customer.title + ' ' + this.customer.name, reason }) }).then((x) => x.json());
      if (r.error) { this.error = r.error; return } it.approval_id = r.id; it.approval = { status: 'pending', total: r.total, sig: this.sig(it) }; this.poll();
    },
    poll() { if (this._poll) return; this._poll = setInterval(async () => { const ids = this.items.filter((i) => i.approval?.status === 'pending').map((i) => i.approval_id); if (!ids.length) { clearInterval(this._poll); this._poll = null; return } const d = await fetch(D.urls.approvalStatus + '?ids=' + ids.join(',')).then((x) => x.json()); this.items.forEach((i) => { const m = (d.mine || []).find((x) => +x.id === +i.approval_id); if (m && i.approval && m.status !== i.approval.status) i.approval = { ...i.approval, status: m.status, note: m.decision_note, by: m.by } }) }, 4000) },
    addPay() { this.payError = ''; const s = this.draftSettle; if (!(+this.draft.amount > 0)) return this.payError = 'Enter an amount'; if (this.balance <= 0) return this.payError = 'Nothing due';
      if (this.draft.method === 'card' && D.pay.requireRef && !this.draft.reference) return this.payError = 'Card payments need a reference number';
      this.pays.push({ ...this.draft, amount: +this.draft.amount, change_amount: s.over > 0 ? s.ca : '' }); this.draft = { ...this.draft, amount: '', reference: '', is_deposit: false, change_amount: '', notes: '' } },
    payloadItem(it) { const o = {}; ['id', 'tour_id', 'option_id', 'tour_date', 'adults', 'children', 'infants', 'transfer_type', 'transfer_direction', 'vehicle_id', 'vehicle_count', 'slot_id', 'entry_time', 'entry_slot_id', 'booking_hours', 'booking_units', 'pickup_time', 'drop_time', 'pickup_location', 'drop_location', 'adult_price', 'child_price', 'infant_price', 'discount', 'agreed_price', 'notes', 'approval_id'].forEach((k) => o[k] = it[k]);
      o.addons = Object.entries(it.addons).filter(([, q]) => +q > 0).map(([k, q]) => ({ addon_id: +k, quantity: +q, price: it.addon_prices[k] ?? '' })); return o },
    async submit(status) {
      this.error = ''; const bad = this.items.findIndex((it) => !this.res(it) || this.res(it).errors.length); if (bad >= 0) return this.error = `Fix item ${bad + 1}: ` + (this.res(this.items[bad])?.errors.join(' ') || 'select a tour');
      const na = this.items.findIndex((it) => !this.approvalOk(it)); if (na >= 0) return this.error = `Item ${na + 1}: price is below the minimum – request approval and wait for it before saving.`;
      this.saving = true;
      const body = { customer: this.customer, travel_desk: this.travel_desk, sales_person_id: this.sales_person_id, balance_collection: this.balance_collection, notes: this.notes, terms_id: this.terms_id || null, terms_override: this.terms_override, status,
        items: this.items.map((it) => this.payloadItem(it)), payments: D.initial ? [] : this.pays, customer_signature: this.sigData('cust'), agent_signature: this.sigData('agent') };
      const r = await fetch(D.urls.save, { method: D.initial ? 'PUT' : 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': D.csrf, Accept: 'application/json' }, body: JSON.stringify(body) }).then((x) => x.json()).catch(() => ({ error: 'Network error – please try again.' }));
      this.saving = false; if (r.error) { this.error = r.error; window.scrollTo(0, document.body.scrollHeight); return } location.href = r.redirect;
    },
    sigData(id) { const c = document.getElementById('sig-' + id); return c && c.dataset.signed === '1' ? c.toDataURL('image/png') : null },
  };
}

function sigPad(el) {
  const ctx = el.getContext('2d'), ratio = window.devicePixelRatio || 1; el.width = el.offsetWidth * ratio; el.height = el.offsetHeight * ratio; ctx.scale(ratio, ratio); ctx.lineWidth = 2.2; ctx.lineCap = 'round'; ctx.strokeStyle = '#0f1a33';
  if (el.dataset.src) { const i = new Image(); i.onload = () => ctx.drawImage(i, 0, 0, el.offsetWidth, el.offsetHeight); i.src = el.dataset.src; el.dataset.signed = '1' }
  let d = false; const p = (e) => { const r = el.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top] };
  el.addEventListener('pointerdown', (e) => { d = true; el.setPointerCapture(e.pointerId); ctx.beginPath(); ctx.moveTo(...p(e)) });
  el.addEventListener('pointermove', (e) => { if (d) { ctx.lineTo(...p(e)); ctx.stroke(); el.dataset.signed = '1' } });
  ['pointerup', 'pointerleave'].forEach((ev) => el.addEventListener(ev, () => d = false));
  el.clear = () => { ctx.clearRect(0, 0, el.width, el.height); el.dataset.signed = '' };
}
