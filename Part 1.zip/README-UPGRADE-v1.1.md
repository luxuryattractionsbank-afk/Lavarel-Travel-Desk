# Travel Desk v1.1.0 — Time-slotted vs anytime tickets

## What's new
Tickets now support two admission types:
- **Specific time slot** (e.g. Burj Khalifa): the sales agent selects/enters an
  exact entry time on the booking. You can predefine selectable times (with an
  optional "Prime" star) per product; agents may also type a custom time.
- **Anytime on date** (e.g. Ski Dubai): admission is valid any time on the
  chosen date — no entry time needed.

The chosen entry time appears on the booking, the on-screen receipt and the PDF.

## How to upgrade (Hostinger) — no data loss
1. Back up your MySQL database and the `storage/` folder (as usual).
2. Upload this ZIP into the subdomain folder and extract it, overwriting files.
   KEEP your existing `.env` (it is not included in this ZIP).
3. Sign in as an administrator.
4. Go to **Settings → System** and click **Run database update**.
   This adds the new `ticket_slots` table and the `ticket_timing` / `entry_time`
   columns. Existing bookings, payments and staff records are kept.
5. Open **Tours & Products**, edit a ticket, set **Ticket timing**:
   - "Specific time slot" → save, then add the selectable entry times.
   - "Anytime on date" → nothing else to configure.

## How to use when booking
- Add a ticket line. If it is a time-slot ticket, an **Entry time** field appears
  (with quick-pick buttons for any predefined times). It is required.
- If it is an anytime ticket, a green "valid any time on the selected date" note
  shows and no time is required.

## Notes
- This build also keeps the CSS/JS MIME fix so styling stays correct after upload.
- New demo installs include Burj Khalifa (time slots incl. Prime Hours) and a new
  Ski Dubai (anytime) example so you can see both types immediately.

## v1.1.1 — Editable private drop-back time
- Private transfers: the **Drop-back time** is now editable by the agent.
- If left blank, it defaults to the product's **Closing time**; if no closing
  time is set, it falls back to pick-up + duration (previous behaviour).
- No database change — apply the files and hard-refresh (Ctrl+F5) so the updated
  booking.js loads. No "Run database update" needed for this fix.

## v1.2.0 — Password recovery + internal booking emails
Two additions:

1) **Password recovery**
   - The login page has a **"Forgot your password?"** link. Staff enter their
     username or email and receive a reset link at their registered email.
   - Reset links are valid for 60 minutes and can be used once.
   - **Admins** can trigger a reset from **Accounts / Staff → (employee) →
     Send reset link**, which emails the link to that employee's address.
   - Emails are sent from the SMTP account configured in Settings → Email.

2) **Automatic internal booking notifications**
   - Every new booking is emailed (with the receipt PDF) to an internal address.
   - Configure it in **Settings → Email → Internal booking notifications**:
     tick the box and set **Send bookings to (internal email)**, e.g.
     traveldesk@luxuryattractions.com. Leave blank to use the From email.
   - This is separate from emailing the customer; it fires automatically on
     booking creation and never blocks saving if the mail server is briefly down.

No new database tables are required for these features (they reuse the existing
password_reset_tokens and email_logs tables). After uploading, hard-refresh
(Ctrl+F5). Running the database update is still safe and recommended.

## v1.2.1 — Home-screen icon (Android "Add to Home Screen")
- Adds a Web App Manifest at /manifest.webmanifest and PNG app icons at
  /branding/icon/192, /branding/icon/512 (plus maskable variants) generated from
  your uploaded company logo (Settings → Company → Logo).
- The login page and the whole app now include the manifest, theme-color and
  apple-touch-icon tags, so Chrome on Android shows a proper name + icon when a
  user taps "Add to Home Screen" (iOS Safari "Add to Home Screen" too).
- For the sharpest result, upload a SQUARE logo (PNG, at least 512×512). If no
  raster logo is set, a navy "LA" badge is used automatically.
- No database change. After uploading, hard-refresh; on the phone, remove any old
  home-screen shortcut and add it again so Chrome picks up the new icon.

## v1.3.0 — Directional transfer pricing (One-way vs Two-way)
- Shared transfers now have separate One-way and Two-way prices, each with an
  optional minimum (lowest price allowed without approval). Set them in
  Tours & Products → product → Transfer configuration. The Default direction
  selector chooses which is pre-selected on new bookings; the agent can switch it.
- Private per-vehicle options can have a separate One-way price + minimum
  (Tours & Products → product → option). Leave One-way at 0 to reuse the two-way
  (per-vehicle) price. Two-way keeps using the existing per-vehicle price/minimum.
- The transfer minimums feed the booking approval floor, so an agent can discount
  the whole package down to (options + transfer minimums) before approval is required.
- Data-preserving: your previous "per person / way" shared price is migrated so
  current totals are unchanged (Two-way = old x 2, One-way = old). Run the database
  update, then hard-refresh so the new booking.js loads.

## v1.4.0 — Hourly (yacht) pricing
- New option pricing method **Per hour (yacht)**. Each yacht option has:
  - a **Max capacity** (Adults + Children + Infants counted together),
  - an **Hourly rate**, plus an optional higher **Prime hourly rate** within a
    **Prime start–end** window (e.g. 17:00–19:00),
  - a **Min hours** for that yacht, and a product-level **Min booking hours
    (general)** default (e.g. 2),
  - a **Min hourly rate** for the approval floor.
- On the booking, the agent picks a **Start time** and **Hours**; the system prices
  each hour at the normal or prime rate depending on the start time, enforces the
  minimum hours and the capacity, and shows the hours on the receipt/PDF.
- Set it in Tours & Products → product → option → Pricing method = Per hour (yacht),
  then fill the blue "Hourly (yacht) settings" box. Data-preserving; run the database
  update and hard-refresh. New demo installs include a Private Yacht Charter example.

## v1.5.0 — Category-linked ticket admission times
- Each ticket admission time can now carry a **Category** (matching an option's
  "Ticket category"), set in Tours & Products → product → Ticket admission times.
- On the booking, when the agent picks an option the entry-time quick-picks are
  filtered to that option's category. Times with no category show for every option,
  and the agent can still type a custom time.
- Example: a "Prime" option shows only Prime entry times; a "Non-Prime" option shows
  the Non-Prime times. This enforces the correct time slots per ticket option.
- Data-preserving; run the database update and hard-refresh. New demo installs tag
  Burj Khalifa's times as Prime / Non-Prime to match its two options.

## v1.6.0 — Enforce ticket time-slot category on receipts
- New admin setting: Settings → Booking → "Enforce ticket time-slot category".
- When ON, a receipt is blocked if the entered/selected entry time belongs to a
  different category than the chosen option (e.g. a Prime-Time slot chosen under a
  Normal option). The agent sees a clear message and a one-click "Switch to <option>"
  button that changes the option to the matching category.
- When OFF (default), the same mismatch shows only as a soft warning and can be saved.
- Times that don't match any listed slot (truly custom times) are allowed; slots with
  no category are universal. No database change. Run the update and hard-refresh.

## v1.7.0 — Per-unit (jet ski) pricing
- New option pricing method **Per unit (jet ski)** for products sold in fixed
  duration blocks. Each option sets: Block minutes (e.g. 20 or 30), Price per unit,
  optional Capacity per unit (A+C+I), and a Min price per unit (approval floor).
- Make one option per duration (e.g. "Jet Ski - 20 Minutes", "Jet Ski - 30 Minutes").
- On the booking the agent enters the number of **Units**; total = units × price. To
  sell 2 units of 20 min and 1 unit of 30 min, add two lines (one per option). Units
  show on the receipt/PDF.
- Data-preserving; run the database update and hard-refresh. New demo installs include
  a "Jet Ski Ride - Dubai Marina" example with 20- and 30-minute options.
