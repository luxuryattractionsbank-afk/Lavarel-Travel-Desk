@extends('layouts.app')
@section('title', 'Dashboard')
@php use App\Support\Fmt; @endphp
@section('content')
@include('partials.header', ['title' => 'Welcome, '.auth()->user()->display_name, 'subtitle' => Fmt::date(today()), 'actions' => can('bookings.create') ? '<a href="'.route('bookings.create').'" class="btn-gold text-base">+ New Booking</a>' : null])
<div class="grid grid-cols-2 gap-3 lg:grid-cols-4">
  <a href="{{ route('bookings') }}" class="card border-l-4 border-l-navy-700"><div class="text-xs font-semibold uppercase text-slate-500">Today's bookings</div><div class="text-2xl font-bold">{{ $todayB->n }}</div></a>
  @if($showSales)<div class="card border-l-4 border-l-gold-500"><div class="text-xs font-semibold uppercase text-slate-500">Today's sales</div><div class="text-2xl font-bold">{{ money($todayB->t, $cur) }}</div></div>@endif
  <div class="card border-l-4 border-l-red-500"><div class="text-xs font-semibold uppercase text-slate-500">Today's outstanding</div><div class="text-2xl font-bold">{{ money($todayB->bal, $cur) }}</div></div>
  @if($showSales)<div class="card border-l-4 border-l-emerald-500"><div class="text-xs font-semibold uppercase text-slate-500">Monthly sales</div><div class="text-2xl font-bold">{{ money($month->t, $cur) }}</div><div class="text-xs text-slate-500">{{ $month->n }} bookings</div></div>@endif
  <a href="{{ route('bookings') }}?pay=outstanding" class="card border-l-4 border-l-red-500"><div class="text-xs font-semibold uppercase text-slate-500">Pending payments</div><div class="text-2xl font-bold">{{ $pending->n }}</div><div class="text-xs text-slate-500">{{ money($pending->bal, $cur) }}</div></a>
  @isset($fines)<a href="{{ route('fines') }}" class="card border-l-4 border-l-navy-700"><div class="text-xs font-semibold uppercase text-slate-500">Outstanding fines</div><div class="text-2xl font-bold">{{ money($fines->s, $cur) }}</div><div class="text-xs text-slate-500">{{ $fines->n }} fines</div></a>
  <a href="{{ route('tickets') }}" class="card border-l-4 border-l-gold-500"><div class="text-xs font-semibold uppercase text-slate-500">Tickets needing upload</div><div class="text-2xl font-bold">{{ $ticketsNeeded }}</div></a>@endisset
</div>
<div class="mt-5 grid gap-5 lg:grid-cols-3">
  <div class="space-y-5 lg:col-span-2">
    <div class="card overflow-x-auto"><div class="card-title">Upcoming tours</div><table class="tbl"><thead><tr><th>Date</th><th>Code</th><th>Tour</th><th>Customer</th><th>Pax</th><th>Pick-up</th></tr></thead><tbody>
      @forelse($upcoming as $u)<tr><td class="whitespace-nowrap">{{ Fmt::date($u->tour_date) }}</td><td><a class="font-mono text-navy-700 underline" href="{{ route('bookings.show', $u->booking_id) }}">{{ $u->tour_code }}</a></td><td>{{ $u->tour_name }}<div class="text-xs text-slate-500">{{ $u->option_name }}</div></td><td>{{ $u->cust }}<div class="text-xs text-slate-500">{{ $u->hotel }}</div></td><td>{{ $u->adults }}/{{ $u->children }}/{{ $u->infants }}</td><td class="text-xs">{{ $u->pickup_time ?: '-' }}</td></tr>
      @empty<tr><td colspan="6" class="text-center text-slate-500">No upcoming tours</td></tr>@endforelse</tbody></table></div>
    <div class="card overflow-x-auto"><div class="card-title">Recent receipts</div><table class="tbl"><tbody>
      @foreach($recent as $r)<tr><td><a class="font-mono text-navy-700 underline" href="{{ route('bookings.show', $r->id) }}">{{ $r->receipt_number }}</a></td><td>{{ $r->cust }}</td><td class="text-right">{{ money($r->total_amount, $r->base_currency) }}</td><td class="text-right text-red-600">{{ money($r->balance_due, $r->base_currency) }}</td><td>{!! badge($r->payment_status) !!}</td></tr>@endforeach</tbody></table></div>
    @isset($byTour)<div class="card"><div class="card-title">Sales by tour (this month)</div>@php $max = max(1, $byTour->max('t')); @endphp
      @foreach($byTour as $t)<div class="mb-2 text-xs"><div class="flex justify-between"><span>{{ $t->tour_name }}</span><span>{{ money($t->t, $cur) }}</span></div><div class="h-2.5 rounded-full bg-slate-100"><div class="h-2.5 rounded-full bg-gradient-to-r from-navy-700 to-gold-500" style="width: {{ $t->t / $max * 100 }}%"></div></div></div>@endforeach</div>@endisset
  </div>
  <div class="space-y-5">
    @if(can('attendance.self'))<div class="card border-2 border-gold-500/40"><div class="card-title">Duty check-in</div>
      <p class="mb-3 text-sm text-slate-600">{!! $att?->actual_in ? 'Checked in at <b>'.$att->actual_in.'</b>'.($att->actual_out ? ' · out at <b>'.$att->actual_out.'</b>' : '') : 'You have not checked in today.' !!}</p>
      @if($att?->actual_in)<p class="mb-3 text-xs text-slate-500">{{ $att->late_calc }}</p>@endif
      @unless($att?->actual_out)<form method="post" action="{{ route('attendance.check') }}">@csrf<input type="hidden" name="op" value="{{ $att?->actual_in ? 'out' : 'in' }}"><button class="{{ $att?->actual_in ? 'btn-outline' : 'btn-gold' }} w-full">{{ $att?->actual_in ? 'Check out' : 'Check in now' }}</button></form>@endunless</div>@endif
    <div class="card"><div class="card-title">Outstanding customer balances</div>
      @forelse($outstanding as $o)<a href="{{ route('bookings.show', $o->id) }}" class="flex justify-between border-b py-2 text-sm last:border-0"><span><b>{{ $o->cust }}</b><span class="block text-xs text-slate-500">{{ $o->receipt_number }} · {{ $o->balance_collection === 'driver' ? 'Driver' : 'Desk' }}</span></span><b class="text-red-600">{{ money($o->balance_due, $o->base_currency) }}</b></a>
      @empty<p class="text-sm text-slate-500">All settled 🎉</p>@endforelse</div>
    @isset($staffAtt)<div class="card"><div class="card-title">Attendance today</div>@foreach($staffAtt as $s)<div class="flex justify-between text-sm"><span>{{ $s->display_name }}</span><span class="{{ $s->late_fine > 0 ? 'text-red-600' : ($s->actual_in ? 'text-emerald-700' : 'text-slate-400') }}">{{ $s->is_day_off ? 'Day off' : ($s->actual_in ? $s->actual_in.' → '.($s->actual_out ?: '…') : 'Not checked in') }}</span></div>@endforeach</div>@endisset
  </div>
</div>
@endsection
