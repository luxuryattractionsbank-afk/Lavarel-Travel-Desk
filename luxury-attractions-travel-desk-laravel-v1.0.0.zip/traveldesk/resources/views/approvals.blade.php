@extends('layouts.app')
@section('title', 'Price approvals')
@php use App\Support\Fmt; @endphp
@section('content')
@include('partials.header', ['title' => can('pricing.approve') ? 'Price approvals' : 'My price approval requests', 'subtitle' => 'Sales below the minimum price need approval from another authorised user. Approvals are valid for 24 hours and one booking.'])
<div x-data x-init="setInterval(() => { if (!document.querySelector('input:focus')) location.reload() }, 15000)"></div>
@forelse($rows as $a)
  @php $live = $a->status === 'pending' && now()->lt($a->expires_at); @endphp
  <div class="card mb-3 {{ $live ? 'border-2 border-amber-300' : '' }}">
    <div class="flex flex-wrap justify-between gap-2"><div><div class="font-semibold">#{{ $a->id }} · {{ $a->tour_name }} <span class="font-normal text-slate-500">– {{ $a->option_name }}</span></div><div class="text-xs text-slate-500">By <b>{{ $a->agent }}</b> · {{ Fmt::dt($a->created_at) }} · {{ $a->customer_name }} · {{ $a->adults }}A/{{ $a->children }}C/{{ $a->infants }}I</div></div>{!! badge($live || $a->status !== 'pending' ? $a->status : 'expired') !!}</div>
    <div class="mt-2 grid gap-1 text-sm sm:grid-cols-3"><div>Listed: <b>{{ money($a->standard_total) }}</b></div><div>Minimum: <b>{{ money($a->min_total) }}</b></div><div class="text-red-700">Requested: <b>{{ money($a->requested_total) }}</b></div></div>
    @if($a->reason)<p class="mt-2 rounded bg-slate-50 p-2 text-xs">{{ $a->reason }}</p>@endif
    @if($a->decided_at)<p class="mt-2 text-xs">{{ Fmt::label($a->status) }} by <b>{{ $a->decider }}</b> · {{ Fmt::dt($a->decided_at) }} {{ $a->decision_note ? '– “'.$a->decision_note.'”' : '' }}</p>@endif
    @if(can('pricing.approve') && $live)
      @if($a->requested_by_id == auth()->id())<p class="mt-3 rounded bg-slate-100 p-2 text-xs">Your own request – must be approved by another user from their login.</p>
      @else<form method="post" action="{{ route('approvals.decide', $a->id) }}" class="mt-3 flex flex-wrap gap-2">@csrf<input name="note" placeholder="Note (required to reject)" class="input flex-1"><button name="decision" value="approved" class="btn bg-emerald-600 text-white">✓ Approve</button><button name="decision" value="rejected" class="btn-danger">✕ Reject</button></form>@endif
    @endif
    <div class="mt-2">@include('partials.delete', ['entity' => 'approval', 'id' => $a->id, 'what' => 'approval #'.$a->id])</div>
  </div>
@empty<div class="card text-center text-slate-500">No requests</div>@endforelse
@endsection
