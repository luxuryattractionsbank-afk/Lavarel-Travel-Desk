@extends('layouts.app')
@section('title', 'Employee')
@section('content')
@php $off = $s ? json_decode($s->weekly_days_off, true) : []; @endphp
<div class="mb-5 flex items-end justify-between"><div><h1 class="text-2xl font-bold text-navy-900">{{ $u->full_name ?? 'New employee' }}</h1><a class="text-sm underline" href="{{ route('staff') }}">← All staff</a></div>
  @if($u && $u->id !== auth()->id())@include('partials.delete', ['entity' => 'user', 'id' => $u->id, 'what' => 'employee '.$u->full_name, 'heavy' => true, 'back' => route('staff')])@endif</div>
<form method="post" action="{{ route('staff.save', $u->id ?? null) }}" class="card grid gap-3 sm:grid-cols-3">@csrf
  @foreach(['full_name' => 'Full name *', 'display_name' => 'Display name', 'username' => 'Username *', 'email' => 'Email *'] as $k => $l)<label class="text-xs">{{ $l }}<input name="{{ $k }}" value="{{ old($k, $u->$k ?? '') }}" class="input"></label>@endforeach
  <label class="text-xs">Role *<select name="role_id" class="input">@foreach($roles as $r)<option value="{{ $r->id }}" @selected(($u->role_id ?? null) == $r->id || (!$u && $r->key === 'sales_agent'))>{{ $r->name }}</option>@endforeach</select></label>
  <label class="text-xs">{{ $u ? 'New password (blank = keep)' : 'Password *' }}<input name="password" type="password" minlength="8" class="input" autocomplete="new-password"></label>
  @foreach(['work' => 'Work mobile', 'personal' => 'Personal mobile'] as $k => $l)<div><label class="text-xs">{{ $l }}<input name="{{ $k }}_mobile" value="{{ $u->{$k.'_mobile'} ?? '' }}" class="input"></label><label class="mt-1 flex items-center gap-2 text-sm"><input type="checkbox" name="{{ $k }}_whatsapp" value="1" @checked($u->{$k.'_whatsapp'} ?? false)> WhatsApp enabled</label></div>@endforeach
  <label class="text-xs">Status<select name="status" class="input"><option value="active">Active</option><option value="inactive" @selected(($u->status ?? '') === 'inactive')>Inactive</option></select></label>
  <label class="text-xs">Expected check-in<input type="time" name="check_in" value="{{ $s->check_in ?? '09:00' }}" class="input"></label><label class="text-xs">Expected check-out<input type="time" name="check_out" value="{{ $s->check_out ?? '18:00' }}" class="input"></label>
  <label class="text-xs">Joining date<input type="date" name="joining_date" value="{{ $u->joining_date ?? '' }}" class="input"></label><label class="text-xs">Monthly salary<input type="number" step="0.01" name="monthly_salary" value="{{ $u->monthly_salary ?? 0 }}" class="input"></label>
  <div class="sm:col-span-3"><div class="lbl">Weekly days off</div><div class="flex flex-wrap gap-3">@foreach(['Sun','Mon','Tue','Wed','Thu','Fri','Sat'] as $i => $dn)<label class="flex min-h-11 items-center gap-2 text-sm"><input type="checkbox" name="days_off[]" value="{{ $i }}" @checked(in_array($i, $off)) class="h-5 w-5"> {{ $dn }}</label>@endforeach</div></div>
  <label class="text-xs sm:col-span-3">Notes<textarea name="notes" class="input">{{ $u->notes ?? '' }}</textarea></label><div class="sm:col-span-3"><button class="btn-gold">Save employee</button></div></form>
@endsection
