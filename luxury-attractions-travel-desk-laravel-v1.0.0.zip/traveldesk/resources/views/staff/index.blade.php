@extends('layouts.app')
@section('title', 'Staff')
@section('content')
@include('partials.header', ['title' => 'Accounts / Staff management', 'actions' => '<a href="'.route('staff.edit', 'new').'" class="btn-gold">+ New employee</a>'])
<div class="card overflow-x-auto"><table class="tbl"><thead><tr><th>Name</th><th>Username / Email</th><th>Role</th><th>Work mobile</th><th>Personal mobile</th><th>Schedule</th><th>Status</th></tr></thead><tbody>
@foreach($rows as $u)<tr><td><a class="font-semibold text-navy-700 underline" href="{{ route('staff.edit', $u->id) }}">{{ $u->full_name }}</a></td><td class="text-xs">{{ $u->username }}<div>{{ $u->email }}</div></td><td>{{ $u->role }}</td>
  @foreach([[$u->work_mobile, $u->work_whatsapp], [$u->personal_mobile, $u->personal_whatsapp]] as [$ph, $wa])<td>@if($ph && $wa)<a class="text-emerald-700 underline" target="_blank" href="{{ \App\Support\Fmt::wa($ph) }}"><span class="badge bg-emerald-600 text-white">WA</span> {{ $ph }}</a>@elseif($ph)<a class="underline" href="tel:{{ $ph }}">{{ $ph }}</a>@else - @endif</td>@endforeach
  <td class="text-xs">{{ $u->check_in }}–{{ $u->check_out }}</td><td>{!! badge($u->status) !!}</td></tr>@endforeach</tbody></table></div>
@endsection
