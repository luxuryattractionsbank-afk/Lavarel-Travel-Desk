@extends('layouts.app')
@section('title', 'My profile')
@section('content')
@php $u = auth()->user(); @endphp
@include('partials.header', ['title' => 'My profile', 'subtitle' => $u->full_name.' · '.$u->roleName().' · '.$u->email])
<div class="grid gap-5 lg:grid-cols-2">
  <form method="post" action="{{ route('profile.save') }}" class="card" onsubmit="const c = document.getElementById('my-sig'); this.signature.value = c.dataset.signed === '1' ? c.toDataURL('image/png') : ''">@csrf<div class="card-title">My digital signature</div>
    <p class="mb-2 text-sm text-slate-500">Automatically used as the sales agent signature on new receipts.</p><input type="hidden" name="signature">
    <canvas id="my-sig" data-src="{{ $u->signature }}" x-data x-init="sigPad($el)" class="h-36 w-full touch-none rounded-lg border-2 border-dashed bg-white"></canvas>
    <div class="mt-3 flex gap-2"><button class="btn-primary">Save signature</button><button type="button" class="btn-outline" onclick="document.getElementById('my-sig').clear()">Clear</button></div></form>
  <form method="post" action="{{ route('profile.save') }}" class="card space-y-3">@csrf<div class="card-title">Change password</div>
    <div><label class="lbl">Current password</label><input type="password" name="current" required class="input"></div><div><label class="lbl">New password (min 8)</label><input type="password" name="password" minlength="8" required class="input"></div>
    <div><label class="lbl">Repeat new password</label><input type="password" name="password_confirmation" minlength="8" required class="input"></div><button class="btn-primary">Update password</button></form>
</div>
@endsection
@push('scripts')<script src="{{ asset('js/booking.js') }}"></script>@endpush
