@extends('layouts.app')
@section('title', 'Audit log')
@section('content')
@include('partials.header', ['title' => 'Audit log', 'subtitle' => 'Every important action (latest 500). Deleted records keep a full copy here.'])
<form class="card mb-4 grid gap-2 sm:grid-cols-4"><input name="entity" value="{{ request('entity') }}" placeholder="Entity (booking, user, …)" class="input"><input name="action" value="{{ request('action') }}" placeholder="Action contains…" class="input"><select name="user" class="input"><option value="">All users</option>@foreach($users as $u)<option value="{{ $u->id }}" @selected(request('user') == $u->id)>{{ $u->full_name }}</option>@endforeach</select><button class="btn-primary">Filter</button></form>
<div class="card overflow-x-auto"><table class="tbl"><thead><tr><th>When</th><th>User</th><th>Entity</th><th>Action</th><th>Details</th></tr></thead><tbody>
  @foreach($rows as $l)<tr><td class="whitespace-nowrap text-xs">{{ \App\Support\Fmt::dt($l->created_at) }}</td><td class="text-xs">{{ $l->who ?? 'System' }}</td><td class="text-xs">@if($l->entity_type === 'booking' && $l->entity_id)<a class="underline" href="{{ route('bookings.show', $l->entity_id) }}">booking #{{ $l->entity_id }}</a>@else{{ $l->entity_type }} {{ $l->entity_id ? '#'.$l->entity_id : '' }}@endif</td><td>{!! badge($l->action) !!}</td><td class="max-w-xl break-all font-mono text-[11px] text-slate-500">{{ \Illuminate\Support\Str::limit($l->details, 400) }}</td></tr>@endforeach</tbody></table></div>
@endsection
