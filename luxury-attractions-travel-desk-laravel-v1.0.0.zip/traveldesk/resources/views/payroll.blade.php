@extends('layouts.app')
@section('title', 'Payroll')
@php $txt = fn ($t) => collect($t)->map(fn ($x) => $x[0].($x[1] === null ? '+' : '-'.$x[1]).'='.$x[2])->implode("\n"); @endphp
@section('content')
@include('partials.header', ['title' => $manager ? 'Payroll & commission' : 'My commission & salary', 'subtitle' => 'Net pay = salary + monthly commission + high-sale commission − negative sales production − fines − advances',
  'actions' => '<form class="flex gap-2"><input type="month" name="month" value="'.$month.'" class="input w-40"><button class="btn-primary btn-sm">Go</button></form>'])
@foreach($calcs as $c)
  <details class="card mb-3" {{ $manager ? '' : 'open' }}><summary class="flex cursor-pointer flex-wrap justify-between gap-2"><b>{{ $c['user']->full_name }} {!! badge($c['run'] ? 'finalized' : 'pending') !!}</b><span class="text-sm">Sales <b>{{ number_format($c['sales'], 2) }}</b> · Net <b>{{ money($c['net']) }}</b></span></summary>
    <table class="mt-3 w-full max-w-xl text-sm">
      <tr><td>Net sales (commission basis)</td><td class="text-right">{{ number_format($c['sales'], 2) }}</td></tr><tr><td>Basic salary</td><td class="text-right">{{ number_format($c['user']->monthly_salary, 2) }}</td></tr>
      <tr><td>+ Monthly commission <div class="text-xs text-slate-500">{{ $c['explain'] }}</div></td><td class="text-right text-emerald-700">{{ number_format($c['commission'], 2) }}</td></tr>
      <tr><td>+ High-sale commission ({{ count($c['high']) }})<div class="text-xs text-slate-500">@foreach($c['high'] as $h){{ $h['code'] }}: {{ $h['std'] }} → {{ $h['sold'] }} ({{ $h['markup'] }}%) = {{ $h['comm'] }}; @endforeach</div></td><td class="text-right text-emerald-700">{{ number_format($c['high_total'], 2) }}</td></tr>
      <tr><td>− Negative sales production<div class="text-xs text-slate-500">{{ $c['negative_explain'] }}</div></td><td class="text-right text-red-600">{{ number_format($c['negative'], 2) }}</td></tr>
      <tr><td>− Fines</td><td class="text-right text-red-600">{{ number_format($c['fines'], 2) }}</td></tr><tr><td>− Advances</td><td class="text-right text-red-600">{{ number_format($c['advances'], 2) }}</td></tr>
      <tr class="border-t text-base font-bold"><td>Net pay</td><td class="text-right">{{ money($c['net']) }}</td></tr></table>
    @if($manager)<div class="mt-3 flex flex-wrap gap-2 border-t pt-3"><form method="post" action="{{ route('payroll.action', 'salary') }}" class="flex gap-2">@csrf<input type="hidden" name="user_id" value="{{ $c['user']->id }}"><input name="salary" type="number" step="0.01" value="{{ $c['user']->monthly_salary }}" class="input w-32"><button class="btn-outline btn-sm">Save salary</button></form>
      <form method="post" action="{{ route('payroll.action', $c['run'] ? 'reopen' : 'finalize') }}" onsubmit="return confirm('Are you sure?')">@csrf<input type="hidden" name="user_id" value="{{ $c['user']->id }}"><input type="hidden" name="month" value="{{ $month }}"><button class="{{ $c['run'] ? 'btn-outline' : 'btn-gold' }} btn-sm">{{ $c['run'] ? 'Reopen' : 'Finalize '.$month }}</button></form></div>@endif
  </details>
@endforeach
<div class="card mt-5 overflow-x-auto"><div class="card-title">Salary advances</div>
  @if($manager)<form method="post" action="{{ route('payroll.action', 'advance') }}" class="mb-3 grid gap-2 sm:grid-cols-6">@csrf<select name="user_id" class="input sm:col-span-2">@foreach($users as $u)<option value="{{ $u->id }}">{{ $u->full_name }}</option>@endforeach</select><input name="amount" type="number" step="0.01" required placeholder="Amount" class="input"><input name="date" type="date" value="{{ today()->toDateString() }}" class="input"><input name="month" type="month" value="{{ $month }}" class="input"><button class="btn-gold">+ Advance</button><input name="reason" placeholder="Reason" class="input sm:col-span-6"></form>@endif
  <table class="tbl">@foreach($advances as $a)<tr><td>{{ $a->date }}</td><td>{{ $a->name }}</td><td class="text-right">{{ number_format($a->amount, 2) }}</td><td>{{ $a->month }}</td><td>{{ $a->reason }}</td><td>{!! badge($a->status) !!}</td><td>@include('partials.delete', ['entity' => 'advance', 'id' => $a->id, 'what' => 'this advance'])</td></tr>@endforeach</table></div>
@if($manager)<form method="post" action="{{ route('payroll.action', 'plan') }}" class="card mt-5 grid gap-3 md:grid-cols-2">@csrf<div class="card-title md:col-span-2">Commission plan & targets</div>
  <label class="text-xs">Apply to<select name="user_id" class="input"><option value="">Whole team</option>@foreach($users as $u)<option value="{{ $u->id }}">{{ $u->full_name }} (custom plan)</option>@endforeach</select></label>
  <label class="text-xs">Mode<select name="tier_mode" class="input"><option value="flat">Flat – whole month at the tier reached</option><option value="progressive" @selected($team['tier_mode'] === 'progressive')>Progressive</option></select></label>
  <label class="text-xs">Monthly commission tiers (sales=rate %)<textarea name="tiers" class="input min-h-24 font-mono">{{ $txt($team['tiers']) }}</textarea></label>
  <label class="text-xs">Negative sales production (sales=salary cut %)<textarea name="negative_tiers" class="input min-h-24 font-mono">{{ $txt($team['negative_tiers']) }}</textarea></label>
  <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="high_sale_enabled" value="1" @checked($team['high_sale_enabled'])> High-sale commission</label>
  <div class="grid grid-cols-3 gap-2"><label class="text-xs">Min markup %<input name="high_sale_markup_pct" type="number" step="0.01" value="{{ $team['high_sale_markup_pct'] }}" class="input"></label><label class="text-xs">Rate %<input name="high_sale_rate" type="number" step="0.01" value="{{ $team['high_sale_rate'] }}" class="input"></label><label class="text-xs">On<select name="high_sale_basis" class="input"><option value="sale">Whole sale</option><option value="excess" @selected($team['high_sale_basis'] === 'excess')>Amount above standard</option></select></label></div>
  <button class="btn-gold">Save plan</button></form>@endif
@endsection
