@extends('layouts.app')
@section('title', 'Tickets')
@php use App\Support\Fmt; @endphp
@section('content')
@include('partials.header', ['title' => 'Ticket management', 'subtitle' => 'Tickets are never lost – status changes and reissues are kept.'])
<div class="card mb-5 overflow-x-auto"><div class="card-title">Requires attention – upcoming ticket products without an active ticket ({{ $attention->count() }})</div><table class="tbl">
  @forelse($attention as $a)<tr><td>{{ Fmt::date($a->tour_date) }}</td><td class="font-mono">{{ $a->tour_code }}</td><td>{{ $a->tour_name }} · {{ $a->option_name }}</td><td>{{ $a->cust }}</td><td><a class="underline" href="{{ route('bookings.show', $a->booking_id) }}">{{ $a->receipt_number }} → upload</a></td></tr>
  @empty<tr><td class="text-slate-500">All upcoming ticket bookings have tickets ✓</td></tr>@endforelse</table></div>
<form class="card mb-4 flex flex-wrap gap-2"><input name="q" value="{{ request('q') }}" placeholder="Tour code, customer, ticket no." class="input flex-1"><select name="status" class="input w-44"><option value="">Any status</option>@foreach(['active','used','expired','cancelled','refunded','reissued'] as $s)<option @selected(request('status') === $s)>{{ $s }}</option>@endforeach</select><button class="btn-primary">Filter</button></form>
<div class="card overflow-x-auto"><table class="tbl"><thead><tr><th>#</th><th>Tour code</th><th>Customer</th><th>Receipt</th><th>Type</th><th>Date</th><th>Status</th><th>File</th></tr></thead><tbody>
  @foreach($tickets as $t)<tr><td>{{ $t->id }}{{ $t->reissued_from_id ? ' ↻'.$t->reissued_from_id : '' }}</td><td class="font-mono">{{ $t->tour_code }}</td><td>{{ $t->cust }}</td><td><a class="underline" href="{{ route('bookings.show', $t->booking_id) }}">{{ $t->receipt_number }}</a></td><td>{{ $t->ticket_type }}</td><td>{{ Fmt::date($t->ticket_date) }}</td><td>{!! badge($t->status) !!}</td><td>@if($t->file_path)<a class="underline" target="_blank" href="{{ route('file', ['ticket', $t->id]) }}">View</a>@endif</td></tr>@endforeach</tbody></table></div>
@endsection
