@php
    $u = auth()->user();
    $company = \App\Support\Settings::get('company');
    $nav = array_filter([
        ['dashboard', 'Dashboard', '🏠', true],
        ['bookings.create', 'New Booking', '➕', can('bookings.create')],
        ['bookings', 'Bookings & Receipts', '🧾', true],
        ['approvals', can('pricing.approve') ? 'Price Approvals' : 'My Price Requests', '✅', true],
        ['tickets', 'Tickets', '🎫', can('tickets.manage')],
        ['tours', 'Tours & Products', '🗺️', can('tours.manage')],
        ['suppliers', 'Suppliers', '🤝', can('suppliers.view') || can('suppliers.manage') || can('suppliers.payments')],
        ['suppliers.queue', 'Supplier Assignment', '🧭', can('suppliers.assign')],
        ['reviews', 'Reviews', '⭐', can('reviews.write') || can('reviews.see_supplier')],
        ['cash', can('cash.collect') ? 'Cash Custody' : 'My Cash', '💵', can('cash.collect') || can('cash.own')],
        ['payroll', can('commission.manage') ? 'Payroll & Commission' : 'My Commission', '🏆', can('commission.manage') || can('commission.own')],
        ['reports', 'Reports', '📊', can('reports.view') || can('reports.own_sales')],
        ['attendance', 'Attendance', '⏱️', true],
        ['fines', 'Fines', '💸', true],
        ['staff', 'Accounts / Staff', '👥', can('users.manage')],
        ['audit', 'Audit Log', '📜', can('audit.view')],
        ['settings', 'Settings', '⚙️', can('settings.manage') || can('users.manage')],
        ['profile', 'My Profile', '👤', true],
    ], fn ($n) => $n[3]);
@endphp
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Travel Desk') – {{ $company['name'] }}</title>
    <link rel="icon" href="{{ url('/branding/favicon') }}"><link rel="stylesheet" href="{{ asset('css/app.css') }}?v={{ @filemtime(public_path('css/app.css')) }}">
    <script defer src="{{ asset('js/alpine.min.js') }}"></script>
    <style>[x-cloak]{display:none!important} @media print {.no-print{display:none!important}}</style>
</head>
<body class="bg-slate-100 text-slate-900 antialiased" x-data="{ menu: false }">
<header class="no-print sticky top-0 z-40 flex items-center justify-between bg-navy-900 px-4 py-3 text-white lg:hidden">
    <button @click="menu = !menu" class="btn-sm btn rounded-md border border-navy-700 text-white">☰</button>
    <span class="truncate font-semibold">{{ $company['name'] }}</span>
    @if(can('bookings.create'))<a href="{{ route('bookings.create') }}" class="btn-sm btn-gold">+ New</a>@else<span></span>@endif
</header>
<div x-show="menu" x-cloak class="fixed inset-0 z-40 bg-black/40 lg:hidden" @click="menu = false"></div>
<aside :class="menu ? 'translate-x-0' : '-translate-x-full'" class="no-print fixed inset-y-0 left-0 z-50 flex w-64 -translate-x-full flex-col bg-navy-900 transition-transform lg:translate-x-0">
    <div class="flex items-center gap-3 border-b border-navy-700 p-4">
        <img src="{{ url('/branding/logo') }}" alt="" class="h-10 w-10 rounded-lg bg-white object-contain">
        <div class="min-w-0"><div class="truncate text-sm font-bold text-white">{{ $company['name'] }}</div><div class="text-xs text-gold-400">Travel Desk</div></div>
    </div>
    <nav class="flex flex-1 flex-col gap-1 overflow-y-auto p-3">
        @foreach($nav as [$route, $label, $icon])
            <a href="{{ route($route) }}" class="flex min-h-11 items-center gap-3 rounded-lg px-3 text-sm font-medium {{ request()->routeIs($route) ? 'bg-gold-500 text-navy-900' : 'text-slate-200 hover:bg-navy-700' }}"><span class="w-5 text-center">{{ $icon }}</span>{{ $label }}</a>
        @endforeach
    </nav>
    <div class="border-t border-navy-700 p-3 text-xs text-slate-300">
        <div class="mb-2 truncate">Signed in as <b class="text-white">{{ $u->display_name }}</b> ({{ $u->roleName() }})</div>
        <form method="post" action="{{ route('logout') }}">@csrf<button class="btn-sm btn w-full border border-navy-700 text-slate-200 hover:bg-navy-700">Sign out</button></form>
    </div>
</aside>
<div class="lg:pl-64">
    <div class="no-print sticky top-0 z-30 hidden items-center gap-3 border-b border-slate-200 bg-white/90 px-6 py-3 backdrop-blur lg:flex">
        <form action="{{ route('bookings') }}" class="flex flex-1 gap-2"><input name="q" placeholder="Search receipt no., tour code, customer, phone, hotel, room…" class="input max-w-xl"><button class="btn-outline">Search</button></form>
        @if(can('pricing.approve'))
            <a href="{{ route('approvals') }}" x-data="{ n: 0 }" x-init="const f = () => fetch('{{ route('approvals.status') }}').then(r => r.json()).then(d => n = d.pending); f(); setInterval(f, 10000)" class="btn-sm btn relative border" :class="n ? 'border-red-300 bg-red-50 text-red-700' : 'border-slate-300 bg-white'">🔔 Approvals <span x-show="n" x-text="n" class="absolute -right-2 -top-2 grid h-5 min-w-5 place-items-center rounded-full bg-red-600 px-1 text-[10px] font-bold text-white"></span></a>
        @endif
        <span class="text-xs text-slate-500">{{ $company['phone'] }}</span>
    </div>
    <main class="mx-auto max-w-7xl p-3 sm:p-6">
        @foreach(['ok' => 'bg-emerald-50 text-emerald-800', 'error' => 'bg-red-50 text-red-700'] as $k => $cls)
            @if(session($k))<div class="mb-4 rounded-lg p-3 text-sm {{ $cls }}">{{ session($k) }}</div>@endif
        @endforeach
        @if($errors->any())<div class="mb-4 rounded-lg bg-red-50 p-3 text-sm text-red-700">@foreach($errors->all() as $e)<div>{{ $e }}</div>@endforeach</div>@endif
        @yield('content')
    </main>
</div>
<script>
async function copyText(t, btn) { try { await navigator.clipboard.writeText(t) } catch (e) { const a = document.createElement('textarea'); a.value = t; document.body.appendChild(a); a.select(); document.execCommand('copy'); a.remove() } if (btn) { const o = btn.innerText; btn.innerText = '✓ Copied'; setTimeout(() => btn.innerText = o, 1500) } }
</script>
@stack('scripts')
</body>
</html>
