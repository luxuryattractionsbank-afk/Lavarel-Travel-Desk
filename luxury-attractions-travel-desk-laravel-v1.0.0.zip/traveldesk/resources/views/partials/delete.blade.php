@if(can('records.delete'))
<form method="post" action="{{ route('delete', [$entity, $id]) }}" class="inline" onsubmit="{{ !empty($heavy) ? "if (prompt('Permanently delete ".e($what)."? Everything linked to it is deleted too. A copy is kept in the audit log.\\n\\nType DELETE to confirm:') !== 'DELETE') return false;" : "if (!confirm('Permanently delete ".e($what)."? A copy is kept in the audit log.')) return false;" }} this.reason.value = prompt('Reason (optional):') || ''; return true;">
    @csrf<input type="hidden" name="reason"><input type="hidden" name="back" value="{{ $back ?? url()->current() }}">
    <button class="btn-sm btn border border-red-200 bg-white text-red-600 hover:bg-red-50">🗑 Delete</button>
</form>
@endif
