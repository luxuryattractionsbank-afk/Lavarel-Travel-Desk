<div class="mb-5 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
    <div><h1 class="text-xl font-bold text-navy-900 sm:text-2xl">{{ $title }}</h1>@isset($subtitle)<p class="mt-1 text-sm text-slate-500">{!! $subtitle !!}</p>@endisset</div>
    @isset($actions)<div class="flex flex-wrap gap-2">{!! $actions !!}</div>@endisset
</div>
