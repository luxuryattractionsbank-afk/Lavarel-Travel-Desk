@extends('layouts.app')
@section('title', 'Supplier assignment')
@php use App\Support\Fmt; @endphp
@section('content')
@include('partials.header', ['title' => 'Supplier assignment', 'subtitle' => 'Choose which supplier operates each booking – their cost is added to their account automatically.', 'actions' => '<a href="'.route('suppliers.queue').'" class="btn-sm btn '.(!$assigned ? 'bg-navy-800 text-white' : 'btn-outline').'">Needs assignment</a><a href="'.route('suppliers.queue').'?show=assigned" class="btn-sm btn '.($assigned ? 'bg-navy-800 text-white' : 'btn-outline').'">Recently assigned</a>'])
@forelse($rows as $it)@php $linked = $links->get($it->tour_id, collect())->pluck('supplier_id')->all(); @endphp
  <div class="card mb-3 {{ $it->supplier_id ? '' : 'border-l-4 border-l-red-400' }}"><div class="flex flex-wrap justify-between gap-2"><div><b>{{ Fmt::date($it->tour_date) }} · {{ $it->tour_name }}</b> – {{ $it->option_name }}<div class="text-xs text-slate-500"><span class="font-mono">{{ $it->tour_code }}</span> · <a class="underline" href="{{ route('bookings.show', $it->booking_id) }}">{{ $it->receipt_number }}</a> · {{ $it->cust }} · {{ $it->hotel }} · {{ $it->adults }}A/{{ $it->children }}C/{{ $it->infants }}I · {{ Fmt::transfer($it) }}</div></div>
    @if($it->supplier_name)<div class="text-xs">Assigned: <b>{{ $it->supplier_name }}</b> · {{ number_format($it->supplier_cost, 2) }}</div>@endif</div>
    <form method="post" action="{{ route('items.assign', $it->id) }}" class="mt-2 flex flex-wrap items-end gap-2">@csrf<select name="supplier_id" class="input max-w-sm"><option value="">— Not assigned —</option><optgroup label="Offer this tour">@foreach($suppliers->whereIn('id', $linked) as $s)<option value="{{ $s->id }}" @selected($it->supplier_id == $s->id)>{{ $s->name }}</option>@endforeach</optgroup><optgroup label="Other">@foreach($suppliers->whereNotIn('id', $linked) as $s)<option value="{{ $s->id }}">{{ $s->name }}</option>@endforeach</optgroup></select>
      @if(can('suppliers.payments'))<input name="cost" type="number" step="0.01" placeholder="Cost override" class="input w-32">@endif<button class="btn-primary btn-sm">{{ $it->supplier_id ? 'Reassign' : 'Assign' }}</button></form></div>
@empty<div class="card text-center text-slate-500">{{ $assigned ? 'Nothing assigned yet' : 'All upcoming bookings have a supplier ✓' }}</div>@endforelse
@endsection
