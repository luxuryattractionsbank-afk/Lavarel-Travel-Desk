@extends('layouts.app')
@section('title', 'Reviews')
@php use App\Support\Fmt; @endphp
@section('content')
@include('partials.header', ['title' => 'Tour & ticket reviews', 'subtitle' => $see ? 'Reviews are linked to the supplier who operated the booking.' : 'Rate the tours and tickets you sold.'])
@if(can('reviews.write'))<div class="card mb-5"><div class="card-title">Write a review</div>
  @forelse($toReview as $it)<form method="post" action="{{ route('items.review', $it->id) }}" class="mb-2 grid items-center gap-2 rounded-lg border p-2 md:grid-cols-[minmax(0,1.4fr)_auto_minmax(0,1fr)_auto]">@csrf
    <div class="text-sm"><b class="font-mono text-gold-600">{{ $it->tour_code }}</b> · {{ $it->tour_name }}<div class="text-xs text-slate-500">{{ Fmt::date($it->tour_date) }} · {{ $it->cust }} · {{ $it->receipt_number }}</div></div>
    <select name="rating" class="input w-32">@for($s = 5; $s >= 1; $s--)<option value="{{ $s }}">{{ str_repeat('★', $s) }}</option>@endfor</select><input name="comment" placeholder="Comment" class="input"><button class="btn-gold btn-sm">Submit</button></form>
  @empty<p class="text-sm text-slate-500">Nothing to review – tours from the last 60 days appear here.</p>@endforelse</div>@endif
<div class="card overflow-x-auto"><table class="tbl"><thead><tr><th>Date</th><th>Tour code</th><th>Tour</th>@if($see)<th>Supplier</th>@endif<th>Rating</th><th>Comment</th><th>By</th><th></th></tr></thead><tbody>
  @forelse($rows as $r)<tr><td class="text-xs">{{ Fmt::dt($r->created_at) }}</td><td class="font-mono">{{ $r->tour_code }}</td><td>{{ $r->tour }}</td>@if($see)<td>{{ $r->supplier ?? 'not assigned' }}</td>@endif<td class="text-gold-600">{{ str_repeat('★', $r->rating) }}</td><td>{{ $r->comment }}</td><td class="text-xs">{{ $r->who }}</td><td>@include('partials.delete', ['entity' => 'review', 'id' => $r->id, 'what' => 'this review'])</td></tr>
  @empty<tr><td colspan="8" class="text-center text-slate-500">No reviews yet</td></tr>@endforelse</tbody></table></div>
@endsection
