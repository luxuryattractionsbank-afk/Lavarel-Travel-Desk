<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Installation – Travel Desk</title><link rel="stylesheet" href="{{ asset('css/app.css') }}"></head>
<body class="min-h-screen bg-gradient-to-br from-navy-900 via-navy-800 to-navy-700 px-4 py-10">
<div class="mx-auto max-w-2xl space-y-4">
    <div class="text-center text-white"><div class="mx-auto mb-3 grid h-16 w-16 place-items-center rounded-2xl bg-gold-500 text-2xl font-black text-navy-900">LA</div>
        <h1 class="text-2xl font-bold">Travel Desk – Installation</h1><p class="text-sm text-gold-400">Luxury Attractions Tourism · Laravel + MySQL</p></div>
    @if(session('error'))<div class="rounded-lg bg-red-50 p-3 text-sm text-red-700">{{ session('error') }}</div>@endif
    @if($errors->any())<div class="rounded-lg bg-red-50 p-3 text-sm text-red-700">@foreach($errors->all() as $e)<div>{{ $e }}</div>@endforeach</div>@endif
    <div class="card"><div class="card-title">1 · Server check</div>
        <ul class="space-y-1 text-sm">@foreach($reqs as [$label, $ok, $detail])<li class="flex gap-2"><span class="{{ $ok ? 'text-emerald-600' : 'text-red-600' }}">{{ $ok ? '✓' : '✕' }}</span><span><b>{{ $label }}</b> <span class="text-xs text-slate-500">– {{ $detail }}</span></span></li>@endforeach</ul>
        @if(collect($reqs)->contains(fn ($r) => ! $r[1]))<p class="mt-2 rounded bg-red-50 p-2 text-xs text-red-700">Fix the items marked ✕ (see the installation guide – usually folder permissions 755 or PHP version/extensions in cPanel “Select PHP Version”), then reload.</p>@endif
    </div>
    <div class="card"><div class="card-title">2 · MySQL database</div>
        @if(session('install_db') && session('ok'))
            <p class="rounded-lg bg-emerald-50 p-3 text-sm text-emerald-800">✓ {{ session('ok') }}</p>
        @elseif(session('install_db'))
            <p class="rounded-lg bg-emerald-50 p-3 text-sm text-emerald-800">✓ Database connection tested ({{ session('install_db')['database'] }}).</p>
        @endif
        <form method="post" action="/install/test" class="mt-3 grid gap-3 sm:grid-cols-2">@csrf
            <label class="text-xs text-slate-600">Database host<input name="host" value="{{ old('host', session('install_db')['host'] ?? 'localhost') }}" class="input"></label>
            <label class="text-xs text-slate-600">Port<input name="port" value="{{ old('port', session('install_db')['port'] ?? '3306') }}" class="input"></label>
            <label class="text-xs text-slate-600 sm:col-span-2">Database name<input name="database" value="{{ old('database', session('install_db')['database'] ?? '') }}" placeholder="e.g. myuser_traveldesk" class="input" required></label>
            <label class="text-xs text-slate-600">Database username<input name="username" value="{{ old('username', session('install_db')['username'] ?? '') }}" placeholder="e.g. myuser_desk" class="input" required autocomplete="off"></label>
            <label class="text-xs text-slate-600">Database password<input name="password" type="password" class="input" autocomplete="new-password"></label>
            <button class="btn-gold sm:col-span-2">{{ session('install_db') ? 'Test again' : 'Test connection' }}</button>
        </form>
    </div>
    @if(session('install_db'))
    <form method="post" action="/install" class="card space-y-3">@csrf
        <div class="card-title">3 · Company & administrator</div>
        <div class="grid gap-3 sm:grid-cols-2">
            <label class="text-xs text-slate-600 sm:col-span-2">Company name<input name="company_name" value="{{ old('company_name', 'Luxury Attractions Tourism') }}" class="input" required></label>
            <label class="text-xs text-slate-600">Company phone<input name="company_phone" value="{{ old('company_phone', '+971 52 888 5145') }}" class="input"></label>
            <label class="text-xs text-slate-600">Company email<input name="company_email" type="email" value="{{ old('company_email', 'salesdesk@luxuryattractions.com') }}" class="input"></label>
            <label class="text-xs text-slate-600">Administrator full name<input name="admin_name" value="{{ old('admin_name') }}" class="input" required></label>
            <label class="text-xs text-slate-600">Administrator email<input name="admin_email" type="email" value="{{ old('admin_email') }}" class="input" required></label>
            <label class="text-xs text-slate-600">Admin username<input name="admin_username" value="{{ old('admin_username', 'admin') }}" class="input" required></label><span></span>
            <label class="text-xs text-slate-600">Admin password (min. 8)<input name="admin_password" type="password" minlength="8" class="input" required autocomplete="new-password"></label>
            <label class="text-xs text-slate-600">Repeat password<input name="admin_password_confirmation" type="password" minlength="8" class="input" required autocomplete="new-password"></label>
            <label class="flex items-center gap-2 text-sm sm:col-span-2"><input type="checkbox" name="example_data" value="1" checked class="h-5 w-5"> Add example tours & tickets (can be edited or deleted later)</label>
            <label class="flex items-center gap-2 text-sm sm:col-span-2"><input type="checkbox" name="demo_agent" value="1" class="h-5 w-5"> Keep a demo sales agent account (“agent”)</label>
        </div>
        <button class="btn-gold w-full text-base" onclick="this.innerText='Installing – creating tables (up to 1 minute)…'">Install now</button>
    </form>
    @endif
</div></body></html>
