@extends('layouts.app')
@section('title', 'Reports')
@php $qs = http_build_query(request()->all()); $n = fn ($v) => number_format((float) $v, 2); @endphp
@section('content')
@include('partials.header', ['title' => can('reports.view') ? 'Sales reports' : 'My sales summary', 'subtitle' => "$from → $to · values in $cur"])
<form class="card mb-4 grid gap-2 sm:grid-cols-4 lg:grid-cols-7"><input type="date" name="from" value="{{ $from }}" class="input"><input type="date" name="to" value="{{ $to }}" class="input">
  @if(can('reports.view'))<select name="agent" class="input"><option value="">All agents</option>@foreach($agents as $a)<option value="{{ $a->id }}" @selected(request('agent') == $a->id)>{{ $a->full_name }}</option>@endforeach</select>@endif
  <select name="desk" class="input"><option value="">All desks</option>@foreach($desks as $d)<option @selected(request('desk') === $d)>{{ $d }}</option>@endforeach</select>
  <select name="method" class="input"><option value="">All methods</option>@foreach(['cash','card','driver'] as $m)<option value="{{ $m }}" @selected(request('method') === $m)>{{ lbl($m) }}</option>@endforeach</select>
  <select name="currency" class="input"><option value="">All currencies</option>@foreach($currencies as $c)<option @selected(request('currency') === $c)>{{ $c }}</option>@endforeach</select><button class="btn-primary">Run report</button></form>
<div class="grid grid-cols-2 gap-3 lg:grid-cols-4">@foreach([['Total bookings', $summary->n], ['Total sales', money($summary->sales, $cur)], ['Paid (payments in period)', money($byMethod->sum('t'), $cur)], ['Outstanding', money($summary->bal, $cur)]] as [$k, $v])<div class="card"><div class="text-xs font-semibold uppercase text-slate-500">{{ $k }}</div><div class="text-xl font-bold">{{ $v }}</div></div>@endforeach</div>
<div class="mt-5 grid gap-5 lg:grid-cols-2">
  @foreach([['Daily sales', 'daily', ['Date', 'Bookings', 'Sales'], $daily->map(fn ($x) => [$x->k, $x->n, $n($x->t)])], ['Monthly sales', 'daily', ['Month', 'Bookings', 'Sales'], $monthly->map(fn ($x) => [$x->k, $x->n, $n($x->t)])],
    ['Sales by tour', 'by_tour', ['Tour', 'Items', 'Pax', 'Sales'], $byTour->map(fn ($x) => [$x->k, $x->n, $x->pax, $n($x->t)])], ['Sales by option', 'by_tour', ['Option', 'Items', 'Sales'], $byOption->map(fn ($x) => [$x->k, $x->n, $n($x->t)])],
    ['Sales by agent', 'by_agent', ['Agent', 'Bookings', 'Sales', 'Outstanding'], $byAgent->map(fn ($x) => [$x->k, $x->n, $n($x->t), $n($x->bal)])], ['Sales by travel desk', 'daily', ['Desk', 'Bookings', 'Sales'], $byDesk->map(fn ($x) => [$x->k, $x->n, $n($x->t)])],
    ['Payments by method', 'by_method', ['Method', 'Payments', 'Base'], $byMethod->map(fn ($x) => [lbl($x->k), $x->n, $n($x->t)])], ['Payments by currency (cash drawer: received − change)', 'by_currency', ['Currency', 'Method', 'Received', 'Change given', 'Base'], $byCurrency->map(fn ($x) => [$x->k, lbl($x->m), $n($x->a), $x->m === 'cash' ? $n($change[$x->k] ?? 0) : '-', $n($x->t)])],
    ['Outstanding balances', 'outstanding', ['Receipt', 'Customer', 'Balance', 'Collect by'], $outstanding->map(fn ($x) => [$x->receipt_number, $x->cust, $n($x->balance_due), $x->balance_collection === 'driver' ? 'Driver' : 'Desk'])]] as [$title, $key, $head, $rows])
    <div class="card overflow-x-auto"><div class="mb-2 flex justify-between"><div class="card-title mb-0">{{ $title }}</div><a class="btn-outline btn-sm" href="{{ route('reports.export') }}?report={{ $key }}&{{ $qs }}">CSV</a></div>
      <table class="tbl"><thead><tr>@foreach($head as $h)<th>{{ $h }}</th>@endforeach</tr></thead><tbody>@forelse($rows as $row)<tr>@foreach($row as $cell)<td>{{ $cell }}</td>@endforeach</tr>@empty<tr><td colspan="{{ count($head) }}" class="text-center text-slate-400">No data</td></tr>@endforelse</tbody></table></div>
  @endforeach
</div>
@endsection
