@extends('layouts.app')
@section('title', $b->receipt_number)
@php use App\Support\Fmt; $cur = $b->base_currency; $closed = in_array($b->status, ['cancelled', 'refunded']); $n = fn ($v) => number_format((float) $v, 2); $contacts = json_decode($c->contacts, true) ?: []; @endphp
@section('content')
@if(request('saved'))<div class="mb-4 rounded-lg bg-emerald-50 p-3 text-sm font-semibold text-emerald-700">✓ Booking saved. Print or email the receipt below.</div>@endif
<div class="mb-5 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
  <div><h1 class="text-xl font-bold text-navy-900 sm:text-2xl">Receipt {{ $b->receipt_number }}</h1><p class="mt-1 text-sm text-slate-500">Issued {{ Fmt::dt($b->issued_at) }} · {!! badge($b->status) !!} {!! badge($b->payment_status) !!}</p></div>
  <div class="flex flex-wrap gap-2"><a href="{{ route('bookings.receipt', $b->id) }}" target="_blank" class="btn-primary">🖨 Print A4</a><a href="{{ route('bookings.receipt', $b->id) }}?layout=thermal" target="_blank" class="btn-outline">Thermal</a><a href="{{ route('bookings.pdf', $b->id) }}" target="_blank" class="btn-outline">PDF</a>
    @if(can('bookings.edit') && !$closed)<a href="{{ route('bookings.edit', $b->id) }}" class="btn-outline">Edit</a>@endif
    @include('partials.delete', ['entity' => 'booking', 'id' => $b->id, 'what' => 'booking '.$b->receipt_number, 'heavy' => true, 'back' => route('bookings')])</div>
</div>
<div class="grid grid-cols-2 gap-3 md:grid-cols-5">
  @foreach([['Standard', money($b->standard_total, $cur)], ['Total amount', money($b->total_amount, $cur)], ['Amount paid', money($b->paid_amount - $b->refunded_amount, $cur)], ['Balance due', money($b->balance_due, $cur)], ['Balance collection', $b->balance_collection === 'driver' ? 'Driver' : 'Travel Desk']] as [$k, $v])
    <div class="card {{ $k === 'Balance due' && $b->balance_due > 0 ? 'border-red-300 bg-red-50' : '' }}"><div class="text-xs font-semibold uppercase text-slate-500">{{ $k }}</div><div class="text-lg font-bold">{{ $v }}</div></div>
  @endforeach
</div>
<div class="mt-5 grid gap-5 lg:grid-cols-3">
  <div class="card text-sm"><div class="card-title">Customer</div>
    <div class="font-medium">{{ $c->title }} {{ $c->name }}</div><div>{{ $c->hotel ?: '-' }}{{ $c->room_number ? ' · Room '.$c->room_number : '' }}</div>
    @foreach($contacts as $k => $ct)@php $dg = preg_replace('/\D/', '', $ct['number']); @endphp
      <div class="mt-1"><b>{{ $ct['number'] }}</b>@if(!empty($ct['call'])) <a class="badge bg-slate-200" href="tel:{{ $ct['number'] }}">Call</a>@endif @if(!empty($ct['whatsapp'])) <a class="badge bg-emerald-600 text-white" target="_blank" href="https://wa.me/{{ $dg }}">WhatsApp</a>@endif @if(!empty($ct['telegram'])) <a class="badge bg-sky-500 text-white" target="_blank" href="https://t.me/+{{ $dg }}">Telegram</a>@endif @if(!empty($ct['viber'])) <a class="badge bg-purple-600 text-white" href="viber://chat?number=%2B{{ $dg }}">Viber</a>@endif @if(!empty($ct['other']))<span class="badge bg-slate-100">{{ $ct['other'] }}</span>@endif</div>
    @endforeach
    <div class="mt-1 break-all">{{ $c->email ?: '' }}</div>@if($c->notes)<div class="text-slate-500">{{ $c->notes }}</div>@endif</div>
  <div class="card text-sm"><div class="card-title">Travel desk</div><div>Desk: {{ $b->travel_desk ?: '-' }}</div><div>Sales person: {{ $b->sales_person ?: '-' }}</div><div>Created by: {{ $b->created_by }}</div><div>Notes: {{ $b->notes ?: '-' }}</div><div>Last emailed: {{ $b->last_emailed_at ? Fmt::dt($b->last_emailed_at) : 'Never' }}</div></div>
  @if(can('receipts.email'))<form method="post" action="{{ route('bookings.email', $b->id) }}" class="card space-y-2">@csrf<div class="card-title">Email</div>
    <input name="email" type="email" value="{{ $c->email }}" placeholder="customer@email.com" class="input">
    <select name="template" class="input"><option value="receipt">Receipt (PDF attached)</option><option value="booking_confirmation">Booking confirmation</option><option value="payment_confirmation">Payment confirmation</option><option value="ticket_delivery">Ticket delivery (tickets attached)</option></select>
    <button class="btn-gold w-full">✉ Send by email</button>
    @foreach($emails as $e)<div class="text-xs text-slate-500">{!! badge($e->status) !!} {{ $e->recipient }} · {{ Fmt::dt($e->created_at) }} {{ $e->error ? '– '.$e->error : '' }}</div>@endforeach</form>@endif
</div>

@foreach($items as $it)
  @php $adds = $addons->get($it->id, collect()); $tix = $tickets->get($it->id, collect()); @endphp
  <section class="card mt-5 border-l-4 {{ $it->status === 'cancelled' ? 'border-l-slate-300 opacity-60' : 'border-l-gold-500' }}">
    <div class="flex flex-wrap items-start justify-between gap-2"><div><div class="text-lg font-semibold">{{ $it->tour_name }} <span class="text-sm font-normal text-slate-500">· {{ $it->option_name }}</span></div>
      <div class="text-sm text-slate-600">{{ Fmt::date($it->tour_date) }} · {{ Fmt::pax($it->adults, $it->children, $it->infants) }}</div></div>
      <div class="text-right"><div class="font-mono text-lg font-bold text-gold-600">{{ $it->tour_code }}</div>{!! badge($it->status) !!}</div></div>
    <div class="mt-2 text-sm text-slate-600">{{ Fmt::transfer($it) }}{{ $it->pickup_time ? ' · Pick-up '.$it->pickup_time : '' }}{{ $it->drop_time ? ' · Drop-back '.$it->drop_time : '' }}{{ $it->pickup_location ? ' · From '.$it->pickup_location : '' }}</div>
    <table class="tbl mt-3"><thead><tr><th>Description</th><th class="text-right">Qty</th><th class="text-right">Unit</th><th class="text-right">Amount</th></tr></thead><tbody>
      @foreach(json_decode($it->breakdown, true) as $l)<tr><td>{{ $l['label'] }}</td><td class="text-right">{{ $l['qty'] }}</td><td class="text-right">{{ $n($l['unit']) }}</td><td class="text-right">{{ $n($l['total']) }}</td></tr>@endforeach
      <tr><td colspan="3" class="text-right text-slate-500">Standard price</td><td class="text-right">{{ $n($it->standard_price) }}</td></tr>
      @if(abs($it->discount) > 0.004)<tr><td colspan="3" class="text-right text-slate-500">{{ $it->discount > 0 ? 'Discount' : 'Surcharge' }}</td><td class="text-right">{{ $n(abs($it->discount)) }}</td></tr>@endif
      <tr class="font-bold"><td colspan="3" class="text-right">Item total</td><td class="text-right">{{ money($it->total, $cur) }}</td></tr></tbody></table>
    @if($it->sold_adult_price !== null || $it->sold_child_price !== null || $it->sold_infant_price !== null)<p class="mt-2 text-sm">Agreed rates: {{ collect(['Adult' => $it->sold_adult_price, 'Child' => $it->sold_child_price, 'Infant' => $it->sold_infant_price])->filter(fn ($v) => $v !== null)->map(fn ($v, $k) => "$k $cur ".$n($v))->implode(' · ') }}</p>@endif
    @if($it->price_approval_id)<p class="text-xs text-amber-700">Below-minimum price – approval #{{ $it->price_approval_id }} (minimum was {{ $cur }} {{ $n($it->min_total) }})</p>@endif
    @if($it->notes)<p class="mt-1 text-sm text-slate-600">Notes: {{ $it->notes }}</p>@endif
    @if(can('suppliers.assign') || can('suppliers.payments') || can('suppliers.manage'))
      <div class="mt-3 text-xs text-slate-600">Supplier: <b>{{ $it->supplier_name ?? 'not assigned' }}</b>@if($it->supplier_id) · cost {{ $cur }} {{ $n($it->supplier_cost) }} · margin {{ $cur }} {{ $n($it->total - $it->supplier_cost) }}@endif</div>
      @if(can('suppliers.assign') && $it->status !== 'cancelled')
        @php $linked = $links->get($it->tour_id, collect())->pluck('supplier_id')->all(); @endphp
        <form method="post" action="{{ route('items.assign', $it->id) }}" class="mt-2 flex flex-wrap items-end gap-2 rounded-lg bg-slate-50 p-2">@csrf
          <label class="flex-1 text-xs text-slate-500">Assign supplier<select name="supplier_id" class="input"><option value="">— Not assigned —</option>
            <optgroup label="Suppliers offering this tour">@foreach($suppliers->whereIn('id', $linked) as $s)<option value="{{ $s->id }}" @selected($it->supplier_id == $s->id)>{{ $s->name }}</option>@endforeach</optgroup>
            <optgroup label="Other suppliers">@foreach($suppliers->whereNotIn('id', $linked) as $s)<option value="{{ $s->id }}" @selected($it->supplier_id == $s->id)>{{ $s->name }}</option>@endforeach</optgroup></select></label>
          @if(can('suppliers.payments'))<label class="w-28 text-xs text-slate-500">Cost override<input name="cost" type="number" step="0.01" min="0" placeholder="{{ $n($it->supplier_cost) }}" class="input"></label>@endif
          <button class="btn-primary btn-sm">{{ $it->supplier_id ? 'Reassign' : 'Assign' }}</button></form>
      @endif
    @endif
    @if($it->status !== 'cancelled')
      @php $copy = Fmt::copyText($it, $adds, $b, $c); @endphp
      <div class="mt-3 rounded-lg border bg-slate-50 p-2"><div class="mb-1 flex items-center justify-between"><span class="text-xs font-semibold uppercase text-slate-500">Copy text – {{ $it->tour_code }}</span><button type="button" class="btn-sm btn bg-navy-800 text-white" onclick="copyText(this.parentElement.nextElementSibling.value, this)">📋 Copy</button></div>
        <textarea readonly rows="9" class="w-full rounded border bg-white p-2 font-mono text-xs">{{ $copy }}</textarea></div>
      @if(can('reviews.write'))
        @if($r = $myReviews->get($it->id))<p class="mt-2 text-xs text-slate-500">Your review: <span class="text-gold-600">{{ str_repeat('★', $r->rating) }}</span> {{ $r->comment }}</p>
        @else<details class="mt-2"><summary class="cursor-pointer text-xs font-semibold text-navy-700">⭐ Review this {{ $it->product_type }}{{ can('reviews.see_supplier') && $it->supplier_name ? ' (supplier: '.$it->supplier_name.')' : '' }}</summary>
          <form method="post" action="{{ route('items.review', $it->id) }}" class="mt-2 flex flex-wrap gap-2">@csrf<select name="rating" class="input w-32">@for($s = 5; $s >= 1; $s--)<option value="{{ $s }}">{{ str_repeat('★', $s) }}</option>@endfor</select><input name="comment" placeholder="Comment" class="input flex-1"><button class="btn-outline btn-sm">Submit review</button></form></details>@endif
      @endif
    @endif
    @if($it->product_type === 'ticket' || $tix->count())
      <div class="mt-4 rounded-lg bg-slate-50 p-3"><div class="lbl">Tickets</div>
        @if(!$tix->count())<p class="text-sm text-amber-700">No ticket uploaded yet.</p>@endif
        @foreach($tix as $t)<div class="mt-2 rounded-lg border bg-white p-3 text-sm"><div class="flex flex-wrap items-center justify-between gap-2"><div><b>#{{ $t->id }}</b> · {{ $t->ticket_type }} · {{ Fmt::date($t->ticket_date) }} {{ $t->ticket_number ? '· No. '.$t->ticket_number : '' }} {!! badge($t->status) !!} @if(!$t->still_usable)<span class="badge bg-red-100 text-red-700">Not usable</span>@endif</div>
          <div class="flex gap-2">@if($t->file_path)<a class="text-navy-700 underline" target="_blank" href="{{ route('file', ['ticket', $t->id]) }}">📎 {{ $t->file_name }}</a>@endif @include('partials.delete', ['entity' => 'ticket', 'id' => $t->id, 'what' => 'ticket #'.$t->id])</div></div>
          @if(can('tickets.manage') && $t->status !== 'reissued')<details class="mt-2"><summary class="cursor-pointer text-xs font-semibold text-navy-700">Update / Reissue</summary><div class="mt-2 grid gap-3 md:grid-cols-2">
            <form method="post" action="{{ route('tickets.update', $t->id) }}" class="space-y-2">@csrf<select name="status" class="input">@foreach(['active','used','expired','cancelled','refunded'] as $s)<option @selected($t->status === $s)>{{ $s }}</option>@endforeach</select><label class="flex items-center gap-2 text-xs"><input type="checkbox" name="still_usable" value="1" @checked($t->still_usable)> Still usable</label><button class="btn-outline btn-sm">Update ticket</button></form>
            <form method="post" enctype="multipart/form-data" action="{{ route('tickets.reissue', $t->id) }}" class="space-y-2">@csrf<select name="original_status" class="input">@foreach(['cancelled','refunded','expired','used'] as $s)<option value="{{ $s }}">Original was: {{ $s }}</option>@endforeach</select><label class="flex items-center gap-2 text-xs"><input type="checkbox" name="original_usable" value="1"> Original still usable</label><input name="new_tour_code" placeholder="New tour code (default {{ $t->tour_code }})" class="input"><input name="ticket_number" placeholder="New ticket number" class="input"><input name="reason" required placeholder="Reason *" class="input"><input type="file" name="ticket" required accept=".pdf,.jpg,.jpeg,.png" class="input"><button class="btn-gold btn-sm">Reissue ticket</button></form></div></details>@endif
        </div>@endforeach
        @if(can('tickets.manage') && $it->status !== 'cancelled')<form method="post" enctype="multipart/form-data" action="{{ route('tickets.upload', $it->id) }}" class="mt-3 grid gap-2 sm:grid-cols-5">@csrf<input name="ticket_type" value="{{ $it->option_name }}" class="input"><input name="ticket_number" placeholder="Ticket no." class="input"><input type="date" name="ticket_date" value="{{ $it->tour_date }}" class="input"><input type="file" name="ticket" required accept=".pdf,.jpg,.jpeg,.png" class="input"><button class="btn-primary">Upload ticket</button></form>@endif
      </div>
    @endif
  </section>
@endforeach

<section class="card mt-5 overflow-x-auto"><div class="card-title">Payment history</div>
  <table class="tbl"><thead><tr><th>Date</th><th>Method</th><th>Currency</th><th class="text-right">Tendered</th><th class="text-right">Rate</th><th class="text-right">Applied ({{ $cur }})</th><th>Change</th><th>Reference</th><th>Staff</th><th></th></tr></thead><tbody>
  @forelse($payments as $p)<tr class="{{ $p->status === 'void' ? 'text-slate-400 line-through' : '' }}"><td class="whitespace-nowrap text-xs">{{ Fmt::dt($p->paid_at) }}</td><td>{{ Fmt::label($p->method) }}{{ $p->is_deposit ? ' (deposit)' : '' }}<div class="text-xs text-slate-500">{{ $p->provider }} {{ $p->card_type }}</div></td><td>{{ $p->currency }}</td><td class="text-right">{{ $n($p->amount) }}</td><td class="text-right">{{ (float) $p->exchange_rate }}</td><td class="text-right font-semibold">{{ $n($p->base_amount) }}</td>
    <td class="text-xs">@if($p->overpayment_base > 0)Overpaid {{ $n($p->overpayment_base) }}@if($p->change_amount > 0)<div class="font-semibold text-amber-700">Change {{ $p->change_currency }} {{ $n($p->change_amount) }}</div>@endif @else - @endif</td>
    <td class="text-xs">{{ $p->reference ?: '-' }}@if($p->slip_path)<a class="block underline" target="_blank" href="{{ route('file', ['slip', $p->id]) }}">📎 {{ $p->slip_name }}</a>@endif @if($p->status === 'void')<div class="text-red-600">VOID: {{ $p->void_reason }}</div>@endif</td><td class="text-xs">{{ $p->staff }}</td>
    <td class="min-w-40">@if($p->status === 'active')<details><summary class="cursor-pointer text-xs text-navy-700">More</summary>
      <form method="post" enctype="multipart/form-data" action="{{ route('payments.slip', $p->id) }}" class="mt-1 space-y-1">@csrf<input type="file" name="slip" accept=".pdf,.jpg,.jpeg,.png" class="text-xs" required><button class="btn-outline btn-sm">Upload slip</button></form>
      @if(can('payments.void'))<form method="post" action="{{ route('payments.void', $p->id) }}" class="mt-2 space-y-1" onsubmit="return confirm('Void this payment?')">@csrf<input name="reason" required placeholder="Void reason" class="input"><button class="btn-danger btn-sm">Void</button></form>@endif</details>@endif
      @include('partials.delete', ['entity' => 'payment', 'id' => $p->id, 'what' => 'payment #'.$p->id])</td></tr>
  @empty<tr><td colspan="10" class="text-center text-slate-500">No payments yet</td></tr>@endforelse</tbody></table>
  @if($refunds->count())<div class="lbl mt-4">Refunds</div><table class="tbl">@foreach($refunds as $r)<tr><td class="text-xs">{{ Fmt::dt($r->created_at) }}</td><td>{{ Fmt::label($r->method) }}</td><td>{{ $r->currency }} {{ $n($r->amount) }}</td><td class="text-right">{{ $n($r->base_amount) }}</td><td>{{ $r->reason }}</td><td>{{ $r->staff }}</td><td>@include('partials.delete', ['entity' => 'refund', 'id' => $r->id, 'what' => 'this refund'])</td></tr>@endforeach</table>@endif
  @if(can('payments.record') && !$closed && $b->balance_due > 0)
    <form method="post" enctype="multipart/form-data" action="{{ route('payments.store', $b->id) }}" class="mt-5 grid gap-3 border-t pt-4 sm:grid-cols-4" x-data="{ method: 'cash', currency: '{{ $cur }}', amount: '', chCur: '{{ $cur }}', chAmt: '', rates: @js($currencies->pluck('rate_to_base', 'code')), bal: {{ (float) $b->balance_due }}, tol: {{ (float) $pay['overpayment_tolerance'] }},
      get rate() { return +this.rates[this.currency] || 1 }, get balIn() { return Math.ceil(this.bal / this.rate * 100 - 1e-6) / 100 }, get over() { return Math.max(0, Math.round((this.amount * this.rate - this.bal) * 100) / 100) }, get sug() { return Math.round(this.over / (+this.rates[this.chCur] || 1) * 100) / 100 } }">@csrf
      <div class="lbl sm:col-span-4">Record payment</div>
      <div><label class="lbl">Method</label><select name="method" x-model="method" class="input">@if($pay['cash_enabled'])<option value="cash">Cash</option>@endif @if($pay['card_enabled'])<option value="card">Card</option>@endif</select></div>
      <div><label class="lbl">Currency</label><select name="currency" x-model="currency" class="input">@foreach($currencies as $cc)<option>{{ $cc->code }}</option>@endforeach</select></div>
      <div class="sm:col-span-2"><label class="lbl">Amount</label><div class="flex gap-2"><input name="amount" x-model="amount" type="number" step="0.01" min="0.01" required class="input"><button type="button" class="btn-outline whitespace-nowrap" @click="amount = balIn.toFixed(2)">Full balance</button></div></div>
      <div class="rounded-lg bg-gold-400/15 p-3 sm:col-span-4"><div class="text-xs font-semibold uppercase text-slate-600">Remaining balance</div><div class="text-2xl font-bold" x-text="currency + ' ' + balIn.toFixed(2)"></div></div>
      <div x-show="over > 0" class="grid gap-2 rounded-lg border-2 border-amber-300 bg-amber-50 p-3 sm:col-span-4 sm:grid-cols-3"><div class="text-sm font-semibold sm:col-span-3" x-text="'Overpaid by {{ $cur }} ' + over.toFixed(2) + ' – give change as your notes allow'"></div>
        <label class="text-xs">Give change in<select name="change_currency" x-model="chCur" class="input">@foreach($currencies as $cc)<option>{{ $cc->code }}</option>@endforeach</select></label>
        <label class="text-xs">Change given<input name="change_amount" x-model="chAmt" type="number" step="0.01" min="0" :placeholder="over <= tol ? '0' : sug.toFixed(2)" class="input"></label><div class="text-xs" x-text="'Exact change: ' + chCur + ' ' + sug.toFixed(2)"></div></div>
      <template x-if="method === 'card'"><div class="grid gap-3 sm:col-span-4 sm:grid-cols-3"><input name="reference" placeholder="Reference *" class="input"><select name="provider" class="input">@foreach($pay['card_providers'] as $pp)<option>{{ $pp }}</option>@endforeach</select><select name="card_type" class="input"><option value="">Card type</option><option>Visa</option><option>Mastercard</option><option>Amex</option></select></div></template>
      <select name="booking_item_id" class="input"><option value="">Entire receipt</option>@foreach($items->where('status', '!=', 'cancelled') as $it)<option value="{{ $it->id }}">{{ $it->tour_code }} {{ $it->tour_name }}</option>@endforeach</select>
      <input type="file" name="slip" accept=".pdf,.jpg,.jpeg,.png" class="input sm:col-span-2"><label class="flex items-center gap-2 text-sm"><input type="checkbox" name="is_deposit" value="1" class="h-5 w-5"> Deposit</label>
      <input name="notes" placeholder="Notes (optional)" class="input sm:col-span-3"><button class="btn-gold">Record payment</button>
    </form>
  @endif
</section>

<div class="mt-5 grid gap-5 lg:grid-cols-2">
  @if(can('refunds.process') && $b->paid_amount - $b->refunded_amount > 0)
    <form method="post" action="{{ route('refunds.store', $b->id) }}" class="card grid gap-2 sm:grid-cols-2" onsubmit="return confirm('Record this refund?')">@csrf<div class="card-title sm:col-span-2">Process refund</div>
      <select name="payment_id" class="input sm:col-span-2"><option value="">Not linked to a specific payment</option>@foreach($payments->where('status', 'active') as $p)<option value="{{ $p->id }}">#{{ $p->id }} {{ Fmt::label($p->method) }} {{ $p->currency }} {{ $n($p->amount) }}</option>@endforeach</select>
      <select name="currency" class="input">@foreach($currencies as $cc)<option>{{ $cc->code }}</option>@endforeach</select><input name="amount" type="number" step="0.01" min="0.01" required placeholder="Amount" class="input">
      <select name="method" class="input">@foreach($pay['refund_methods'] as $m)<option value="{{ $m }}">{{ Fmt::label($m) }}</option>@endforeach</select><input name="reference" placeholder="Reference" class="input">
      <input name="reason" required placeholder="Reason *" class="input sm:col-span-2"><button class="btn-danger">Record refund</button></form>
  @endif
  @if(can('suppliers.payments') && !$closed && $b->balance_due > 0)
    <form method="post" action="{{ route('payments.driver', $b->id) }}" class="card grid gap-2 sm:grid-cols-2 {{ $b->balance_collection === 'driver' ? 'border-2 border-amber-300' : '' }}">@csrf<div class="card-title sm:col-span-2">Balance collected by driver</div>
      <p class="text-xs text-slate-500 sm:col-span-2">Settles the customer balance and deducts it from what we owe the supplier.</p>
      <select name="supplier_id" required class="input"><option value="">Supplier…</option>@foreach($suppliers as $s)<option value="{{ $s->id }}" @selected($items->pluck('supplier_id')->contains($s->id))>{{ $s->name }}</option>@endforeach</select>
      <input name="amount" type="number" step="0.01" value="{{ $n($b->balance_due) }}" class="input"><input name="reference" placeholder="Driver / reference" class="input"><input name="notes" placeholder="Notes" class="input"><button class="btn-gold">Record driver collection</button></form>
  @endif
  @if(can('bookings.cancel'))<form method="post" action="{{ route('bookings.status', $b->id) }}" class="card grid gap-2 sm:grid-cols-2">@csrf<div class="card-title sm:col-span-2">Booking status</div>
    <select name="status" class="input">@foreach(['draft','confirmed','pending','completed','cancelled'] as $s)<option value="{{ $s }}" @selected($b->status === $s)>{{ Fmt::label($s) }}</option>@endforeach</select><input name="reason" placeholder="Reason (required for cancel)" class="input"><button class="btn-outline">Update status</button></form>@endif
  <form method="post" action="{{ route('bookings.signatures', $b->id) }}" class="card" onsubmit="['cust','agent'].forEach(k => { const c = document.getElementById('s-' + k); if (c.dataset.signed === '1') this[k === 'cust' ? 'customer_signature' : 'agent_signature'].value = c.toDataURL('image/png') })">@csrf<div class="card-title">Signatures</div>
    <input type="hidden" name="customer_signature"><input type="hidden" name="agent_signature">
    <div class="grid gap-4 sm:grid-cols-2">@foreach([['cust', 'Customer', $b->customer_signature], ['agent', 'Sales agent', $b->agent_signature]] as [$k, $t, $src])<div><div class="mb-1 flex justify-between"><span class="lbl mb-0">{{ $t }}</span><button type="button" class="text-xs text-red-600" onclick="document.getElementById('s-{{ $k }}').clear()">Clear</button></div><canvas id="s-{{ $k }}" data-src="{{ $src }}" x-data x-init="sigPad($el)" class="h-32 w-full touch-none rounded-lg border-2 border-dashed bg-white"></canvas></div>@endforeach</div>
    <button class="btn-primary mt-3">Save signatures</button></form>
</div>
@if($logs->count())<section class="card mt-5"><div class="card-title">Audit history</div><div class="max-h-96 overflow-auto"><table class="tbl">@foreach($logs as $l)<tr><td class="whitespace-nowrap text-xs">{{ Fmt::dt($l->created_at) }}</td><td class="text-xs">{{ $l->who ?? 'System' }}</td><td>{!! badge($l->action) !!}</td><td class="max-w-md break-all font-mono text-[11px] text-slate-500">{{ $l->details }}</td></tr>@endforeach</table></div></section>@endif
@endsection
@push('scripts')<script src="{{ asset('js/booking.js') }}"></script>@endpush
