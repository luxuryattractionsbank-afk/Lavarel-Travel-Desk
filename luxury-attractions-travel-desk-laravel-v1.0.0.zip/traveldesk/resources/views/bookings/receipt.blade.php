@php use App\Support\Fmt; $b = $d['b'] ?? $b; $cur = $b->base_currency; $co = $company; $n = fn ($v) => number_format((float) $v, 2); @endphp
<!DOCTYPE html><html><head><meta charset="utf-8"><title>Receipt {{ $b->receipt_number }}</title>
<style>
  @page { size: A4; margin: 12mm; } body { font-family: DejaVu Sans, Arial, sans-serif; font-size: 11px; color: #0f172a; margin: 0; }
  .wrap { max-width: 190mm; margin: 0 auto; background: #fff; padding: {{ $pdf ? '0' : '10mm' }}; }
  h2 { background: #17223d; color: #e3c26b; font-size: 10px; letter-spacing: .08em; text-transform: uppercase; padding: 4px 6px; margin: 14px 0 6px; }
  table { width: 100%; border-collapse: collapse; } td, th { padding: 3px 4px; vertical-align: top; } th { text-align: left; font-size: 9px; color: #64748b; text-transform: uppercase; border-bottom: 1px solid #e2e8f0; }
  .r { text-align: right; } .muted { color: #64748b; } .gold { color: #a8832f; } .b { font-weight: bold; } .line { border-bottom: 2px solid #c9a24a; }
  .item { border-bottom: 1px solid #e2e8f0; padding: 6px 0; page-break-inside: avoid; } .box { background: #f8fafc; padding: 6px; }
  .toolbar { position: sticky; top: 0; background: #0f1a33; padding: 10px; text-align: center; } .toolbar a, .toolbar button { background: #fff; border: 0; border-radius: 6px; padding: 7px 12px; margin: 2px; font-size: 12px; text-decoration: none; color: #0f172a; cursor: pointer; }
  .toolbar .gold-btn { background: #c9a24a; font-weight: bold; } @media print { .toolbar { display: none; } body { background: #fff; } .wrap { padding: 0; } }
</style></head>
<body style="{{ $pdf ? '' : 'background:#e2e8f0' }}">
@unless($pdf)<div class="toolbar"><button class="gold-btn" onclick="window.print()">🖨 Print receipt</button><a href="?layout=thermal">Thermal layout</a><a href="?{{ $blank ? '' : 'blank=1' }}">{{ $blank ? 'Digital signatures' : 'Blank signature area' }}</a><a href="{{ route('bookings.pdf', $b->id) }}" target="_blank">Download PDF</a><a href="{{ route('bookings.show', $b->id) }}">← Back</a></div>@endunless
<div class="wrap">
  <table class="line"><tr>
    <td style="width:55%">@if(!empty($co['logo']) && file_exists(storage_path('app/public/'.$co['logo'])))<img src="{{ $pdf ? storage_path('app/public/'.$co['logo']) : url('/branding/logo') }}" style="max-height:60px;max-width:160px">@else<div style="font-size:18px;font-weight:bold;color:#17223d">{{ $co['name'] }}</div>@endif
      <div class="muted" style="font-size:9px">{{ $co['description'] }}</div></td>
    <td class="r muted" style="font-size:10px"><div class="b" style="color:#0f172a;font-size:13px">{{ $co['name'] }}</div>{{ $co['address'] }}<br>Tel: {{ $co['phone'] }}<br>{{ $co['email'] }}@if($co['website'])<br>{{ $co['website'] }}@endif</td></tr></table>
  <table style="margin-top:8px"><tr><td><div class="b" style="font-size:15px;text-transform:uppercase">{{ $co['receipt_header'] }}</div><div class="muted">Status: {{ Fmt::label($b->status) }} · Payment: {{ Fmt::label($b->payment_status) }}</div></td>
    <td class="r"><div class="b" style="font-size:13px">No. {{ $b->receipt_number }}</div><div>Issued: {{ Fmt::dt($b->issued_at) }}</div></td></tr></table>
  <table class="box" style="margin-top:8px"><tr><td><b>Customer:</b> {{ $c->title }} {{ $c->name }}</td><td><b>Travel desk:</b> {{ $b->travel_desk ?: '-' }}</td></tr>
    <tr><td><b>Hotel / Room:</b> {{ $c->hotel ?: '-' }} / {{ $c->room_number ?: '-' }}</td><td><b>Sales person:</b> {{ $b->sales_person ?? $b->created_by }}</td></tr>
    <tr><td colspan="2"><b>Contact:</b> {{ Fmt::contacts($c->contacts, $c->phone) }}</td></tr><tr><td colspan="2"><b>Email:</b> {{ $c->email ?: '-' }}</td></tr></table>
  <h2>Tour items</h2>
  @foreach($items as $it)
    <div class="item" style="{{ $it->status === 'cancelled' ? 'opacity:.5' : '' }}">
      <table><tr><td class="b">{{ $it->tour_name }} – {{ $it->option_name }}{{ $it->status === 'cancelled' ? ' (CANCELLED)' : '' }}</td><td class="r b gold">Tour code: {{ $it->tour_code }}</td></tr></table>
      <div class="muted">Date: {{ Fmt::date($it->tour_date) }} · Passengers: {{ Fmt::pax($it->adults, $it->children, $it->infants) }}</div>
      <div class="muted">{{ Fmt::transfer($it) }}{{ $it->pickup_time ? ' · Pick-up '.$it->pickup_time : '' }}{{ $it->drop_time ? ' · Drop-back '.$it->drop_time : '' }}{{ $it->pickup_location ? ' · From '.$it->pickup_location : '' }}</div>
      <table style="margin-top:4px"><tr><th>Description</th><th class="r">Qty</th><th class="r">Unit</th><th class="r">Amount ({{ $cur }})</th></tr>
        @foreach(json_decode($it->breakdown, true) as $l)<tr><td>{{ $l['label'] }}</td><td class="r">{{ $l['qty'] }}</td><td class="r">{{ $n($l['unit']) }}</td><td class="r">{{ $n($l['total']) }}</td></tr>@endforeach
        <tr><td colspan="3" class="r muted">Standard price</td><td class="r">{{ $n($it->standard_price) }}</td></tr>
        @if(abs($it->discount) > 0.004)<tr><td colspan="3" class="r muted">{{ $it->discount > 0 ? 'Discount' : 'Surcharge' }}</td><td class="r">{{ $n(abs($it->discount)) }}</td></tr>@endif
        @if($it->sold_adult_price !== null || $it->sold_child_price !== null || $it->sold_infant_price !== null)<tr><td colspan="4" class="r muted" style="font-size:9px">Agreed rates: {{ collect(['Adult' => $it->sold_adult_price, 'Child' => $it->sold_child_price, 'Infant' => $it->sold_infant_price])->filter(fn ($v) => $v !== null)->map(fn ($v, $k) => "$k ".$n($v))->implode(' · ') }}</td></tr>@endif
        <tr class="b"><td colspan="3" class="r">Item total</td><td class="r">{{ $n($it->total) }}</td></tr></table>
    </div>
  @endforeach
  <table style="margin-top:8px"><tr><td style="width:55%"></td><td><table>
    <tr><td>Standard total</td><td class="r">{{ $cur }} {{ $n($b->standard_total) }}</td></tr><tr><td>Discounts</td><td class="r">{{ $cur }} {{ $n($b->discount_total) }}</td></tr>
    <tr class="b" style="font-size:13px"><td>Total amount</td><td class="r">{{ $cur }} {{ $n($b->total_amount) }}</td></tr><tr><td>Amount paid</td><td class="r">{{ $cur }} {{ $n($b->paid_amount) }}</td></tr>
    @if($b->refunded_amount > 0)<tr><td>Refunded</td><td class="r">{{ $cur }} {{ $n($b->refunded_amount) }}</td></tr>@endif
    <tr class="b" style="font-size:13px;color:#b91c1c"><td>Balance due</td><td class="r">{{ $cur }} {{ $n($b->balance_due) }}</td></tr>
    @if($b->balance_due > 0)<tr><td colspan="2" class="b">Balance Collection: {{ $b->balance_collection === 'driver' ? 'Driver' : 'Travel Desk' }}</td></tr>@endif
  </table></td></tr></table>
  @if($payments->count())<h2>Payments</h2><table><tr><th>#</th><th>Date/time</th><th>Method</th><th>Currency</th><th class="r">Tendered</th><th class="r">Rate</th><th class="r">Applied ({{ $cur }})</th><th>Change</th><th>Ref</th><th>Staff</th></tr>
    @foreach($payments as $k => $p)<tr style="{{ $p->status === 'void' ? 'color:#94a3b8;text-decoration:line-through' : '' }}"><td>{{ $k + 1 }}</td><td>{{ Fmt::dt($p->paid_at) }}</td><td>{{ Fmt::label($p->method) }}{{ $p->is_deposit ? ' (deposit)' : '' }}</td><td>{{ $p->currency }}</td><td class="r">{{ $n($p->amount) }}</td><td class="r">{{ (float) $p->exchange_rate }}</td><td class="r">{{ $n($p->base_amount) }}</td><td>{{ $p->change_amount > 0 ? $p->change_currency.' '.$n($p->change_amount) : '-' }}</td><td>{{ $p->reference ?: '-' }}</td><td>{{ $p->staff }}</td></tr>@endforeach</table>@endif
  @if($refunds->count())<table style="margin-top:4px">@foreach($refunds as $r)<tr style="color:#6b21a8"><td>Refund {{ Fmt::dt($r->created_at) }}</td><td>{{ Fmt::label($r->method) }}</td><td>{{ $r->currency }} {{ $n($r->amount) }}</td><td class="r">-{{ $n($r->base_amount) }}</td><td>{{ $r->reason }}</td></tr>@endforeach</table>@endif
  @if($terms)<h2>Terms & conditions</h2><div class="muted" style="font-size:9px;white-space:pre-line">{{ $terms }}</div>@endif
  <table style="margin-top:26px;page-break-inside:avoid"><tr>
    @foreach([['Customer signature', $c->title.' '.$c->name, $b->customer_signature], ['Sales agent signature', $b->sales_person ?? $b->created_by, $b->agent_signature]] as [$t, $who, $sig])
      <td style="width:50%;padding-right:20px"><div style="height:60px">@if(!$blank && $sig)<img src="{{ $sig }}" style="max-height:60px">@endif</div><div style="border-top:1px solid #64748b;padding-top:3px"><b>{{ $t }}</b> – {{ $who }}</div>@if($blank)<div class="muted">Date: ____________</div>@endif</td>
    @endforeach</tr></table>
  <div style="margin-top:20px;border-top:2px solid #c9a24a;padding-top:6px;text-align:center" class="muted"><div>{{ $co['receipt_footer'] }}</div><div>{{ $co['name'] }} · {{ $co['phone'] }} · {{ $co['email'] }}</div><div style="font-size:9px">{{ $co['legal_text'] }}</div></div>
</div></body></html>
