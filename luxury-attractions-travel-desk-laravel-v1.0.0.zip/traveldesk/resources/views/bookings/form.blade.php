@extends('layouts.app')
@section('title', $initial ? 'Edit booking' : 'New booking')
@section('content')
@include('partials.header', ['title' => $initial ? 'Edit '.$receipt : 'New Booking', 'subtitle' => 'Customer → Tours → Transfer → Add-ons → Price → Payment → Signatures → Save'])
<div x-data="bookingForm(@js($data))" class="grid gap-5 pb-28 lg:grid-cols-[1fr_300px] lg:pb-0">
<div class="space-y-5">
  {{-- CUSTOMER --}}
  <section class="card">
    <div class="card-title">1 · Customer details</div>
    <div class="grid gap-3 sm:grid-cols-6">
      <div><label class="lbl">Title</label><select x-model="customer.title" class="input"><option>Mr</option><option>Mrs</option><option>Ms</option><option>Other</option></select></div>
      <div class="sm:col-span-5"><label class="lbl">Customer name *</label><input x-model="customer.name" class="input"></div>
      <div class="sm:col-span-4"><label class="lbl">Hotel</label><input x-model="customer.hotel" list="hotels" class="input" placeholder="Start typing e.g. Atlantis…"><datalist id="hotels">@foreach($hotels as $h)<option value="{{ $h }}">@endforeach</datalist></div>
      <div class="sm:col-span-2"><label class="lbl">Room number</label><input x-model="customer.room_number" class="input"></div>
      <div class="space-y-2 sm:col-span-6">
        <div class="flex items-center justify-between"><label class="lbl mb-0">Contact numbers *</label><button type="button" class="btn-outline btn-sm" @click="customer.contacts.push({number:'',call:true,whatsapp:false,telegram:false,viber:false,other:''})">+ Add number</button></div>
        <template x-for="(ct, k) in customer.contacts" :key="k">
          <div class="grid gap-2 rounded-lg border border-slate-200 p-2 md:grid-cols-[minmax(0,1fr)_auto]">
            <div class="flex gap-2"><input x-model="ct.number" type="tel" class="input" :placeholder="k === 0 ? '+971… (primary)' : '+… additional number'">
              <button type="button" x-show="customer.contacts.length > 1" @click="customer.contacts.splice(k,1)" class="btn-outline h-11 w-11 p-0 text-red-600">✕</button></div>
            <div class="flex flex-wrap items-center gap-1">
              <template x-for="[key, lb] in [['call','📞 Call'],['whatsapp','WhatsApp'],['telegram','Telegram'],['viber','Viber']]">
                <label class="flex min-h-11 cursor-pointer items-center rounded-lg border px-2.5 text-xs font-semibold" :class="ct[key] ? 'border-navy-700 bg-navy-800 text-white' : 'border-slate-300 bg-white text-slate-600'"><input type="checkbox" class="sr-only" x-model="ct[key]"><span x-text="lb"></span></label>
              </template>
              <input x-model="ct.other" class="input w-32" placeholder="Other (e.g. WeChat)">
            </div>
          </div>
        </template>
      </div>
      <div class="sm:col-span-6"><label class="lbl">Customer email (for e-receipt)</label><input x-model="customer.email" type="email" class="input"></div>
      <div class="sm:col-span-6"><label class="lbl">Additional notes</label><input x-model="customer.notes" class="input"></div>
    </div>
    <div class="mt-4 grid gap-3 border-t pt-4 sm:grid-cols-2">
      <div><label class="lbl">Travel desk</label><input x-model="travel_desk" list="desks" class="input"><datalist id="desks"><template x-for="d in D.desks"><option :value="d"></option></template></datalist></div>
      <div><label class="lbl">Sales person</label>
        <template x-if="D.canSelectSales"><select x-model="sales_person_id" class="input"><template x-for="s in D.sales"><option :value="s.id" x-text="s.name" :selected="+s.id === +sales_person_id"></option></template></select></template>
        <template x-if="!D.canSelectSales"><input class="input" disabled :value="D.me.name"></template></div>
    </div>
  </section>

  {{-- ITEMS --}}
  <template x-for="(it, i) in items" :key="it.key">
    <section class="card border-t-4 border-t-gold-500">
      <div class="mb-3 flex items-center justify-between"><div class="card-title mb-0" x-text="'Tour item ' + (i + 1) + (it.id ? ' (existing)' : '')"></div>
        <button type="button" x-show="items.length > 1" @click="items.splice(i,1)" class="btn-sm btn text-red-600">Remove</button></div>
      <div class="grid gap-3 sm:grid-cols-3">
        <div class="relative sm:col-span-2" @click.outside="it.open = false"><label class="lbl">Tour / ticket * (type a code or name)</label>
          <input class="input" :value="it.open ? it.search : (tourOf(it) ? tourOf(it).code_prefix + ' · ' + tourOf(it).name : '')" @focus="it.open = true; it.search = ''" @input="it.search = $event.target.value; it.open = true" placeholder="e.g. DS, LY, safari, yacht…">
          <div x-show="it.open" x-cloak class="absolute z-40 mt-1 max-h-72 w-full overflow-auto rounded-lg border bg-white shadow-xl">
            <template x-for="t in matches(it)" :key="t.id"><button type="button" @click="pickTour(it, t)" class="flex min-h-11 w-full items-center gap-3 px-3 py-2 text-left text-sm hover:bg-gold-400/20">
              <span class="w-12 shrink-0 rounded bg-navy-800 px-1.5 py-0.5 text-center font-mono text-xs text-gold-400" x-text="t.code_prefix"></span>
              <span><span class="block" x-text="t.name"></span><span class="block text-xs text-slate-400" x-text="(t.product_type === 'ticket' ? 'Ticket · ' : 'Tour · ') + t.options.map(o => o.name).join(' · ')"></span></span></button></template>
            <div x-show="!matches(it).length" class="p-3 text-sm text-slate-500">No match</div>
          </div></div>
        <div><label class="lbl">Tour date *</label><input type="date" x-model="it.tour_date" class="input"></div>
      </div>
      <template x-if="tourOf(it)"><div>
        <details class="mt-3 rounded-lg bg-slate-50 p-3 text-sm" :open="!it.id"><summary class="cursor-pointer font-semibold text-navy-800" x-text="'ℹ️ Product knowledge – ' + tourOf(it).product_type"></summary>
          <div class="mt-2 grid gap-1 text-slate-600 sm:grid-cols-2">
            <p class="sm:col-span-2" x-text="tourOf(it).description"></p>
            <p x-show="tourOf(it).operating_hours"><b>Operating hours:</b> <span x-text="tourOf(it).operating_hours"></span></p>
            <p x-show="tourOf(it).validity"><b>Validity:</b> <span x-text="tourOf(it).validity"></span></p>
            <p x-show="tourOf(it).pickup_rules"><b>Pick-up:</b> <span x-text="tourOf(it).pickup_rules"></span></p>
            <p x-show="tourOf(it).notes" class="text-amber-700 sm:col-span-2"><b>Notes:</b> <span x-text="tourOf(it).notes"></span></p>
          </div></details>
        <label class="lbl mt-4">Option / category *</label>
        <div class="grid gap-2 sm:grid-cols-2"><template x-for="o in tourOf(it).options" :key="o.id">
          <button type="button" @click="it.option_id = o.id; if (o.pricing_method === 'per_vehicle') it.transfer_type = 'private'" class="rounded-lg border-2 p-3 text-left text-sm" :class="+it.option_id === +o.id ? 'border-gold-500 bg-gold-400/10' : 'border-slate-200'">
            <div class="font-semibold" x-text="o.name"></div>
            <div class="text-xs" x-text="o.pricing_method === 'per_person' ? `Adult ${o.adult_allowed ? o.adult_price : '✕'} · Child ${o.child_allowed ? o.child_price : '✕ not sold'} · Infant ${o.infant_allowed ? (o.infant_price || 'Free') : '✕ not sold'}` : (o.pricing_method === 'per_vehicle' ? 'Charged per vehicle' : 'Group ' + o.group_price)"></div></button></template></div>
        <p x-show="optionOf(it)?.restriction_note" class="mt-2 rounded bg-amber-50 p-2 text-xs text-amber-800" x-text="'⚠ ' + optionOf(it)?.restriction_note"></p>
        <div class="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
          <template x-for="[k, lb] in [['adults','Adults'],['children','Children'],['infants','Infants']]"><div><div class="lbl" x-text="lb"></div>
            <div class="flex items-center gap-1"><button type="button" class="btn-outline h-11 w-11 p-0" @click="it[k] = Math.max(0, +it[k] - 1)">−</button><input type="number" min="0" x-model.number="it[k]" class="input w-16 text-center"><button type="button" class="btn-outline h-11 w-11 p-0" @click="it[k] = +it[k] + 1">+</button></div></div></template>
          <div><div class="lbl">Total pax</div><div class="grid h-11 place-items-center rounded-lg bg-navy-800 text-lg font-bold text-white" x-text="+it.adults + +it.children + +it.infants"></div></div>
        </div>
        {{-- Transfer --}}
        <div class="mt-4 rounded-lg border border-slate-200 p-3"><div class="lbl">Transfer</div>
          <div class="mb-3 flex flex-wrap gap-2" x-show="optionOf(it)?.pricing_method !== 'per_vehicle'">
            <template x-for="t in ['none','shared','private'].filter(t => t === 'none' ? tourOf(it).no_transfer_allowed : (t === 'shared' ? tourOf(it).shared_available : tourOf(it).private_available))">
              <button type="button" @click="it.transfer_type = t" class="btn-sm btn border" :class="it.transfer_type === t ? 'bg-navy-800 text-white' : 'bg-white'" x-text="t === 'none' ? 'No transfer' : t[0].toUpperCase() + t.slice(1)"></button></template>
          </div>
          <div class="mb-3 flex flex-wrap gap-2" x-show="res(it)?.type !== 'none'">
            <template x-for="d in ['one_way','two_way']"><button type="button" @click="it.transfer_direction = d" class="btn-sm btn border" :class="it.transfer_direction === d ? 'bg-gold-500 text-navy-900' : 'bg-white'" x-text="d === 'one_way' ? 'One Way' : 'Two Way'"></button></template>
            <span x-show="res(it)?.type === 'shared'" class="badge self-center bg-slate-100 text-slate-700" x-text="tourOf(it).shared_transfer_pricing === 'included' ? 'Included in tour price' : 'Extra ' + tourOf(it).shared_transfer_price + '/person/way'"></span>
          </div>
          <div x-show="res(it)?.type === 'shared'" class="grid gap-2 sm:grid-cols-2"><template x-for="s in tourOf(it).slots" :key="s.id">
            <button type="button" @click="it.slot_id = s.id" class="rounded-lg border-2 p-2 text-left text-sm" :class="+it.slot_id === +s.id ? 'border-gold-500 bg-gold-400/10' : 'border-slate-200'"><b>Pick-up</b> <span x-text="s.pickup_start + '–' + s.pickup_end"></span><div class="text-xs text-slate-500" x-show="it.transfer_direction === 'two_way'" x-text="'Drop-back ' + (s.drop_start ? s.drop_start + '–' + (s.drop_end || '') : 'per duration')"></div></button></template></div>
          <div x-show="res(it)?.type === 'private'" class="space-y-3">
            <div class="grid gap-2 sm:grid-cols-2"><template x-for="v in tourOf(it).vehicles" :key="v.id">
              <button type="button" @click="it.vehicle_id = v.id" :disabled="res(it).pax > v.capacity * it.vehicle_count && !tourOf(it).allow_over_capacity" class="rounded-lg border-2 p-2 text-left text-sm disabled:opacity-40" :class="+it.vehicle_id === +v.id ? 'border-gold-500 bg-gold-400/10' : 'border-slate-200'"><div class="font-semibold" x-text="v.name"></div><div class="text-xs text-slate-500" x-text="'Up to ' + v.capacity + ' pax · ' + v.price + ' per vehicle'"></div></button></template></div>
            <div class="grid gap-3 sm:grid-cols-3"><div><label class="lbl">No. of vehicles</label><input type="number" min="1" x-model.number="it.vehicle_count" class="input"></div>
              <div><label class="lbl">Pick-up time</label><input type="time" x-model="it.pickup_time" class="input"></div>
              <div><label class="lbl">Expected drop-back</label><input disabled class="input" :value="res(it)?.drop || '-'"></div></div>
          </div>
          <div class="mt-3 grid gap-3 sm:grid-cols-2" x-show="res(it)?.type !== 'none'"><div><label class="lbl">Pick-up location</label><input x-model="it.pickup_location" class="input" :placeholder="customer.hotel || 'Hotel lobby'"></div>
            <div x-show="it.transfer_direction === 'two_way'"><label class="lbl">Drop-back location</label><input x-model="it.drop_location" class="input" :placeholder="customer.hotel || 'Same as pick-up'"></div></div>
        </div>
        {{-- Add-ons --}}
        <div class="mt-4 rounded-lg border border-slate-200 p-3" x-show="tourOf(it).addons.length"><div class="lbl">Add-ons</div>
          <template x-for="a in tourOf(it).addons" :key="a.id"><div class="flex flex-wrap items-center justify-between gap-2 border-b py-2 last:border-0">
            <div class="text-sm"><div class="font-medium" x-text="a.name"></div><div class="text-xs text-slate-500" x-text="a.price + ' ' + a.pricing_method.replace('_',' ') + ' · min ' + (a.min_price ?? a.price)"></div></div>
            <div class="flex items-center gap-1"><button type="button" class="btn-outline h-10 w-10 p-0" @click="it.addons[a.id] = Math.max(0, (+it.addons[a.id] || 0) - 1)">−</button><span class="w-8 text-center font-semibold" x-text="it.addons[a.id] || 0"></span><button type="button" class="btn-outline h-10 w-10 p-0" @click="it.addons[a.id] = (+it.addons[a.id] || 0) + 1">+</button>
              <input x-show="+it.addons[a.id] > 0" type="number" step="0.01" min="0" x-model="it.addon_prices[a.id]" :placeholder="'Price ' + a.price" class="input ml-2 w-28" :class="it.addon_prices[a.id] !== undefined && it.addon_prices[a.id] !== '' && +it.addon_prices[a.id] < Math.min(a.min_price ?? a.price, a.price) ? 'border-red-500 bg-red-50' : ''"></div>
          </div></template>
        </div>
        {{-- Price --}}
        <div class="mt-4 rounded-lg bg-slate-50 p-3" x-show="res(it)">
          <div class="lbl" x-text="'Price calculation (' + D.base + ')'"></div>
          <table class="w-full text-sm"><tbody>
            <template x-for="l in res(it)?.lines || []"><tr><td x-text="l.label"></td><td class="text-right text-slate-500" x-text="l.qty + ' × ' + l.unit"></td><td class="w-24 text-right" x-text="l.total.toFixed(2)"></td></tr></template>
            <tr class="border-t font-semibold"><td>Standard / public price</td><td></td><td class="text-right" x-text="res(it)?.standard.toFixed(2)"></td></tr></tbody></table>
          <div x-show="optionOf(it)?.pricing_method === 'per_person'" class="mt-3 grid gap-3 rounded-lg border bg-white p-3 sm:grid-cols-3">
            <template x-for="[k, lb, cnt] in [['adult','Adult', it.adults],['child','Child', it.children],['infant','Infant', it.infants]].filter(x => +x[2] > 0 && optionOf(it)?.[x[0] + '_allowed'])"><div>
              <label class="lbl" x-text="lb + ' × ' + cnt"></label>
              <input type="number" step="0.01" min="0" x-model="it[k + '_price']" :disabled="it.agreed_price !== ''" :placeholder="optionOf(it)[k + '_price'].toFixed(2)" class="input" :class="it[k + '_price'] !== '' && +it[k + '_price'] < Math.min(optionOf(it)['min_' + k + '_price'] ?? optionOf(it)[k + '_price'], optionOf(it)[k + '_price']) ? 'border-red-500 bg-red-50' : ''">
              <div class="mt-1 text-xs text-slate-500" x-text="'List ' + optionOf(it)[k + '_price'].toFixed(2) + ' · Min ' + Math.min(optionOf(it)['min_' + k + '_price'] ?? optionOf(it)[k + '_price'], optionOf(it)[k + '_price']).toFixed(2)"></div></div></template>
          </div>
          <div class="mt-3 grid gap-3 sm:grid-cols-3">
            <div><label class="lbl">Discount</label><input type="number" min="0" step="0.01" x-model="it.discount" :disabled="it.agreed_price !== ''" class="input"></div>
            <div><label class="lbl">Agreed selling price</label><input type="number" min="0" step="0.01" x-model="it.agreed_price" :placeholder="res(it)?.standard.toFixed(2)" class="input"></div>
            <div><label class="lbl">Item total</label><div class="grid h-11 place-items-center rounded-lg bg-navy-800 font-bold text-white" x-text="D.base + ' ' + (res(it)?.total || 0).toFixed(2)"></div></div>
          </div>
          <p class="mt-1 text-xs text-slate-500" x-show="res(it)?.min < res(it)?.standard" x-text="'Minimum allowed without approval: ' + D.base + ' ' + res(it)?.min.toFixed(2)"></p>
          <div x-show="res(it)?.approval.length && !D.canOverride" class="mt-3 rounded-lg border-2 p-3 text-sm" :class="approvalOk(it) ? 'border-emerald-300 bg-emerald-50' : 'border-red-300 bg-red-50'">
            <div class="font-semibold" x-text="approvalOk(it) ? '✓ Below-minimum price approved' : 'Price below minimum – approval required'"></div>
            <ul class="mt-1 list-inside list-disc text-xs"><template x-for="r in res(it)?.approval || []"><li x-text="r"></li></template></ul>
            <p x-show="it.approval?.status === 'pending' && it.approval?.sig === sig(it)" class="mt-2 animate-pulse text-xs font-semibold text-amber-800" x-text="'⏳ Waiting for an authorised user to approve (request #' + it.approval_id + ')…'"></p>
            <p x-show="it.approval?.status === 'rejected'" class="mt-2 text-xs font-semibold text-red-700" x-text="'✕ Rejected' + (it.approval?.by ? ' by ' + it.approval.by : '') + (it.approval?.note ? ': ' + it.approval.note : '')"></p>
            <div x-show="!approvalOk(it) && !(it.approval?.status === 'pending' && it.approval?.sig === sig(it))" class="mt-2 flex flex-wrap gap-2"><input x-ref="reason" :id="'reason' + i" placeholder="Reason (e.g. repeat customer)" class="input flex-1"><button type="button" class="btn-gold" @click="requestApproval(it, document.getElementById('reason' + i).value)">Request approval</button></div>
          </div>
          <template x-for="e in res(it)?.errors || []"><p class="mt-2 rounded bg-red-50 p-2 text-sm text-red-700" x-text="'⛔ ' + e"></p></template>
        </div>
        <div class="mt-3"><label class="lbl">Item notes</label><input x-model="it.notes" class="input"></div>
      </div></template>
    </section>
  </template>
  <button type="button" @click="items.push(Object.assign(newItem(), { tour_date: items[items.length - 1]?.tour_date || D.today }))" class="btn w-full border-2 border-dashed border-gold-500 bg-white py-4 text-base text-navy-800">+ Add Another Tour</button>

  {{-- PAYMENT --}}
  <section class="card">
    <div class="card-title">Payment</div>
    <template x-if="!D.initial"><div>
      <table class="tbl mb-3" x-show="pays.length"><thead><tr><th>#</th><th>Method</th><th>Currency</th><th class="text-right">Tendered</th><th class="text-right">Change</th><th></th></tr></thead>
        <tbody><template x-for="(p, k) in pays"><tr><td x-text="k + 1"></td><td x-text="p.method + (p.is_deposit ? ' (deposit)' : '')"></td><td x-text="p.currency"></td><td class="text-right" x-text="(+p.amount).toFixed(2)"></td><td class="text-right text-xs" x-text="p.change_amount ? p.change_currency + ' ' + (+p.change_amount).toFixed(2) : '-'"></td><td><button type="button" class="text-xs text-red-600" @click="pays.splice(k,1)">Remove</button></td></tr></template></tbody></table>
      <div x-show="balance > 0" class="grid gap-3 sm:grid-cols-4">
        <div><label class="lbl">Method</label><select x-model="draft.method" class="input"><option value="cash" x-show="D.pay.cash">Cash</option><option value="card" x-show="D.pay.card">Card</option></select></div>
        <div><label class="lbl">Currency</label><select x-model="draft.currency" class="input"><template x-for="c in D.currencies"><option :value="c.code" x-text="c.code"></option></template></select></div>
        <div class="sm:col-span-2"><label class="lbl" x-text="'Amount (' + draft.currency + ')'"></label><div class="flex gap-2"><input type="number" step="0.01" min="0" x-model="draft.amount" class="input"><button type="button" class="btn-outline whitespace-nowrap" @click="draft.amount = balIn(draft.currency)">Full balance</button></div></div>
        <div class="rounded-lg bg-gold-400/15 p-3 sm:col-span-4"><div class="text-xs font-semibold uppercase text-slate-600" x-text="'Remaining balance in ' + draft.currency"></div><div class="text-2xl font-bold" x-text="draft.currency + ' ' + balIn(draft.currency).toFixed(2)"></div><div class="text-xs text-slate-500" x-show="draft.currency !== D.base" x-text="'= ' + D.base + ' ' + balance.toFixed(2) + ' at rate ' + rate(draft.currency)"></div></div>
        <div x-show="draftSettle.over > 0" class="space-y-2 rounded-lg border-2 border-amber-300 bg-amber-50 p-3 sm:col-span-4">
          <div class="text-sm font-semibold" x-text="'Customer overpaid by ' + D.base + ' ' + draftSettle.over.toFixed(2) + ' – give change as your notes allow'"></div>
          <div class="grid gap-2 sm:grid-cols-3"><label class="text-xs">Give change in<select x-model="draft.change_currency" @change="draft.change_amount = ''" class="input"><template x-for="c in D.currencies"><option :value="c.code" x-text="c.code"></option></template></select></label>
            <label class="text-xs">Change given<input type="number" step="0.01" min="0" x-model="draft.change_amount" :placeholder="draftSettle.sug.toFixed(2)" class="input"></label>
            <div class="text-xs"><div x-text="'Exact change: ' + draft.change_currency + ' ' + draftSettle.sug.toFixed(2)"></div><div x-show="Math.abs(draftSettle.kept) >= 0.01" x-text="draftSettle.kept > 0 ? 'Kept by desk: ' + draftSettle.kept.toFixed(2) : 'Extra change: ' + (-draftSettle.kept).toFixed(2)"></div>
              <button type="button" class="underline" @click="draft.change_amount = draftSettle.sug.toFixed(2)">Exact</button> · <button type="button" class="underline" @click="draft.change_amount = Math.floor(draftSettle.sug)">Round down</button> · <button type="button" class="underline" @click="draft.change_amount = 0">No change</button></div></div>
        </div>
        <template x-if="draft.method === 'card'"><div class="grid gap-3 sm:col-span-4 sm:grid-cols-3"><div><label class="lbl">Reference *</label><input x-model="draft.reference" class="input"></div><div><label class="lbl">Provider</label><select x-model="draft.provider" class="input"><template x-for="p in D.pay.providers"><option x-text="p"></option></template></select></div><div><label class="lbl">Card type</label><select x-model="draft.card_type" class="input"><option value="">-</option><option>Visa</option><option>Mastercard</option><option>Amex</option></select></div></div></template>
        <div><label class="lbl">Allocate to</label><select x-model="draft.item_index" class="input"><option value="">Entire receipt</option><template x-for="(it, k) in items"><option :value="k" x-text="'Item ' + (k + 1) + ': ' + (tourOf(it)?.name || '-')"></option></template></select></div>
        <label class="flex items-center gap-2 text-sm"><input type="checkbox" x-model="draft.is_deposit" class="h-5 w-5"> Deposit</label>
        <div class="sm:col-span-2"><button type="button" @click="addPay()" class="btn-gold">+ Add payment</button><p x-show="payError" class="mt-2 text-sm text-red-600" x-text="payError"></p></div>
      </div>
      <p x-show="balance <= 0 && grand > 0" class="rounded bg-emerald-50 p-3 text-sm font-semibold text-emerald-700">Fully paid ✓</p>
    </div></template>
    <p x-show="D.initial" class="text-sm text-slate-500">Further payments are recorded on the booking page.</p>
    <div class="mt-4 border-t pt-4"><div class="lbl">Balance collection</div><div class="flex gap-2">
      <button type="button" @click="balance_collection = 'travel_desk'" class="btn flex-1 border" :class="balance_collection === 'travel_desk' ? 'bg-navy-800 text-white' : 'bg-white'">Collect at Travel Desk</button>
      <button type="button" @click="balance_collection = 'driver'" class="btn flex-1 border" :class="balance_collection === 'driver' ? 'bg-navy-800 text-white' : 'bg-white'">Collect by Driver</button></div></div>
  </section>

  <section class="card"><div class="card-title">Terms & signatures</div>
    <div class="grid gap-3 sm:grid-cols-2">
      <div><label class="lbl">Terms & conditions</label><select x-model="terms_id" class="input"><template x-for="t in D.terms"><option :value="t.id" x-text="t.title + (t.is_default ? ' (default)' : '')"></option></template></select></div>
      <div><label class="lbl">Booking notes</label><input x-model="notes" class="input"></div>
      <div class="sm:col-span-2" x-show="D.canTerms"><label class="lbl">Override terms for this booking (optional)</label><textarea x-model="terms_override" class="input min-h-20"></textarea></div>
    </div>
    <div class="mt-4 grid gap-4 sm:grid-cols-2">
      @foreach([['cust', 'Customer signature', $initial['customer_signature'] ?? null], ['agent', 'Sales agent signature', $initial['agent_signature'] ?? auth()->user()->signature]] as [$id, $label, $src])
        <div><div class="mb-1 flex justify-between"><span class="lbl mb-0">{{ $label }}</span><button type="button" class="text-xs text-red-600" onclick="document.getElementById('sig-{{ $id }}').clear()">Clear</button></div>
          <canvas id="sig-{{ $id }}" data-src="{{ $src }}" x-init="sigPad($el)" class="h-36 w-full touch-none rounded-lg border-2 border-dashed border-slate-300 bg-white"></canvas></div>
      @endforeach
    </div>
  </section>
  <p x-show="error" class="rounded-lg bg-red-50 p-3 text-sm text-red-700" x-text="error"></p>
</div>
<aside class="fixed inset-x-0 bottom-0 z-30 border-t bg-white p-3 shadow-2xl lg:sticky lg:top-20 lg:self-start lg:rounded-xl lg:border lg:p-5">
  <div class="hidden lg:block"><div class="card-title">Booking summary</div>
    <template x-for="(it, k) in items"><div class="flex justify-between text-sm"><span class="truncate" x-text="(k + 1) + '. ' + (tourOf(it)?.name || '—')"></span><span x-text="(res(it)?.total || 0).toFixed(2)"></span></div></template></div>
  <div class="grid grid-cols-3 gap-2 text-center lg:mt-3 lg:grid-cols-1 lg:text-left">
    <div class="lg:flex lg:justify-between"><div class="text-[10px] uppercase text-slate-500 lg:text-sm">Total</div><b x-text="D.base + ' ' + grand.toFixed(2)"></b></div>
    <div class="lg:flex lg:justify-between"><div class="text-[10px] uppercase text-slate-500 lg:text-sm">Paid</div><b class="text-emerald-700" x-text="D.base + ' ' + paid.toFixed(2)"></b></div>
    <div class="lg:flex lg:justify-between"><div class="text-[10px] uppercase text-slate-500 lg:text-sm">Balance</div><b class="text-red-600" x-text="D.base + ' ' + balance.toFixed(2)"></b></div>
  </div>
  <div class="mt-2 flex gap-2 lg:mt-4 lg:flex-col"><button type="button" :disabled="saving" @click="submit('confirmed')" class="btn-gold flex-1 text-base" x-text="saving ? 'Saving…' : (D.initial ? 'Save changes' : 'Save booking')"></button>
    <button type="button" x-show="!D.initial" :disabled="saving" @click="submit('draft')" class="btn-outline">Save as draft</button></div>
</aside>
</div>
@endsection
@push('scripts')<script src="{{ asset('js/booking.js') }}?v={{ @filemtime(public_path('js/booking.js')) }}"></script>@endpush
