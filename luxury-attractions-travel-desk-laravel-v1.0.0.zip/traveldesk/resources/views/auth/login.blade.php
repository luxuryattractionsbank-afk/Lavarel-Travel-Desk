@php $company = \App\Support\Settings::get('company'); @endphp
<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Sign in – {{ $company['name'] }}</title>
<link rel="icon" href="{{ url('/branding/favicon') }}"><link rel="stylesheet" href="{{ asset('css/app.css') }}"></head>
<body class="grid min-h-screen place-items-center bg-gradient-to-br from-navy-900 via-navy-800 to-navy-700 px-4">
<div class="w-full max-w-md">
    <div class="mb-6 text-center text-white">
        <img src="{{ url('/branding/logo') }}" alt="" class="mx-auto mb-3 h-16 w-16 rounded-2xl bg-white object-contain">
        <h1 class="text-2xl font-bold">{{ $company['name'] }}</h1><p class="text-sm text-gold-400">Travel Desk Management System</p>
    </div>
    <form method="post" action="/login" class="card space-y-4">@csrf
        @if(session('ok'))<p class="rounded-lg bg-emerald-50 p-3 text-sm text-emerald-800">✓ {{ session('ok') }}</p>@endif
        @if(session('error'))<p class="rounded-lg bg-red-50 p-2 text-sm text-red-700">{{ session('error') }}</p>@endif
        @if($errors->any())<p class="rounded-lg bg-red-50 p-2 text-sm text-red-700">{{ $errors->first() }}</p>@endif
        <div><label class="lbl">Username or email</label><input name="username" value="{{ old('username') }}" class="input" required autofocus autocomplete="username"></div>
        <div><label class="lbl">Password</label><input name="password" type="password" class="input" required autocomplete="current-password"></div>
        <button class="btn-primary w-full">Sign in</button>
    </form>
    <p class="mt-4 text-center text-xs text-slate-300">{{ $company['phone'] }} · {{ $company['email'] }}</p>
</div></body></html>
