@extends('layouts.app')
@section('title', 'Tours & products')
@section('content')
@include('partials.header', ['title' => 'Tours & products', 'subtitle' => 'Structured product configuration used by the booking form and pricing engine.', 'actions' => '<a href="'.route('tours.edit', 'new').'" class="btn-gold">+ New product</a>'])
<div class="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">@foreach($tours as $t)<a href="{{ route('tours.edit', $t->id) }}" class="card block hover:border-gold-500">
  <div class="flex justify-between"><b>{{ $t->name }}</b>{!! badge($t->active ? 'active' : 'inactive') !!}</div><div class="mt-1 text-xs text-slate-500">{{ lbl($t->product_type) }} · code <b class="font-mono">{{ $t->code_prefix }}</b></div>
  <div class="mt-2 text-xs text-slate-500">Suppliers: {!! $sup->has($t->id) ? e($sup[$t->id]->pluck('name')->implode(', ')) : '<span class="text-red-600">none linked</span>' !!}</div></a>@endforeach</div>
<div class="card mt-5"><div class="card-title">Private transfer vehicles (default for all products)</div>
  @foreach($vehicles->concat([null]) as $v)@include('tours.vehicle', ['v' => $v, 'tourId' => null])@endforeach</div>
@endsection
