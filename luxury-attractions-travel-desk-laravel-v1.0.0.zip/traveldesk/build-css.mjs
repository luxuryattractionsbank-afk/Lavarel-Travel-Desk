// Builds public/css/app.css from the Blade views using the Tailwind CSS v4 compiler.
// Run from the Next.js project (which has tailwind installed):  node laravel/build-css.mjs
import postcss from "postcss";
import tailwind from "@tailwindcss/postcss";
import { readFileSync, writeFileSync } from "node:fs";
const input = readFileSync(new URL("./resources/css/tailwind.css", import.meta.url), "utf8");
const from = new URL("./resources/css/tailwind.css", import.meta.url).pathname;
const out = await postcss([tailwind({ optimize: { minify: true } })]).process(input, { from });
writeFileSync(new URL("./public/css/app.css", import.meta.url), out.css);
console.log("public/css/app.css", out.css.length, "bytes");
