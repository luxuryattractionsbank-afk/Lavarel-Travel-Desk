<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Luxury Attractions Travel Desk – complete MySQL schema (version 1.0).
 * Future changes must be added as NEW migration files (never edit this one after release),
 * so upgrades keep all existing records.
 */
return new class extends Migration
{
    public function up(): void
    {
        $money = fn (Blueprint $t, string $c) => $t->decimal($c, 14, 2)->default(0);

        Schema::create('roles', function (Blueprint $t) {
            $t->id(); $t->string('key', 60)->unique(); $t->string('name'); $t->json('permissions'); $t->boolean('system')->default(false); $t->timestamps();
        });
        Schema::create('users', function (Blueprint $t) use ($money) {
            $t->id(); $t->string('username', 60)->unique(); $t->string('email'); $t->string('password');
            $t->foreignId('role_id')->constrained('roles');
            $t->string('full_name'); $t->string('display_name');
            $t->string('work_mobile')->nullable(); $t->boolean('work_whatsapp')->default(false);
            $t->string('personal_mobile')->nullable(); $t->boolean('personal_whatsapp')->default(false);
            $t->string('status', 20)->default('active'); $t->date('joining_date')->nullable(); $t->text('notes')->nullable();
            $t->longText('signature')->nullable(); $money($t, 'monthly_salary');
            $t->rememberToken(); $t->timestamps();
        });
        Schema::create('password_reset_tokens', function (Blueprint $t) { $t->string('email')->primary(); $t->string('token'); $t->timestamp('created_at')->nullable(); });
        Schema::create('sessions', function (Blueprint $t) {
            $t->string('id')->primary(); $t->foreignId('user_id')->nullable()->index(); $t->string('ip_address', 45)->nullable(); $t->text('user_agent')->nullable(); $t->longText('payload'); $t->integer('last_activity')->index();
        });
        Schema::create('employee_schedules', function (Blueprint $t) {
            $t->id(); $t->foreignId('user_id')->unique()->constrained()->cascadeOnDelete(); $t->string('check_in', 5)->default('09:00'); $t->string('check_out', 5)->default('18:00'); $t->json('weekly_days_off');
        });
        Schema::create('settings', function (Blueprint $t) { $t->string('key', 60)->primary(); $t->json('value'); $t->timestamps(); });
        Schema::create('counters', function (Blueprint $t) { $t->string('key', 80)->primary(); $t->unsignedInteger('value')->default(0); });
        Schema::create('currencies', function (Blueprint $t) {
            $t->char('code', 3)->primary(); $t->string('name'); $t->string('symbol', 10); $t->decimal('rate_to_base', 14, 6); $t->boolean('is_base')->default(false); $t->boolean('active')->default(true); $t->boolean('cash_accepted')->default(true);
        });
        Schema::create('exchange_rates', function (Blueprint $t) { $t->id(); $t->char('currency', 3); $t->decimal('rate_to_base', 14, 6); $t->foreignId('user_id')->nullable()->constrained()->nullOnDelete(); $t->timestamp('created_at')->useCurrent(); });
        Schema::create('terms', function (Blueprint $t) { $t->id(); $t->string('title'); $t->text('content'); $t->boolean('active')->default(true); $t->boolean('is_default')->default(false); $t->timestamps(); });
        Schema::create('email_templates', function (Blueprint $t) { $t->string('key', 60)->primary(); $t->string('name'); $t->string('subject'); $t->text('body'); });
        Schema::create('travel_desks', function (Blueprint $t) { $t->id(); $t->string('name')->unique(); $t->string('location')->nullable(); $t->boolean('active')->default(true); });
        Schema::create('hotels', function (Blueprint $t) { $t->id(); $t->string('name')->unique(); $t->string('area')->nullable(); });
        Schema::create('suppliers', function (Blueprint $t) {
            $t->id(); $t->string('name')->unique(); $t->string('contact')->nullable(); $t->string('phone')->nullable(); $t->string('email')->nullable();
            $t->string('whatsapp_group')->nullable(); $t->text('details')->nullable(); $t->string('platform_url')->nullable(); $t->string('platform_username')->nullable();
            $t->text('platform_password')->nullable(); // encrypted with APP_KEY
            $t->boolean('active')->default(true); $t->text('notes')->nullable(); $t->timestamps();
        });

        // ---------------- Products ----------------
        Schema::create('tours', function (Blueprint $t) use ($money) {
            $t->id(); $t->string('name'); $t->string('code_prefix', 6); $t->text('description')->nullable(); $t->string('product_type', 10)->default('tour');
            $t->boolean('active')->default(true); $t->boolean('no_transfer_allowed')->default(false); $t->boolean('shared_available')->default(true); $t->boolean('private_available')->default(false);
            $t->string('default_direction', 10)->default('two_way'); $t->string('shared_transfer_pricing', 10)->default('included'); $money($t, 'shared_transfer_price');
            $t->unsignedInteger('duration_minutes')->default(0); $t->string('opening_time', 5)->nullable(); $t->string('closing_time', 5)->nullable();
            $t->string('operating_hours')->nullable(); $t->string('validity')->nullable(); $t->json('available_days');
            $t->text('pickup_rules')->nullable(); $t->text('drop_rules')->nullable();
            $t->foreignId('supplier_id')->nullable()->constrained('suppliers')->nullOnDelete();
            $t->boolean('requires_ticket')->default(false); $t->boolean('allow_over_capacity')->default(false); $t->text('notes')->nullable(); $t->text('terms')->nullable(); $t->timestamps();
        });
        Schema::create('tour_options', function (Blueprint $t) use ($money) {
            $t->id(); $t->foreignId('tour_id')->constrained()->cascadeOnDelete(); $t->string('name'); $t->text('description')->nullable();
            $t->string('pricing_method', 12)->default('per_person'); $money($t, 'adult_price'); $money($t, 'child_price'); $money($t, 'infant_price'); $money($t, 'group_price');
            foreach (['min_adult_price', 'min_child_price', 'min_infant_price', 'min_group_price'] as $c) $t->decimal($c, 14, 2)->nullable();
            $t->boolean('adult_allowed')->default(true); $t->boolean('child_allowed')->default(true); $t->boolean('infant_allowed')->default(true);
            $t->string('restriction_note')->nullable(); $t->string('ticket_type')->nullable(); $t->string('ticket_category')->nullable();
            $t->boolean('active')->default(true); $t->integer('sort')->default(0);
        });
        Schema::create('addons', function (Blueprint $t) use ($money) {
            $t->id(); $t->foreignId('tour_id')->constrained()->cascadeOnDelete(); $t->string('name'); $t->string('pricing_method', 12)->default('per_unit');
            $money($t, 'price'); $t->decimal('min_price', 14, 2)->nullable(); $t->boolean('active')->default(true);
        });
        Schema::create('vehicles', function (Blueprint $t) use ($money) {
            $t->id(); $t->foreignId('tour_id')->nullable()->constrained()->cascadeOnDelete(); $t->string('name'); $t->unsignedInteger('capacity'); $money($t, 'price'); $t->decimal('supplier_cost', 14, 2)->nullable(); $t->boolean('active')->default(true);
        });
        Schema::create('pickup_slots', function (Blueprint $t) {
            $t->id(); $t->foreignId('tour_id')->constrained()->cascadeOnDelete(); $t->string('pickup_start', 5); $t->string('pickup_end', 5); $t->string('drop_start', 5)->nullable(); $t->string('drop_end', 5)->nullable(); $t->boolean('active')->default(true);
        });
        Schema::create('tour_suppliers', function (Blueprint $t) {
            $t->id(); $t->foreignId('tour_id')->constrained()->cascadeOnDelete(); $t->foreignId('supplier_id')->constrained()->cascadeOnDelete(); $t->unique(['tour_id', 'supplier_id']);
        });
        Schema::create('supplier_prices', function (Blueprint $t) use ($money) {
            $t->id(); $t->foreignId('supplier_id')->constrained()->cascadeOnDelete(); $t->foreignId('option_id')->constrained('tour_options')->cascadeOnDelete();
            $money($t, 'adult_cost'); $money($t, 'child_cost'); $money($t, 'infant_cost'); $t->unique(['supplier_id', 'option_id']);
        });
        Schema::create('supplier_addon_costs', function (Blueprint $t) use ($money) {
            $t->id(); $t->foreignId('supplier_id')->constrained()->cascadeOnDelete(); $t->foreignId('addon_id')->constrained()->cascadeOnDelete(); $money($t, 'cost'); $t->unique(['supplier_id', 'addon_id']);
        });
        Schema::create('supplier_vehicle_costs', function (Blueprint $t) use ($money) {
            $t->id(); $t->foreignId('supplier_id')->constrained()->cascadeOnDelete(); $t->foreignId('vehicle_id')->constrained()->cascadeOnDelete(); $money($t, 'cost'); $t->decimal('hours', 5, 1)->nullable(); $t->unique(['supplier_id', 'vehicle_id']);
        });
        Schema::create('supplier_services_info', function (Blueprint $t) {
            $t->id(); $t->foreignId('supplier_id')->constrained()->cascadeOnDelete(); $t->foreignId('tour_id')->constrained()->cascadeOnDelete();
            $t->string('pickup_times')->nullable(); $t->string('drop_times')->nullable(); $t->text('tour_details')->nullable(); $t->text('itinerary')->nullable(); $t->text('notes')->nullable(); $t->unique(['supplier_id', 'tour_id']);
        });

        // ---------------- Bookings ----------------
        Schema::create('customers', function (Blueprint $t) {
            $t->id(); $t->string('title', 10)->default('Mr'); $t->string('name'); $t->string('hotel')->nullable(); $t->string('room_number', 40)->nullable();
            $t->string('phone', 40)->nullable()->index(); $t->json('contacts'); $t->string('email')->nullable(); $t->text('notes')->nullable(); $t->timestamps();
            $t->index('name');
        });
        Schema::create('bookings', function (Blueprint $t) use ($money) {
            $t->id(); $t->string('receipt_number', 40)->unique(); $t->foreignId('customer_id')->constrained();
            $t->string('travel_desk')->nullable(); $t->foreignId('sales_person_id')->nullable()->constrained('users')->nullOnDelete(); $t->foreignId('created_by_id')->constrained('users');
            $t->string('status', 20)->default('confirmed'); $t->string('payment_status', 20)->default('unpaid'); $t->char('base_currency', 3)->default('AED');
            foreach (['standard_total', 'discount_total', 'total_amount', 'paid_amount', 'refunded_amount', 'balance_due'] as $c) $money($t, $c);
            $t->string('balance_collection', 12)->default('travel_desk'); $t->foreignId('terms_id')->nullable()->constrained('terms')->nullOnDelete(); $t->text('terms_override')->nullable();
            $t->longText('customer_signature')->nullable(); $t->longText('agent_signature')->nullable(); $t->text('notes')->nullable();
            $t->timestamp('issued_at')->useCurrent()->index(); $t->timestamp('last_emailed_at')->nullable(); $t->timestamps();
        });
        Schema::create('price_approvals', function (Blueprint $t) use ($money) {
            $t->id(); $t->foreignId('requested_by_id')->constrained('users')->cascadeOnDelete(); $t->foreignId('tour_id')->constrained()->cascadeOnDelete(); $t->unsignedBigInteger('option_id')->nullable();
            $t->string('tour_name'); $t->string('option_name')->nullable(); $t->unsignedInteger('adults'); $t->unsignedInteger('children'); $t->unsignedInteger('infants');
            $money($t, 'standard_total'); $money($t, 'min_total'); $money($t, 'requested_total'); $t->string('customer_name')->nullable(); $t->text('reason')->nullable(); $t->json('snapshot')->nullable();
            $t->string('status', 12)->default('pending'); $t->foreignId('decided_by_id')->nullable()->constrained('users')->nullOnDelete(); $t->timestamp('decided_at')->nullable(); $t->string('decision_note')->nullable();
            $t->unsignedBigInteger('booking_item_id')->nullable(); $t->timestamp('expires_at'); $t->timestamps();
        });
        Schema::create('booking_items', function (Blueprint $t) use ($money) {
            $t->id(); $t->foreignId('booking_id')->constrained()->cascadeOnDelete(); $t->foreignId('tour_id')->constrained(); $t->foreignId('option_id')->nullable()->constrained('tour_options')->nullOnDelete();
            $t->string('tour_code', 20)->unique(); $t->string('tour_name'); $t->string('option_name')->nullable(); $t->string('product_type', 10); $t->date('tour_date')->index();
            $t->unsignedInteger('adults')->default(0); $t->unsignedInteger('children')->default(0); $t->unsignedInteger('infants')->default(0);
            $t->string('transfer_type', 10)->default('none'); $t->string('transfer_direction', 10)->nullable(); $t->string('transfer_pricing', 10)->nullable();
            $t->foreignId('vehicle_id')->nullable()->constrained()->nullOnDelete(); $t->string('vehicle_name')->nullable(); $t->unsignedInteger('vehicle_count')->default(0);
            $t->foreignId('slot_id')->nullable()->constrained('pickup_slots')->nullOnDelete(); $t->string('pickup_time', 20)->nullable(); $t->string('drop_time', 20)->nullable();
            $t->string('pickup_location')->nullable(); $t->string('drop_location')->nullable(); $t->json('breakdown');
            $money($t, 'standard_price'); $money($t, 'discount'); $t->decimal('agreed_price', 14, 2)->nullable();
            foreach (['sold_adult_price', 'sold_child_price', 'sold_infant_price', 'min_total'] as $c) $t->decimal($c, 14, 2)->nullable();
            $money($t, 'total'); $t->string('status', 12)->default('active'); $t->text('notes')->nullable();
            $t->foreignId('supplier_id')->nullable()->constrained()->nullOnDelete(); $money($t, 'supplier_cost'); $t->boolean('supplier_cost_manual')->default(false);
            $t->foreignId('supplier_assigned_by_id')->nullable()->constrained('users')->nullOnDelete(); $t->timestamp('supplier_assigned_at')->nullable();
            $t->foreignId('price_approval_id')->nullable()->constrained('price_approvals')->nullOnDelete(); $t->timestamps();
        });
        Schema::create('booking_item_addons', function (Blueprint $t) use ($money) {
            $t->id(); $t->foreignId('booking_item_id')->constrained()->cascadeOnDelete(); $t->foreignId('addon_id')->nullable()->constrained()->nullOnDelete();
            $t->string('name'); $t->string('pricing_method', 12); $t->unsignedInteger('quantity'); $money($t, 'unit_price'); $money($t, 'total');
        });

        // ---------------- Money ----------------
        Schema::create('payments', function (Blueprint $t) use ($money) {
            $t->id(); $t->foreignId('booking_id')->constrained()->cascadeOnDelete(); $t->foreignId('booking_item_id')->nullable()->constrained()->nullOnDelete();
            $t->string('method', 12); $t->char('currency', 3); $money($t, 'amount'); $t->decimal('exchange_rate', 14, 6); $money($t, 'base_amount');
            foreach (['tendered_base', 'overpayment_base', 'change_amount', 'change_base', 'rounding_base'] as $c) $money($t, $c);
            $t->char('change_currency', 3)->nullable(); $t->string('reference')->nullable(); $t->string('provider')->nullable(); $t->string('card_type', 30)->nullable();
            $t->boolean('is_deposit')->default(false); $t->string('status', 10)->default('active'); $t->string('void_reason')->nullable(); $t->foreignId('voided_by_id')->nullable()->constrained('users')->nullOnDelete();
            $t->text('notes')->nullable(); $t->foreignId('user_id')->constrained('users'); $t->string('slip_path')->nullable(); $t->string('slip_name')->nullable(); $t->timestamp('paid_at')->useCurrent()->index();
        });
        Schema::create('refunds', function (Blueprint $t) use ($money) {
            $t->id(); $t->foreignId('booking_id')->constrained()->cascadeOnDelete(); $t->foreignId('payment_id')->nullable()->constrained()->nullOnDelete();
            $t->char('currency', 3); $money($t, 'amount'); $t->decimal('exchange_rate', 14, 6); $money($t, 'base_amount'); $t->string('method', 20); $t->string('reference')->nullable();
            $t->string('reason'); $t->foreignId('user_id')->constrained('users'); $t->timestamp('created_at')->useCurrent();
        });
        Schema::create('tickets', function (Blueprint $t) {
            $t->id(); $t->foreignId('booking_id')->constrained()->cascadeOnDelete(); $t->foreignId('booking_item_id')->constrained()->cascadeOnDelete(); $t->string('tour_code', 20);
            $t->string('ticket_type')->nullable(); $t->string('ticket_number')->nullable(); $t->date('ticket_date')->nullable(); $t->string('status', 12)->default('active'); $t->boolean('still_usable')->default(true);
            $t->string('file_path')->nullable(); $t->string('file_name')->nullable(); $t->unsignedBigInteger('reissued_from_id')->nullable(); $t->text('notes')->nullable();
            $t->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete(); $t->timestamps();
        });
        Schema::create('supplier_transactions', function (Blueprint $t) use ($money) {
            $t->id(); $t->foreignId('supplier_id')->constrained()->cascadeOnDelete(); $t->string('type', 20); $money($t, 'amount'); $t->string('reference')->nullable(); $t->text('notes')->nullable();
            $t->foreignId('booking_id')->nullable()->constrained()->nullOnDelete(); $t->foreignId('payment_id')->nullable()->constrained()->nullOnDelete();
            $t->foreignId('user_id')->constrained('users'); $t->timestamp('occurred_at')->useCurrent();
        });
        Schema::create('supplier_reviews', function (Blueprint $t) {
            $t->id(); $t->foreignId('supplier_id')->nullable()->constrained()->cascadeOnDelete(); $t->foreignId('tour_id')->nullable()->constrained()->nullOnDelete();
            $t->foreignId('booking_item_id')->nullable()->constrained()->nullOnDelete(); $t->string('tour_code', 20)->nullable(); $t->unsignedTinyInteger('rating'); $t->text('comment')->nullable();
            $t->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete(); $t->timestamp('created_at')->useCurrent();
        });
        Schema::create('cash_handovers', function (Blueprint $t) {
            $t->id(); $t->foreignId('agent_id')->constrained('users')->cascadeOnDelete(); $t->foreignId('collected_by_id')->constrained('users')->cascadeOnDelete(); $t->timestamp('collected_at')->useCurrent(); $t->text('notes')->nullable();
        });
        Schema::create('cash_handover_lines', function (Blueprint $t) use ($money) {
            $t->id(); $t->foreignId('cash_handover_id')->constrained()->cascadeOnDelete(); $t->char('currency', 3); $money($t, 'amount'); $money($t, 'expected');
        });

        // ---------------- Staff ----------------
        Schema::create('attendance', function (Blueprint $t) use ($money) {
            $t->id(); $t->foreignId('user_id')->constrained()->cascadeOnDelete(); $t->date('date');
            foreach (['expected_in', 'expected_out', 'actual_in', 'actual_out'] as $c) $t->string($c, 5)->nullable();
            foreach (['minutes_worked', 'late_minutes', 'late_hours', 'early_minutes', 'early_hours'] as $c) $t->unsignedInteger($c)->default(0);
            $money($t, 'late_fine'); $money($t, 'early_fine'); $t->string('late_calc')->nullable(); $t->string('early_calc')->nullable();
            $t->boolean('is_day_off')->default(false); $t->text('notes')->nullable(); $t->timestamps(); $t->unique(['user_id', 'date']);
        });
        Schema::create('days_off', function (Blueprint $t) {
            $t->id(); $t->foreignId('user_id')->constrained()->cascadeOnDelete(); $t->date('date'); $t->string('type', 30)->default('day_off'); $t->text('notes')->nullable(); $t->timestamps(); $t->unique(['user_id', 'date']);
        });
        Schema::create('fines', function (Blueprint $t) use ($money) {
            $t->id(); $t->foreignId('user_id')->constrained()->cascadeOnDelete(); $t->string('type', 20); $money($t, 'amount'); $t->date('date'); $t->string('reason'); $t->text('notes')->nullable();
            $t->string('status', 12)->default('outstanding'); $t->foreignId('attendance_id')->nullable()->constrained('attendance')->cascadeOnDelete(); $t->foreignId('created_by_id')->nullable()->constrained('users')->nullOnDelete(); $t->timestamps();
        });
        Schema::create('commission_plans', function (Blueprint $t) {
            $t->id(); $t->string('scope', 30)->unique(); $t->foreignId('user_id')->nullable()->constrained()->cascadeOnDelete(); $t->string('tier_mode', 12)->default('flat'); $t->json('tiers');
            $t->boolean('high_sale_enabled')->default(true); $t->decimal('high_sale_markup_pct', 8, 2)->default(50); $t->decimal('high_sale_rate', 6, 2)->default(5); $t->string('high_sale_basis', 8)->default('sale');
            $t->json('negative_tiers'); $t->timestamps();
        });
        Schema::create('salary_advances', function (Blueprint $t) use ($money) {
            $t->id(); $t->foreignId('user_id')->constrained()->cascadeOnDelete(); $money($t, 'amount'); $t->date('date'); $t->char('month', 7); $t->string('reason')->nullable(); $t->string('status', 12)->default('outstanding');
            $t->foreignId('created_by_id')->nullable()->constrained('users')->nullOnDelete(); $t->timestamps();
        });
        Schema::create('payroll_runs', function (Blueprint $t) use ($money) {
            $t->id(); $t->foreignId('user_id')->constrained()->cascadeOnDelete(); $t->char('month', 7); $t->json('breakdown'); $money($t, 'net_pay');
            $t->foreignId('finalized_by_id')->nullable()->constrained('users')->nullOnDelete(); $t->timestamp('finalized_at')->useCurrent(); $t->unique(['user_id', 'month']);
        });

        // ---------------- Logs ----------------
        Schema::create('audit_logs', function (Blueprint $t) {
            $t->id(); $t->unsignedBigInteger('user_id')->nullable()->index(); $t->string('entity_type', 40); $t->unsignedBigInteger('entity_id')->nullable(); $t->string('action', 60); $t->json('details')->nullable(); $t->timestamp('created_at')->useCurrent();
            $t->index(['entity_type', 'entity_id']);
        });
        Schema::create('email_logs', function (Blueprint $t) {
            $t->id(); $t->foreignId('booking_id')->nullable()->constrained()->cascadeOnDelete(); $t->string('template', 60); $t->string('recipient'); $t->string('subject'); $t->string('status', 10); $t->text('error')->nullable();
            $t->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete(); $t->timestamp('created_at')->useCurrent();
        });
    }

    public function down(): void
    {
        foreach (['email_logs', 'audit_logs', 'payroll_runs', 'salary_advances', 'commission_plans', 'fines', 'days_off', 'attendance', 'cash_handover_lines', 'cash_handovers',
            'supplier_reviews', 'supplier_transactions', 'tickets', 'refunds', 'payments', 'booking_item_addons', 'booking_items', 'price_approvals', 'bookings', 'customers',
            'supplier_services_info', 'supplier_vehicle_costs', 'supplier_addon_costs', 'supplier_prices', 'tour_suppliers', 'pickup_slots', 'vehicles', 'addons', 'tour_options', 'tours',
            'suppliers', 'hotels', 'travel_desks', 'email_templates', 'terms', 'exchange_rates', 'currencies', 'counters', 'settings', 'employee_schedules', 'sessions', 'password_reset_tokens', 'users', 'roles'] as $t) {
            Schema::dropIfExists($t);
        }
    }
};
