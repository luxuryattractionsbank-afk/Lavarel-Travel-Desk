# Luxury Attractions Tourism – Travel Desk System (Laravel + MySQL)
## Master Record File

| | |
|---|---|
| Company | Luxury Attractions Tourism · +971 52 888 5145 · salesdesk@luxuryattractions.com |
| Technology | Laravel 12 (PHP 8.2+), MySQL 5.7+/MariaDB 10.3+, Blade + Alpine.js, Tailwind CSS (pre-compiled), DomPDF |
| Install | Upload zip → MySQL database → web installer at `/install` (locks itself) |
| Upgrades | Laravel migrations; admin button *Settings → System → Run database update* |
| Currency / time zone | AED base (configurable), USD/EUR/GBP cash · Asia/Dubai |

## Modules
| Menu | Functions |
|---|---|
| Dashboard | Today's bookings, sales, outstanding; monthly sales; pending payments; upcoming tours; recent receipts; outstanding balances; staff attendance; fines; tickets needing upload; check-in |
| New Booking | Customer (title, name, hotel list, room, **multiple contact numbers** with Call/WhatsApp/Telegram/Viber/other, email); travel desk; sales person; **+ Add Another Tour** with **searchable tour/ticket picker** (code or name); options with age restrictions; passengers; transfer none/shared/private, one/two-way, pick-up windows, vehicles with capacity check, drop-back calculation; add-ons with own agreed price; per-person agreed prices; discount/agreed total; live price; **minimum-price approval request**; split-currency payments with change; deposit; allocation; balance collection (desk/driver); terms; signatures |
| Bookings & Receipts | Search (receipt, tour code, name, any phone number, hotel, room, desk, agent, ticket no.), filters; **Table view** with Excel-style column filter/sort, payment columns, **Copy Text** column, copy-all, CSV export |
| Booking page | Items + breakdown, agreed rates, **copy text** (with add-ons), supplier assignment, review, tickets (upload / status / reissue), payment history, record payment (with change), slips, void, refunds, driver collection, status, signatures, email, print A4/thermal, PDF, audit history, delete |
| Price Approvals | Requests below minimum → approver (other login) gets a 🔔 count; approve/reject with note; valid 24 h, single use; server re-checks tour/option/pax/price |
| Tickets | Ticket products awaiting upload; all tickets; reissue trail |
| Tours & Products | Product knowledge base: type, code prefix, description, hours, validity, days, transfer rules, duration, **options with adult/child/infant prices + minimum prices**, age rules, **add-ons with minimum price**, time slots, vehicles, **supplier tick-boxes** + default supplier |
| Suppliers | Details, WhatsApp group, platform login (**encrypted password**), tours offered, **price list per tour pre-filled from the product** (options, add-ons, vehicles, times, itinerary), reviews, account ledger (cost / payments / driver collections / adjustments / due) |
| Supplier Assignment | Queue of bookings without supplier; assigning adds that supplier's cost to their account |
| Reviews | Permission-based writing; supplier name visible only with "see supplier" permission |
| Cash Custody | Cash held per agent & currency (received − change − cash refunds − handed over); collection record with collector, date/time, shortage |
| Payroll & Commission | Team/agent plans: commission tiers (flat/progressive), high-sale commission, negative sales production, salary, advances, fines, net pay; finalize/reopen |
| Reports | Daily/monthly, by tour, option, agent, desk, method, currency (cash drawer), outstanding; CSV |
| Attendance / Fines | Check-in/out, fine engine (threshold rule shown), days off, audited corrections, manual fines |
| Staff, Audit, Settings, Profile | Employees & schedules; full audit log (incl. deleted-record copies); company/logo, currencies/rates/base, numbering, payments, fine rules, SMTP & templates, terms, desks & hotels, roles & permissions, system/update |

## Permissions (assignable per role in Settings → Roles)
bookings.create · bookings.view_all · bookings.edit · bookings.cancel · bookings.terms_override · bookings.select_salesperson · payments.record · payments.void · refunds.process · receipts.print · receipts.email · tickets.manage · tours.manage · reports.view · reports.own_sales · attendance.self · attendance.manage · fines.manage · users.manage · settings.manage · audit.view · **records.delete** · **pricing.approve** · **pricing.override** · **cash.collect** · cash.own · **commission.manage** · commission.own · suppliers.view · suppliers.manage · **suppliers.assign** · suppliers.payments · **reviews.write** · **reviews.see_supplier**.
Admin has all; Sales Agent default: create bookings, record payments, print/email receipts, own sales, own attendance, own cash, own commission, write reviews.

## Key rules
- Receipt numbers `LA-{YYYY}-{SEQ:5}`, tour codes `{PREFIX}{SEQ:3}` (e.g. DS001) – unique, searchable, configurable.
- Pricing engine runs in the browser (preview) and on the server (authoritative): per person / per vehicle (group charge) / per group, add-ons, shared transfer included or extra, capacity checks, age restrictions, minimum prices per category and add-on.
- All accounting in base currency; each payment keeps original currency, amount and the rate used; balance shown in the next payment's currency; unlimited change in any currency (applied amount, change and kept amount recorded).
- Supplier cost = assigned supplier's option price × pax (or group) + vehicle cost + add-on costs. Balance due = cost + adjustments − payments − driver collections.
- Fines: first late hour from the threshold, further hours from the expected time (09:15/09:45 → 1 h = AED 40; 10:15/10:45 → 2 h = AED 60); none on days off.
- Delete: permission-based, heavy records need typing DELETE, blocked for tours in use / staff with sales / own account / built-in roles; copy kept in the audit log.
- Security: bcrypt passwords, sessions, CSRF on every form, permission checks on every route, SQL via query builder (bound parameters), Blade escaping, private file storage with access checks, no card data stored.

## Database (MySQL, 50 tables incl. Laravel's)
roles, users, employee_schedules, settings, counters, currencies, exchange_rates, terms, email_templates, travel_desks, hotels, suppliers, tours, tour_options, addons, vehicles, pickup_slots, tour_suppliers, supplier_prices, supplier_addon_costs, supplier_vehicle_costs, supplier_services_info, customers, bookings, price_approvals, booking_items, booking_item_addons, payments, refunds, tickets, supplier_transactions, supplier_reviews, cash_handovers, cash_handover_lines, attendance, days_off, fines, commission_plans, salary_advances, payroll_runs, audit_logs, email_logs (+ Laravel: migrations, sessions, cache, jobs, password_reset_tokens…).

## Folders
`app/Support` (engines: Pricing, BookingService, SupplierCost, Fines, Finance, Installer, Seeder) · `app/Http/Controllers` · `resources/views` · `database/migrations` · `public/` (web root: index.php, css, js) · `storage/` (uploads, logs – back up) · `.env` (settings & key – back up) · `docs/`.
