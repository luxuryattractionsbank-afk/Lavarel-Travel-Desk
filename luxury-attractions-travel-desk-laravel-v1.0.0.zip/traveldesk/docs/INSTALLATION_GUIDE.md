# Installation Guide – Luxury Attractions Travel Desk (Laravel + MySQL)
### Install on a subdomain (e.g. `desk.luxuryattractions.com`) – no programming needed

This installs like WordPress or any Laravel script: **upload → create a MySQL database → open the site → fill in the setup form.**

**You need:** normal cPanel hosting with **PHP 8.2 or newer** and **MySQL/MariaDB** (almost every host has this), and the file `luxury-attractions-travel-desk-laravel-v1.0.0.zip`.

---

### Step 1 – Set PHP to 8.2 or newer
cPanel → **Select PHP Version** (or **MultiPHP Manager**) → choose **8.2** or **8.3** for your account or subdomain.
If there is an **Extensions** tab, make sure these are ticked: `pdo_mysql`, `mbstring`, `openssl`, `xml`/`dom`, `curl`, `gd`, `zip`, `fileinfo`, `bcmath`. Most are on by default.

### Step 2 – Create the subdomain
cPanel → **Domains** (or **Subdomains**) → **Create A New Domain** → type `desk.luxuryattractions.com`.
Untick "Share document root" and set the **Document Root** to: `traveldesk/public`
(the **/public** at the end matters – it keeps the program files private).

### Step 3 – Create the MySQL database
cPanel → **MySQL® Database Wizard**:
1. Database name: `traveldesk` → Next (cPanel shows the full name, e.g. `myuser_traveldesk`).
2. Username: `desk`, generate a strong password → Create User (full name e.g. `myuser_desk`).
3. Tick **ALL PRIVILEGES** → Next.
**Write down:** database name, username and password. The host is `localhost` and the port is `3306`.

### Step 4 – Upload the app
1. cPanel → **File Manager** → go to your home folder and open (or create) the folder **`traveldesk`**.
2. **Upload** the zip file, then right-click it → **Extract**.
3. Check that `artisan`, `composer.json` and the folders `app`, `public`, `vendor`, `storage` are **directly inside `traveldesk`**. (If they are inside an extra sub-folder, move them up one level.) Delete the zip.
4. Right-click the folders **`storage`** and **`bootstrap/cache`** → **Change Permissions** → **755** (tick "recurse" if offered). Do the same for the `traveldesk` folder itself so the installer can create the settings file.

### Step 5 – Switch on https
cPanel → **SSL/TLS Status** → tick your subdomain → **Run AutoSSL**.

### Step 6 – Run the web installer
Open **`https://desk.luxuryattractions.com`** – the **Travel Desk – Installation** page opens automatically.
1. **Server check** – every line should show ✓ (if not, see Troubleshooting).
2. **MySQL database** – host `localhost`, port `3306`, and the database name, username and password from Step 3 → **Test connection**. Mistakes show a clear message (e.g. "Wrong database username or password").
3. **Company & administrator** – check the company details, enter your name, email, an admin username and password (twice), choose whether to add the example tours → **Install now**.
4. After about a minute you are taken to the login page. Sign in with the admin username and password you chose.

The installer locks itself afterwards (file `storage/installed.lock`). **Complete Step 6 straight after uploading.**

---

### If your host cannot point the subdomain to `/public`
Set the document root to `traveldesk` instead. The included `.htaccess` file then forwards everything to `public/` and blocks the private folders. (Pointing to `/public` is still the recommended, most secure setup.)

### After installing
1. **My Profile** – draw your signature, change your password if needed.
2. **Settings → Company** – logo, favicon, address, receipt header/footer, legal text.
3. **Settings → Currency** – check the USD/EUR/GBP rates.
4. **Settings → Terms** – your terms & conditions.
5. **Settings → Email** – SMTP details (cPanel → Email Accounts → *Connect Devices* shows them) so receipts can be emailed.
6. **Tours & Products** – edit/delete the examples, add your tours, options, minimum prices, add-ons, time slots.
7. **Suppliers** – add suppliers, tick the tours they offer, fill in their price lists.
8. **Settings → Roles** and **Accounts / Staff** – create roles (e.g. Supervisor) and staff logins.

### Backups
cPanel → **Backup** → download the **MySQL database** (`myuser_traveldesk`) and the **`traveldesk/storage`** folder (uploaded tickets, slips, logo) regularly. Keep a copy of the **`.env`** file – it contains the encryption key.

### Troubleshooting
| Problem | Fix |
|---|---|
| "500 Server Error" right after uploading | PHP version is below 8.2 (Step 1), or `storage` / `bootstrap/cache` are not writable (Step 4.4). |
| Server check shows ✕ for a PHP extension | cPanel → Select PHP Version → Extensions → tick it. |
| Server check shows ✕ "writable" | File Manager → Change Permissions → 755 on `traveldesk`, `storage`, `bootstrap/cache`. |
| "Wrong database username or password" / "database does not exist" | Use the **full** names with the `myuser_` prefix and make sure the user has ALL PRIVILEGES on the database. |
| You see a file listing or "Index of /" | The document root is not `traveldesk/public` (Step 2). |
| Receipt emails fail | Settings → Email → enter SMTP details; the error is shown on the booking page. |
| Run the installer again | Delete `storage/installed.lock` and `.env`, then open the site. |
