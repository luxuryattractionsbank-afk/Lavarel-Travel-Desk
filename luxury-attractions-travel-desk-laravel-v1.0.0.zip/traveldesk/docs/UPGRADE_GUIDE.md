# Upgrade Guide – keep all records

All records (bookings, payments, staff, settings) live in the **MySQL database**; uploads live in **`storage/`**; settings and the encryption key live in **`.env`**. Upgrades never touch these.

## Steps (cPanel, no terminal)
1. **Back up**: cPanel → Backup → download the MySQL database and the `traveldesk/storage` folder, and copy `.env`.
2. File Manager → `traveldesk` → upload the new zip → **Extract**, choosing to **overwrite** files. **Do not delete** `.env` or `storage/`.
3. Log in as admin → **Settings → System** → **Run database update**. (It applies only new changes – existing records are kept.)
4. Done – Settings → System shows the new version.

## For developers
- Database changes are Laravel migrations in `database/migrations/`. Add a **new** migration for every change – never edit released ones. Prefer additive changes (new tables/columns, nullable or with defaults).
- Terminal alternative: `php artisan migrate --force`.
- Build the stylesheet after changing views: `node build-css.mjs` (requires Tailwind CSS 4 via npm), then package with `composer install --no-dev --optimize-autoloader`.
