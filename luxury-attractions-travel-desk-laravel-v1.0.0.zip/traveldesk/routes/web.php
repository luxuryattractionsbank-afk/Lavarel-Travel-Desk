<?php

use App\Http\Controllers as C;
use Illuminate\Support\Facades\Route;

Route::get('/install', [C\InstallController::class, 'show']);
Route::post('/install/test', [C\InstallController::class, 'test']);
Route::post('/install', [C\InstallController::class, 'install']);

Route::get('/login', [C\AuthController::class, 'show'])->name('login');
Route::post('/login', [C\AuthController::class, 'login'])->middleware('throttle:10,1');
Route::get('/branding/{kind}', [C\FileController::class, 'branding']);

Route::middleware('auth')->group(function () {
    Route::post('/logout', [C\AuthController::class, 'logout'])->name('logout');
    Route::get('/', fn () => redirect()->route('dashboard'));
    Route::get('/dashboard', [C\DashboardController::class, 'index'])->name('dashboard');
    Route::get('/files/{type}/{id}', [C\FileController::class, 'show'])->name('file');

    // Bookings
    Route::get('/bookings', [C\BookingController::class, 'index'])->name('bookings');
    Route::get('/bookings/export', [C\BookingController::class, 'export'])->name('bookings.export');
    Route::get('/bookings/new', [C\BookingController::class, 'create'])->middleware('perm:bookings.create')->name('bookings.create');
    Route::post('/bookings', [C\BookingController::class, 'store'])->middleware('perm:bookings.create')->name('bookings.store');
    Route::get('/bookings/{id}', [C\BookingController::class, 'show'])->name('bookings.show');
    Route::get('/bookings/{id}/edit', [C\BookingController::class, 'edit'])->middleware('perm:bookings.edit')->name('bookings.edit');
    Route::put('/bookings/{id}', [C\BookingController::class, 'update'])->middleware('perm:bookings.edit')->name('bookings.update');
    Route::get('/bookings/{id}/receipt', [C\BookingController::class, 'receipt'])->name('bookings.receipt');
    Route::get('/bookings/{id}/pdf', [C\BookingController::class, 'pdf'])->name('bookings.pdf');
    Route::post('/bookings/{id}/email', [C\BookingController::class, 'email'])->middleware('perm:receipts.email')->name('bookings.email');
    Route::post('/bookings/{id}/status', [C\BookingController::class, 'status'])->middleware('perm:bookings.cancel')->name('bookings.status');
    Route::post('/bookings/{id}/signatures', [C\BookingController::class, 'signatures'])->name('bookings.signatures');
    Route::post('/bookings/{id}/payments', [C\PaymentController::class, 'store'])->middleware('perm:payments.record')->name('payments.store');
    Route::post('/payments/{id}/void', [C\PaymentController::class, 'void'])->middleware('perm:payments.void')->name('payments.void');
    Route::post('/payments/{id}/slip', [C\PaymentController::class, 'slip'])->middleware('perm:payments.record')->name('payments.slip');
    Route::post('/bookings/{id}/refunds', [C\PaymentController::class, 'refund'])->middleware('perm:refunds.process')->name('refunds.store');
    Route::post('/bookings/{id}/driver', [C\PaymentController::class, 'driver'])->middleware('perm:suppliers.payments')->name('payments.driver');
    Route::post('/items/{id}/tickets', [C\TicketController::class, 'upload'])->middleware('perm:tickets.manage')->name('tickets.upload');
    Route::post('/tickets/{id}', [C\TicketController::class, 'update'])->middleware('perm:tickets.manage')->name('tickets.update');
    Route::post('/tickets/{id}/reissue', [C\TicketController::class, 'reissue'])->middleware('perm:tickets.manage')->name('tickets.reissue');
    Route::get('/tickets', [C\TicketController::class, 'index'])->middleware('perm:tickets.manage')->name('tickets');
    Route::post('/items/{id}/assign', [C\SupplierController::class, 'assign'])->middleware('perm:suppliers.assign')->name('items.assign');
    Route::post('/items/{id}/review', [C\ReviewController::class, 'store'])->middleware('perm:reviews.write')->name('items.review');

    // Price approvals
    Route::get('/approvals', [C\ApprovalController::class, 'index'])->name('approvals');
    Route::post('/approvals/request', [C\ApprovalController::class, 'request'])->middleware('perm:bookings.create')->name('approvals.request');
    Route::get('/approvals/status', [C\ApprovalController::class, 'status'])->name('approvals.status');
    Route::post('/approvals/{id}/decide', [C\ApprovalController::class, 'decide'])->middleware('perm:pricing.approve')->name('approvals.decide');

    // Tours
    Route::middleware('perm:tours.manage')->group(function () {
        Route::get('/tours', [C\TourController::class, 'index'])->name('tours');
        Route::get('/tours/{id}', [C\TourController::class, 'edit'])->name('tours.edit');
        Route::post('/tours/{id?}', [C\TourController::class, 'save'])->name('tours.save');
        Route::post('/tours/{id}/option', [C\TourController::class, 'option'])->name('tours.option');
        Route::post('/tours/{id}/addon', [C\TourController::class, 'addon'])->name('tours.addon');
        Route::post('/tours/{id}/slot', [C\TourController::class, 'slot'])->name('tours.slot');
        Route::post('/vehicles', [C\TourController::class, 'vehicle'])->name('tours.vehicle');
    });

    // Suppliers
    Route::get('/suppliers', [C\SupplierController::class, 'index'])->middleware('perm:suppliers.view,suppliers.manage,suppliers.payments')->name('suppliers');
    Route::get('/suppliers/assign', [C\SupplierController::class, 'queue'])->middleware('perm:suppliers.assign')->name('suppliers.queue');
    Route::get('/suppliers/{id}', [C\SupplierController::class, 'show'])->middleware('perm:suppliers.view,suppliers.manage,suppliers.payments')->name('suppliers.show');
    Route::post('/suppliers/{id?}', [C\SupplierController::class, 'save'])->middleware('perm:suppliers.manage')->name('suppliers.save');
    Route::post('/suppliers/{id}/tours', [C\SupplierController::class, 'tours'])->middleware('perm:suppliers.manage')->name('suppliers.tours');
    Route::post('/suppliers/{id}/prices/{tour}', [C\SupplierController::class, 'prices'])->middleware('perm:suppliers.manage')->name('suppliers.prices');
    Route::post('/suppliers/{id}/tx', [C\SupplierController::class, 'tx'])->middleware('perm:suppliers.payments')->name('suppliers.tx');
    Route::get('/reviews', [C\ReviewController::class, 'index'])->middleware('perm:reviews.write,reviews.see_supplier')->name('reviews');

    // Money & staff
    Route::get('/cash', [C\CashController::class, 'index'])->middleware('perm:cash.collect,cash.own')->name('cash');
    Route::post('/cash/collect', [C\CashController::class, 'collect'])->middleware('perm:cash.collect')->name('cash.collect');
    Route::get('/payroll', [C\PayrollController::class, 'index'])->middleware('perm:commission.manage,commission.own')->name('payroll');
    Route::post('/payroll/{action}', [C\PayrollController::class, 'action'])->middleware('perm:commission.manage')->name('payroll.action');
    Route::get('/attendance', [C\AttendanceController::class, 'index'])->name('attendance');
    Route::post('/attendance/check', [C\AttendanceController::class, 'check'])->middleware('perm:attendance.self')->name('attendance.check');
    Route::post('/attendance/correct', [C\AttendanceController::class, 'correct'])->middleware('perm:attendance.manage')->name('attendance.correct');
    Route::post('/attendance/dayoff', [C\AttendanceController::class, 'dayoff'])->middleware('perm:attendance.manage')->name('attendance.dayoff');
    Route::get('/fines', [C\AttendanceController::class, 'fines'])->name('fines');
    Route::post('/fines', [C\AttendanceController::class, 'fine'])->middleware('perm:fines.manage')->name('fines.save');
    Route::get('/staff', [C\StaffController::class, 'index'])->middleware('perm:users.manage')->name('staff');
    Route::get('/staff/{id}', [C\StaffController::class, 'edit'])->middleware('perm:users.manage')->name('staff.edit');
    Route::post('/staff/{id?}', [C\StaffController::class, 'save'])->middleware('perm:users.manage')->name('staff.save');

    Route::get('/reports', [C\ReportController::class, 'index'])->middleware('perm:reports.view,reports.own_sales')->name('reports');
    Route::get('/reports/export', [C\ReportController::class, 'export'])->middleware('perm:reports.view,reports.own_sales')->name('reports.export');
    Route::get('/audit', [C\AuditController::class, 'index'])->middleware('perm:audit.view')->name('audit');
    Route::post('/delete/{entity}/{id}', [C\DeleteController::class, 'destroy'])->middleware('perm:records.delete')->name('delete');

    Route::get('/settings', [C\SettingsController::class, 'index'])->middleware('perm:settings.manage,users.manage')->name('settings');
    Route::post('/settings/{section}', [C\SettingsController::class, 'save'])->middleware('perm:settings.manage,users.manage')->name('settings.save');
    Route::get('/profile', [C\ProfileController::class, 'index'])->name('profile');
    Route::post('/profile', [C\ProfileController::class, 'save'])->name('profile.save');
});
