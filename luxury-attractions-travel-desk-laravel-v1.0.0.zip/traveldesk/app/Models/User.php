<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Facades\DB;

class User extends Authenticatable
{
    protected $guarded = ['id'];
    protected $hidden = ['password', 'remember_token'];
    protected $casts = ['password' => 'hashed'];
    private ?array $permCache = null;

    public function permissions(): array
    {
        if ($this->permCache === null) {
            $p = DB::table('roles')->where('id', $this->role_id)->value('permissions');
            $this->permCache = $p ? (json_decode($p, true) ?: []) : [];
        }
        return $this->permCache;
    }

    public function can($ability, $arguments = []): bool
    {
        $p = $this->permissions();
        return in_array('*', $p, true) || in_array($ability, $p, true);
    }

    public function roleName(): string { return (string) DB::table('roles')->where('id', $this->role_id)->value('name'); }
}
