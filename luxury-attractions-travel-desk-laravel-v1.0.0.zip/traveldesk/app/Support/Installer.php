<?php

namespace App\Support;

use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use PDO;

class Installer
{
    public static function lockPath(): string { return storage_path('installed.lock'); }

    public static function installed(): bool
    {
        if (file_exists(self::lockPath())) return true;
        if (! env('DB_DATABASE')) return false;
        try {
            if (DB::getSchemaBuilder()->hasTable('users') && DB::table('users')->count() > 0) {
                @file_put_contents(self::lockPath(), 'Installed '.now().' (existing database detected)');
                return true;
            }
        } catch (\Throwable) {
        }
        return false;
    }

    public static function requirements(): array
    {
        $ext = fn ($e) => extension_loaded($e);
        return [
            ['PHP 8.2 or newer', version_compare(PHP_VERSION, '8.2.0', '>='), 'Running PHP '.PHP_VERSION],
            ['PDO MySQL extension', $ext('pdo_mysql'), 'pdo_mysql'],
            ['mbstring, openssl, xml, curl, gd extensions', $ext('mbstring') && $ext('openssl') && $ext('dom') && $ext('curl') && $ext('gd'), 'needed for receipts, PDFs and email'],
            ['.env file writable', is_writable(base_path('.env')) || (! file_exists(base_path('.env')) && is_writable(base_path())), base_path('.env')],
            ['storage/ folder writable', is_writable(storage_path()), storage_path()],
            ['bootstrap/cache writable', is_writable(base_path('bootstrap/cache')), 'bootstrap/cache'],
        ];
    }

    public static function testDb(array $c): string
    {
        try {
            $pdo = new PDO("mysql:host={$c['host']};port={$c['port']};dbname={$c['database']};charset=utf8mb4", $c['username'], $c['password'], [PDO::ATTR_TIMEOUT => 8, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
            $v = $pdo->query('select version()')->fetchColumn();
            return "Connected – MySQL/MariaDB $v, database “{$c['database']}”.";
        } catch (\PDOException $e) {
            $m = $e->getMessage();
            if (str_contains($m, 'Access denied')) throw new \RuntimeException('Wrong database username or password (or the user is not added to this database).');
            if (str_contains($m, 'Unknown database')) throw new \RuntimeException('That database name does not exist – use the full name shown in cPanel (e.g. myuser_traveldesk).');
            if (str_contains($m, 'Connection refused') || str_contains($m, 'getaddrinfo') || str_contains($m, 'timed out')) throw new \RuntimeException('Cannot reach the database server – on cPanel the host is usually localhost and the port 3306.');
            throw new \RuntimeException($m);
        }
    }

    public static function writeEnv(array $values): void
    {
        $file = base_path('.env');
        $env = file_exists($file) ? file_get_contents($file) : (file_exists(base_path('.env.example')) ? file_get_contents(base_path('.env.example')) : '');
        foreach ($values as $k => $v) {
            $v = preg_match('/[\s#"\'$]/', (string) $v) ? '"'.str_replace(['\\', '"'], ['\\\\', '\\"'], (string) $v).'"' : (string) $v;
            if (preg_match("/^{$k}=.*$/m", $env)) $env = preg_replace("/^{$k}=.*$/m", str_replace(['\\', '$'], ['\\\\', '\\$'], "$k=$v"), $env);
            else $env .= "\n$k=$v";
        }
        file_put_contents($file, trim($env)."\n");
    }

    public static function install(array $db, array $i): void
    {
        $url = rtrim(request()->getSchemeAndHttpHost().request()->getBaseUrl(), '/');
        self::writeEnv([
            'APP_NAME' => 'Luxury Attractions Travel Desk', 'APP_ENV' => 'production', 'APP_DEBUG' => 'false', 'APP_URL' => $url,
            "APP_KEY" => env('APP_KEY') ?: 'base64:'.base64_encode(random_bytes(32)), 'APP_TIMEZONE' => 'Asia/Dubai',
            'DB_CONNECTION' => 'mysql', 'DB_HOST' => $db['host'], 'DB_PORT' => $db['port'], 'DB_DATABASE' => $db['database'], 'DB_USERNAME' => $db['username'], 'DB_PASSWORD' => $db['password'],
            'SESSION_DRIVER' => 'file', 'CACHE_STORE' => 'file', 'QUEUE_CONNECTION' => 'sync', 'MAIL_MAILER' => 'log',
        ]);
        config(['database.connections.mysql' => array_merge(config('database.connections.mysql'), [
            'host' => $db['host'], 'port' => $db['port'], 'database' => $db['database'], 'username' => $db['username'], 'password' => $db['password'],
        ]), 'database.default' => 'mysql']);
        DB::purge('mysql');
        DB::reconnect('mysql');
        Artisan::call('migrate', ['--force' => true]);
        Seeder::run($i['admin_password'], $i['example_data']);
        Settings::save('company', ['name' => $i['company_name'], 'phone' => $i['company_phone'], 'email' => $i['company_email']]);
        $adminId = DB::table('users')->join('roles', 'roles.id', '=', 'users.role_id')->where('roles.key', 'admin')->min('users.id');
        DB::table('users')->where('id', $adminId)->update(['username' => strtolower($i['admin_username']), 'email' => $i['admin_email'], 'full_name' => $i['admin_name'], 'display_name' => Str::before($i['admin_name'], ' ') ?: $i['admin_name'], 'password' => Hash::make($i['admin_password'])]);
        if (! $i['demo_agent']) DB::table('users')->where('username', 'agent')->update(['status' => 'inactive']);
        Audit::log('system', null, 'installed', ['company' => $i['company_name'], 'admin' => $i['admin_username']], $adminId);
        file_put_contents(self::lockPath(), 'Installed '.now().' – delete this file only to run the web installer again.');
        foreach (['config:clear', 'route:clear', 'view:clear'] as $c) { try { Artisan::call($c); } catch (\Throwable) {} }
    }
}
