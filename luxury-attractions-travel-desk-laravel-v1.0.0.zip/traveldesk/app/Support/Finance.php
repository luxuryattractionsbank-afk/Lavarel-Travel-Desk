<?php

namespace App\Support;

use Illuminate\Support\Facades\DB;

class Finance
{
    /** Recalculate booking totals, payment status and automatic status. */
    public static function recalc(int $bookingId): void
    {
        $b = DB::table('bookings')->where('id', $bookingId)->first();
        if (! $b) return;
        $items = DB::table('booking_items')->where('booking_id', $bookingId)->where('status', '!=', 'cancelled')
            ->selectRaw('coalesce(sum(standard_price),0) std, coalesce(sum(discount),0) disc, coalesce(sum(total),0) tot')->first();
        $paid = (float) DB::table('payments')->where('booking_id', $bookingId)->where('status', 'active')->sum('base_amount');
        $ref = (float) DB::table('refunds')->where('booking_id', $bookingId)->sum('base_amount');
        $total = round((float) $items->tot, 2);
        $cancelled = $b->status === 'cancelled';
        $ps = Pricing::paymentStatus($total, $paid, $ref, $cancelled);
        $status = $b->status;
        if (in_array($b->status, ['confirmed', 'partially_paid', 'paid', 'pending'])) {
            $status = match ($ps) { 'paid' => 'paid', 'partially_paid' => 'partially_paid', 'refunded' => 'refunded', default => $b->status === 'pending' ? 'pending' : 'confirmed' };
        }
        DB::table('bookings')->where('id', $bookingId)->update([
            'standard_total' => round((float) $items->std, 2), 'discount_total' => round((float) $items->disc, 2), 'total_amount' => $total,
            'paid_amount' => round($paid, 2), 'refunded_amount' => round($ref, 2), 'balance_due' => $cancelled ? 0 : round(max(0, $total - $paid), 2),
            'payment_status' => $ps, 'status' => $status, 'updated_at' => now(),
        ]);
        if ($status !== $b->status) Audit::log('booking', $bookingId, 'status_changed', ['from' => $b->status, 'to' => $status, 'auto' => true]);
    }

    public static function rate(string $code): float
    {
        return (float) (DB::table('currencies')->where('code', $code)->value('rate_to_base') ?? 1);
    }
}
