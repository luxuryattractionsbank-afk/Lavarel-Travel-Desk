<?php

namespace App\Support;

use Illuminate\Support\Facades\DB;

class SupplierCost
{
    /** Default supplier for a new booking item: the tour's default supplier, or the only linked supplier. */
    public static function auto(int $tourId): ?int
    {
        $def = DB::table('tours')->where('id', $tourId)->value('supplier_id');
        if ($def) return (int) $def;
        $ids = DB::table('tour_suppliers')->where('tour_id', $tourId)->pluck('supplier_id');
        return $ids->count() === 1 ? (int) $ids[0] : null;
    }

    /** Supplier cost from their price list: option price × pax (or group) + vehicle cost + add-on costs. */
    public static function cost(array $it, ?int $supplierId, array $addonLines): float
    {
        if (! $supplierId) return 0;
        $cost = 0.0;
        if ($it['option_id'] ?? null) {
            $opt = DB::table('tour_options')->where('id', $it['option_id'])->first();
            $p = DB::table('supplier_prices')->where('supplier_id', $supplierId)->where('option_id', $it['option_id'])->first();
            if ($p && $opt && $opt->pricing_method !== 'per_vehicle') {
                $cost += $opt->pricing_method === 'per_group' ? (float) $p->adult_cost : $it['adults'] * $p->adult_cost + $it['children'] * $p->child_cost + $it['infants'] * $p->infant_cost;
            }
        }
        if (($it['transfer_type'] ?? '') === 'private' && ($it['vehicle_id'] ?? null)) {
            $vc = DB::table('supplier_vehicle_costs')->where('supplier_id', $supplierId)->where('vehicle_id', $it['vehicle_id'])->value('cost');
            $vc = $vc ?? DB::table('vehicles')->where('id', $it['vehicle_id'])->value('supplier_cost') ?? 0;
            $cost += $vc * max(1, (int) ($it['vehicle_count'] ?? 1));
        }
        foreach ($addonLines as $a) {
            $c = DB::table('supplier_addon_costs')->where('supplier_id', $supplierId)->where('addon_id', $a['addon_id'])->value('cost');
            $cost += $a['quantity'] * (float) ($c ?? 0);
        }
        return round($cost, 2);
    }

    public static function balances(?array $ids = null): array
    {
        $q = DB::table('suppliers')->select('id');
        if ($ids) $q->whereIn('id', $ids);
        $out = [];
        foreach ($q->pluck('id') as $id) {
            $c = DB::table('booking_items')->join('bookings', 'bookings.id', '=', 'booking_items.booking_id')->where('booking_items.supplier_id', $id)
                ->where('booking_items.status', '!=', 'cancelled')->where('bookings.status', '!=', 'cancelled')->selectRaw('coalesce(sum(supplier_cost),0) c, count(*) n')->first();
            $t = DB::table('supplier_transactions')->where('supplier_id', $id)->selectRaw("coalesce(sum(case when type='payment' then amount end),0) paid, coalesce(sum(case when type='driver_collection' then amount end),0) driver, coalesce(sum(case when type='adjustment' then amount end),0) adj")->first();
            $r = DB::table('supplier_reviews')->where('supplier_id', $id)->selectRaw('avg(rating) a, count(*) n')->first();
            $out[$id] = ['cost' => (float) $c->c, 'items' => (int) $c->n, 'paid' => (float) $t->paid, 'driver' => (float) $t->driver, 'adj' => (float) $t->adj,
                'due' => round($c->c + $t->adj - $t->paid - $t->driver, 2), 'rating' => $r->n ? round($r->a, 1) : null, 'reviews' => (int) $r->n];
        }
        return $out;
    }
}
