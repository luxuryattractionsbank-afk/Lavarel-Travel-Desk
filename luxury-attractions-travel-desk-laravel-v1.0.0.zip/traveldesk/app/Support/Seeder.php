<?php

namespace App\Support;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class Seeder
{
    public static function run(string $adminPassword, bool $examples = true): void
    {
        if (DB::table('roles')->exists()) return;
        $now = now();
        $admin = DB::table('roles')->insertGetId(['key' => 'admin', 'name' => 'Admin', 'permissions' => json_encode(['*']), 'system' => true, 'created_at' => $now, 'updated_at' => $now]);
        $agent = DB::table('roles')->insertGetId(['key' => 'sales_agent', 'name' => 'Sales Agent', 'permissions' => json_encode(Perm::AGENT_DEFAULT), 'system' => true, 'created_at' => $now, 'updated_at' => $now]);
        $a = DB::table('users')->insertGetId(['username' => 'admin', 'email' => 'salesdesk@luxuryattractions.com', 'password' => Hash::make($adminPassword), 'role_id' => $admin, 'full_name' => 'System Administrator', 'display_name' => 'Admin', 'work_mobile' => '+971 52 888 5145', 'work_whatsapp' => true, 'created_at' => $now, 'updated_at' => $now]);
        $g = DB::table('users')->insertGetId(['username' => 'agent', 'email' => 'agent@luxuryattractions.com', 'password' => Hash::make(bin2hex(random_bytes(8))), 'role_id' => $agent, 'full_name' => 'Demo Agent', 'display_name' => 'Agent', 'monthly_salary' => 3000, 'created_at' => $now, 'updated_at' => $now]);
        foreach ([$a, $g] as $u) DB::table('employee_schedules')->insert(['user_id' => $u, 'check_in' => '09:00', 'check_out' => '18:00', 'weekly_days_off' => '[]']);
        DB::table('currencies')->insert([
            ['code' => 'AED', 'name' => 'UAE Dirham', 'symbol' => 'AED', 'rate_to_base' => 1, 'is_base' => true, 'active' => true, 'cash_accepted' => true],
            ['code' => 'USD', 'name' => 'US Dollar', 'symbol' => '$', 'rate_to_base' => 3.6725, 'is_base' => false, 'active' => true, 'cash_accepted' => true],
            ['code' => 'EUR', 'name' => 'Euro', 'symbol' => '€', 'rate_to_base' => 4.0, 'is_base' => false, 'active' => true, 'cash_accepted' => true],
            ['code' => 'GBP', 'name' => 'British Pound', 'symbol' => '£', 'rate_to_base' => 4.65, 'is_base' => false, 'active' => true, 'cash_accepted' => true],
        ]);
        foreach (['Atlantis The Palm Desk' => 'Palm Jumeirah', 'JBR Beach Desk' => 'JBR', 'Downtown Desk' => 'Downtown Dubai'] as $n => $l) DB::table('travel_desks')->insert(['name' => $n, 'location' => $l]);
        foreach (['Atlantis The Palm', 'Atlantis The Royal', 'Burj Al Arab Jumeirah', 'Jumeirah Beach Hotel', 'Address Downtown', 'Armani Hotel Dubai', 'JW Marriott Marquis Dubai', 'Rixos Premium Dubai JBR', 'Sofitel Dubai The Palm', 'Five Palm Jumeirah'] as $h) DB::table('hotels')->insert(['name' => $h]);
        DB::table('terms')->insert(['title' => 'Standard Booking Terms', 'is_default' => true, 'active' => true, 'created_at' => $now, 'updated_at' => $now, 'content' => "1. Cancellations made less than 24 hours before the tour are non-refundable.\n2. Pick-up times are approximate; please be ready in the hotel lobby 10 minutes before the pick-up window.\n3. Tickets are valid only for the date shown unless stated otherwise.\n4. Infants must be accompanied by an adult at all times.\n5. The company is not responsible for delays caused by traffic, weather or third-party suppliers.\n6. Balances due must be settled before the tour starts."]);
        $v = 'Dear {{customer_name}},';
        foreach ([
            ['receipt', 'Receipt', 'Your receipt {{receipt_number}} – {{company_name}}', "$v\n\nThank you for booking with {{company_name}}. Please find attached your receipt {{receipt_number}}.\n\nTours: {{tour_name}}\nDate(s): {{tour_date}}\nTotal: {{total_amount}}\nPaid: {{amount_paid}}\nBalance: {{balance}}\n\nKind regards,\n{{company_name}}"],
            ['booking_confirmation', 'Booking confirmation', 'Booking confirmed – {{receipt_number}}', "$v\n\nYour booking {{receipt_number}} for {{tour_name}} on {{tour_date}} is confirmed.\n\n{{company_name}}"],
            ['payment_confirmation', 'Payment confirmation', 'Payment received – {{receipt_number}}', "$v\n\nWe received your payment. Amount paid: {{amount_paid}}. Remaining balance: {{balance}}.\n\n{{company_name}}"],
            ['ticket_delivery', 'Ticket delivery', 'Your tickets – {{tour_name}}', "$v\n\nPlease find attached your ticket(s) for {{tour_name}} on {{tour_date}}.\n\n{{company_name}}"],
        ] as [$k, $n, $s, $b]) DB::table('email_templates')->insert(['key' => $k, 'name' => $n, 'subject' => $s, 'body' => $b]);
        foreach ([['7 Seater', 7, 450, 300], ['12 Seater', 12, 650, 450], ['14 Seater', 14, 750, 520]] as [$n, $c, $p, $sc]) DB::table('vehicles')->insert(['name' => $n, 'capacity' => $c, 'price' => $p, 'supplier_cost' => $sc]);
        if ($examples) self::examples();
    }

    private static function tour(array $t): int
    {
        return DB::table('tours')->insertGetId(array_merge(['available_days' => json_encode([0, 1, 2, 3, 4, 5, 6]), 'created_at' => now(), 'updated_at' => now()], $t));
    }

    private static function opt(int $tour, array $o): int
    {
        return DB::table('tour_options')->insertGetId(array_merge(['tour_id' => $tour, 'pricing_method' => 'per_person'], $o));
    }

    public static function examples(): void
    {
        $sup = DB::table('suppliers')->insertGetId(['name' => 'Arabian Adventures DMC', 'contact' => 'Operations', 'phone' => '+971 4 000 0000', 'whatsapp_group' => 'AA Desert Ops', 'created_at' => now(), 'updated_at' => now()]);
        $ds = self::tour(['name' => 'Desert Safari', 'code_prefix' => 'DS', 'product_type' => 'tour', 'description' => 'Evening desert safari with dune bashing, camel ride, BBQ dinner and live shows.', 'shared_available' => true, 'private_available' => true, 'duration_minutes' => 360, 'supplier_id' => $sup, 'operating_hours' => 'Daily 14:30 – 21:30', 'pickup_rules' => 'Hotel lobby pick-up within Dubai.', 'notes' => 'Not recommended for pregnant women or guests with back problems.']);
        $n = self::opt($ds, ['name' => 'Normal', 'description' => 'Shared 4x4, BBQ dinner, shows', 'adult_price' => 150, 'child_price' => 120, 'min_adult_price' => 120, 'min_child_price' => 96, 'min_infant_price' => 0, 'sort' => 1]);
        $vip = self::opt($ds, ['name' => 'VIP', 'description' => 'VIP seating, premium dinner', 'adult_price' => 250, 'child_price' => 200, 'min_adult_price' => 200, 'min_child_price' => 160, 'min_infant_price' => 0, 'sort' => 2]);
        self::opt($ds, ['name' => 'Private', 'description' => 'Private 4x4 for your group – charged per vehicle', 'pricing_method' => 'per_vehicle', 'sort' => 3]);
        foreach ([['VIP Upgrade', 'per_person', 100, 80], ['Quad Bike – Single Seater (30 min)', 'per_unit', 150, 120], ['Quad Bike – Two Seater (30 min)', 'per_unit', 250, 200], ['Photography Package', 'per_group', 200, 160]] as [$nm, $m, $p, $mp]) DB::table('addons')->insert(['tour_id' => $ds, 'name' => $nm, 'pricing_method' => $m, 'price' => $p, 'min_price' => $mp]);
        $v7 = DB::table('vehicles')->insertGetId(['tour_id' => $ds, 'name' => 'Private 4x4 – 7 Seater', 'capacity' => 7, 'price' => 1200, 'supplier_cost' => 800]);
        DB::table('vehicles')->insert(['tour_id' => $ds, 'name' => 'Private 4x4 – 12 Seater', 'capacity' => 12, 'price' => 1900, 'supplier_cost' => 1300]);
        DB::table('pickup_slots')->insert([['tour_id' => $ds, 'pickup_start' => '14:30', 'pickup_end' => '15:00', 'drop_start' => '20:30', 'drop_end' => '21:00'], ['tour_id' => $ds, 'pickup_start' => '15:00', 'pickup_end' => '15:30', 'drop_start' => '21:00', 'drop_end' => '21:30']]);
        DB::table('tour_suppliers')->insert(['tour_id' => $ds, 'supplier_id' => $sup]);
        DB::table('supplier_prices')->insert([['supplier_id' => $sup, 'option_id' => $n, 'adult_cost' => 90, 'child_cost' => 70, 'infant_cost' => 0], ['supplier_id' => $sup, 'option_id' => $vip, 'adult_cost' => 160, 'child_cost' => 120, 'infant_cost' => 0]]);
        DB::table('supplier_vehicle_costs')->insert(['supplier_id' => $sup, 'vehicle_id' => $v7, 'cost' => 800, 'hours' => 6]);

        $dc = self::tour(['name' => 'Dubai City Tour', 'code_prefix' => 'DC', 'description' => 'Half-day tour of old and new Dubai.', 'shared_available' => true, 'private_available' => true, 'duration_minutes' => 360]);
        self::opt($dc, ['name' => 'Standard', 'adult_price' => 120, 'child_price' => 90, 'min_adult_price' => 96, 'min_child_price' => 72, 'min_infant_price' => 0]);
        DB::table('pickup_slots')->insert([['tour_id' => $dc, 'pickup_start' => '08:00', 'pickup_end' => '08:30', 'drop_start' => '14:00', 'drop_end' => '14:30'], ['tour_id' => $dc, 'pickup_start' => '09:00', 'pickup_end' => '09:30', 'drop_start' => '15:00', 'drop_end' => '15:30']]);
        $ad = self::tour(['name' => 'Abu Dhabi City Tour', 'code_prefix' => 'AD', 'description' => 'Full-day tour incl. Sheikh Zayed Grand Mosque.', 'shared_available' => true, 'private_available' => true, 'duration_minutes' => 600]);
        self::opt($ad, ['name' => 'Standard', 'adult_price' => 200, 'child_price' => 150, 'min_adult_price' => 150, 'min_child_price' => 120, 'min_infant_price' => 0]);
        DB::table('addons')->insert(['tour_id' => $ad, 'name' => 'Louvre Abu Dhabi Entry', 'pricing_method' => 'per_person', 'price' => 70, 'min_price' => 60]);
        DB::table('pickup_slots')->insert(['tour_id' => $ad, 'pickup_start' => '07:30', 'pickup_end' => '08:00', 'drop_start' => '17:30', 'drop_end' => '18:00']);
        $bk = self::tour(['name' => 'Burj Khalifa', 'code_prefix' => 'BK', 'product_type' => 'ticket', 'description' => 'At the Top observation deck admission.', 'no_transfer_allowed' => true, 'shared_available' => false, 'private_available' => true, 'opening_time' => '08:30', 'closing_time' => '23:00', 'operating_hours' => 'Daily 08:30 – 23:00', 'validity' => 'Selected date & time slot only', 'requires_ticket' => true, 'duration_minutes' => 180]);
        self::opt($bk, ['name' => 'At the Top (124/125) – Non-Prime', 'adult_price' => 169, 'child_price' => 129, 'min_adult_price' => 135, 'min_child_price' => 103, 'min_infant_price' => 0, 'ticket_type' => 'E-ticket', 'ticket_category' => 'Non-Prime', 'sort' => 1]);
        self::opt($bk, ['name' => 'At the Top (124/125) – Prime Hours', 'adult_price' => 249, 'child_price' => 199, 'min_adult_price' => 199, 'min_child_price' => 159, 'min_infant_price' => 0, 'ticket_type' => 'E-ticket', 'ticket_category' => 'Prime', 'sort' => 2]);
        $ly = self::tour(['name' => 'Lotus Mega Yacht Dinner Cruise', 'code_prefix' => 'LY', 'product_type' => 'ticket', 'description' => 'Dinner cruise at Dubai Marina aboard the Lotus Mega Yacht.', 'no_transfer_allowed' => true, 'shared_available' => true, 'private_available' => true, 'shared_transfer_pricing' => 'extra', 'shared_transfer_price' => 50, 'opening_time' => '20:30', 'closing_time' => '23:00', 'operating_hours' => 'Boarding 20:30, cruise 21:00 – 23:00', 'validity' => 'Selected date only', 'requires_ticket' => true, 'duration_minutes' => 240]);
        self::opt($ly, ['name' => 'Normal – Soft Drinks & Unlimited Food', 'adult_price' => 300, 'child_price' => 250, 'min_adult_price' => 240, 'min_child_price' => 200, 'min_infant_price' => 0, 'ticket_category' => 'Normal', 'sort' => 1]);
        self::opt($ly, ['name' => 'VIP Top Deck – Soft Drinks & Unlimited Food', 'adult_price' => 500, 'child_price' => 350, 'min_adult_price' => 400, 'min_child_price' => 280, 'min_infant_price' => 0, 'ticket_category' => 'VIP', 'sort' => 2]);
        self::opt($ly, ['name' => 'Unlimited Alcohol & Unlimited Food', 'adult_price' => 300, 'min_adult_price' => 240, 'child_allowed' => false, 'infant_allowed' => false, 'ticket_category' => 'Alcohol', 'restriction_note' => 'Add a separate item using "Lotus Mega Yacht Dinner Cruise – Normal" for Child/Infant tickets.', 'sort' => 3]);
        self::opt($ly, ['name' => 'Unlimited Alcohol + VIP Top Deck', 'adult_price' => 700, 'min_adult_price' => 560, 'child_allowed' => false, 'infant_allowed' => false, 'ticket_category' => 'Alcohol VIP', 'restriction_note' => 'Add a separate item using "Lotus Mega Yacht Dinner Cruise – VIP" for Child/Infant tickets.', 'sort' => 4]);
        DB::table('pickup_slots')->insert(['tour_id' => $ly, 'pickup_start' => '19:30', 'pickup_end' => '20:00', 'drop_start' => '23:15', 'drop_end' => '23:45']);
    }
}
