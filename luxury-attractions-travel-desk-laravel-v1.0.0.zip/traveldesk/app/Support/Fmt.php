<?php

namespace App\Support;

use Carbon\Carbon;

class Fmt
{
    public static function money($n, string $cur = 'AED'): string { return $cur.' '.number_format((float) $n, 2); }
    public static function n($n): string { return number_format((float) $n, 2, '.', ''); }
    public static function label(?string $s): string { return $s ? ucwords(str_replace('_', ' ', $s)) : '-'; }
    public static function date($d): string { return $d ? Carbon::parse($d)->format('D, d M Y') : '-'; }
    public static function dt($d): string { return $d ? Carbon::parse($d)->timezone(config('app.timezone'))->format('d M Y, H:i') : '-'; }
    public static function r2($n): float { return round((float) $n + 0.0, 2); }

    public static function toMinutes(?string $t): ?int
    {
        return ($t && preg_match('/^(\d{1,2}):(\d{2})/', $t, $m)) ? ((int) $m[1]) * 60 + (int) $m[2] : null;
    }

    public static function addMinutes(string $t, int $mins): string
    {
        $b = self::toMinutes($t);
        if ($b === null) return '';
        $m = (($b + $mins) % 1440 + 1440) % 1440;
        return sprintf('%02d:%02d', intdiv($m, 60), $m % 60);
    }

    public static function platforms(array $c): array
    {
        $p = array_values(array_filter([!empty($c['call']) ? 'Call' : null, !empty($c['whatsapp']) ? 'WhatsApp' : null, !empty($c['telegram']) ? 'Telegram' : null, !empty($c['viber']) ? 'Viber' : null, trim($c['other'] ?? '') ?: null]));
        return $p ?: ['Call'];
    }

    public static function contacts($contacts, ?string $fallback = null): string
    {
        $list = is_string($contacts) ? (json_decode($contacts, true) ?: []) : ($contacts ?? []);
        if (! $list && $fallback) $list = [['number' => $fallback, 'call' => true]];
        return implode(' / ', array_map(fn ($c) => $c['number'].' ('.implode(', ', self::platforms($c)).')', $list)) ?: '-';
    }

    public static function pax(int $a, int $c, int $i): string
    {
        $p = array_filter([$a ? "$a Adult".($a > 1 ? 's' : '') : null, $c ? "$c Child".($c > 1 ? 'ren' : '') : null, $i ? "$i Infant".($i > 1 ? 's' : '') : null]);
        return implode(', ', $p).' (Total '.($a + $c + $i).')';
    }

    public static function transfer(object $it): string
    {
        if ($it->transfer_type === 'none') return 'No transfer';
        $dir = self::label($it->transfer_direction);
        if ($it->transfer_type === 'private') return 'Private transfer'.($it->vehicle_name ? ' – '.$it->vehicle_name.($it->vehicle_count > 1 ? ' × '.$it->vehicle_count : '') : '')." ($dir)";
        return "Shared transfer ($dir".($it->transfer_pricing === 'extra' ? ', extra charge' : '').')';
    }

    public static function pickup(object $it, ?string $hotel): string
    {
        if ($it->transfer_type === 'none') return ($hotel ?: '-').' (no transfer)';
        $pu = 'Pick-up: '.($it->pickup_location ?: $hotel ?: '-').($it->pickup_time ? " ({$it->pickup_time})" : '');
        if ($it->transfer_direction !== 'two_way') return $pu;
        return $pu.' / Drop-off: '.($it->drop_location ?: $it->pickup_location ?: $hotel ?: '-').($it->drop_time ? " ({$it->drop_time})" : '');
    }

    public static function addons(iterable $list): string
    {
        $out = [];
        foreach ($list as $a) $out[] = $a->pricing_method === 'per_group' ? $a->name : $a->quantity.' × '.$a->name;
        return implode(', ', $out);
    }

    /** Standard copy text for one tour/ticket. */
    public static function copyText(object $it, iterable $addons, object $b, object $c): string
    {
        $adds = self::addons($addons);
        $notes = implode(' | ', array_filter([$it->notes, $b->notes, $c->notes]));
        return implode("\n", [
            'Tour date: '.self::date($it->tour_date),
            'Tour/Ticket: '.$it->tour_name.($it->option_name ? ' – '.$it->option_name : '')." ({$it->tour_code}) – ".self::transfer($it).($adds ? " + Add-ons: $adds" : ''),
            'Person: '.self::pax($it->adults, $it->children, $it->infants),
            'Hotel/Pick up Location: '.self::pickup($it, $c->hotel),
            'RV: '.$b->receipt_number,
            'Room: '.($c->room_number ?: '-'),
            'Name: '.$c->title.' '.$c->name,
            'Number: '.self::contacts($c->contacts, $c->phone),
            'Notes: '.($notes ?: '-'),
        ]);
    }

    public static function wa(?string $phone): ?string { $d = preg_replace('/\D/', '', (string) $phone); return $d ? "https://wa.me/$d" : null; }
}
