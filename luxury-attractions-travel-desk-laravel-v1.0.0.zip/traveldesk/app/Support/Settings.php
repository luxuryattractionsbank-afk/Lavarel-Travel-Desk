<?php

namespace App\Support;

use Illuminate\Support\Facades\DB;

class Settings
{
    public const DEFAULTS = [
        'company' => [
            'name' => 'Luxury Attractions Tourism', 'phone' => '+971 52 888 5145', 'email' => 'salesdesk@luxuryattractions.com',
            'address' => 'Dubai, United Arab Emirates', 'website' => '', 'description' => 'Premium tours, attractions and experiences across the UAE.',
            'logo' => null, 'favicon' => null, 'receipt_header' => 'Official Booking Receipt',
            'receipt_footer' => 'Thank you for booking with Luxury Attractions Tourism.',
            'legal_text' => 'This receipt is computer generated. Prices are inclusive of applicable taxes unless stated otherwise.',
        ],
        'booking' => ['receipt_format' => 'LA-{YYYY}-{SEQ:5}', 'tour_code_format' => '{PREFIX}{SEQ:3}', 'agents_see_own_sales' => true],
        'payments' => ['cash_enabled' => true, 'card_enabled' => true, 'require_card_reference' => true, 'overpayment_tolerance' => 1,
            'card_providers' => ['POS Terminal', 'Network International', 'Other'], 'refund_methods' => ['cash', 'card', 'bank_transfer']],
        'attendance' => [
            'late' => ['grace' => 15, 'first' => 40, 'additional' => 20, 'rounding' => 'threshold'],
            'early' => ['grace' => 15, 'first' => 40, 'additional' => 20, 'rounding' => 'threshold'],
            'default_in' => '09:00', 'default_out' => '18:00',
        ],
        'email' => ['host' => '', 'port' => 587, 'encryption' => 'tls', 'username' => '', 'password' => '', 'from_name' => 'Luxury Attractions Tourism', 'from_email' => 'salesdesk@luxuryattractions.com'],
    ];

    private static array $cache = [];

    public static function get(string $key): array
    {
        if (isset(self::$cache[$key])) return self::$cache[$key];
        $row = DB::table('settings')->where('key', $key)->value('value');
        $val = array_replace_recursive(self::DEFAULTS[$key] ?? [], $row ? (json_decode($row, true) ?: []) : []);
        return self::$cache[$key] = $val;
    }

    public static function save(string $key, array $value): array
    {
        $merged = array_replace(self::get($key), $value);
        DB::table('settings')->updateOrInsert(['key' => $key], ['value' => json_encode($merged), 'updated_at' => now(), 'created_at' => now()]);
        unset(self::$cache[$key]);
        return $merged;
    }

    public static function base(): string
    {
        return DB::table('currencies')->where('is_base', true)->value('code') ?? 'AED';
    }
}
