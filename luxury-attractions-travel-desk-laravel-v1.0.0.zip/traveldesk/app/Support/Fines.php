<?php

namespace App\Support;

use Illuminate\Support\Facades\DB;

/** Attendance fine engine: first late hour starts at the threshold; further hours counted from the expected time. */
class Fines
{
    public static function hours(int $minutes, array $rule): int
    {
        if ($minutes <= 0 || $minutes < $rule['grace']) return 0;
        return match ($rule['rounding']) {
            'ceil' => max(1, (int) ceil($minutes / 60)),
            'floor' => max(1, intdiv($minutes, 60)),
            default => 1 + intdiv($minutes - (int) $rule['grace'], 60),
        };
    }

    public static function amount(int $h, array $rule): float { return $h <= 0 ? 0 : round($rule['first'] + ($h - 1) * $rule['additional'], 2); }

    public static function explain(string $kind, int $min, int $h, float $amt, array $rule, string $cur): string
    {
        if ($min <= 0) return "$kind: none";
        if ($h === 0) return "$kind: $min min – within {$rule['grace']} min threshold, no fine";
        return "$kind: $min min (threshold {$rule['grace']} min) → $h hour(s). Fine = $cur {$rule['first']} (1st hour)".($h > 1 ? ' + '.($h - 1)." × $cur {$rule['additional']}" : '')." = $cur $amt";
    }

    /** Recalculate one attendance day and its automatic fines. */
    public static function record(int $userId, string $date, array $patch = []): object
    {
        $cfg = Settings::get('attendance');
        $cur = Settings::base();
        $sched = DB::table('employee_schedules')->where('user_id', $userId)->first();
        $ex = DB::table('attendance')->where('user_id', $userId)->where('date', $date)->first();
        $eIn = $ex->expected_in ?? $sched->check_in ?? $cfg['default_in'];
        $eOut = $ex->expected_out ?? $sched->check_out ?? $cfg['default_out'];
        $aIn = array_key_exists('actual_in', $patch) ? $patch['actual_in'] : ($ex->actual_in ?? null);
        $aOut = array_key_exists('actual_out', $patch) ? $patch['actual_out'] : ($ex->actual_out ?? null);
        $weekly = $sched ? (json_decode($sched->weekly_days_off, true) ?: []) : [];
        $dayOff = DB::table('days_off')->where('user_id', $userId)->where('date', $date)->exists() || in_array((int) date('w', strtotime($date)), $weekly);
        $mi = Fmt::toMinutes($eIn); $mo = Fmt::toMinutes($eOut); $ai = Fmt::toMinutes($aIn); $ao = Fmt::toMinutes($aOut);
        $worked = ($ai !== null && $ao !== null) ? ($ao >= $ai ? $ao - $ai : $ao + 1440 - $ai) : 0;
        $lm = $lh = $em = $eh = 0; $lf = $ef = 0.0;
        if (! $dayOff) {
            if ($mi !== null && $ai !== null && $ai > $mi) { $lm = $ai - $mi; $lh = self::hours($lm, $cfg['late']); $lf = self::amount($lh, $cfg['late']); }
            if ($mo !== null && $ao !== null && $ao < $mo && ($ai === null || $ao >= $ai)) { $em = $mo - $ao; $eh = self::hours($em, $cfg['early']); $ef = self::amount($eh, $cfg['early']); }
        }
        $vals = [
            'expected_in' => $eIn, 'expected_out' => $eOut, 'actual_in' => $aIn, 'actual_out' => $aOut, 'minutes_worked' => $worked,
            'late_minutes' => $lm, 'late_hours' => $lh, 'late_fine' => $lf, 'late_calc' => $dayOff ? 'Approved day off – no fines' : self::explain('Late', $lm, $lh, $lf, $cfg['late'], $cur),
            'early_minutes' => $em, 'early_hours' => $eh, 'early_fine' => $ef, 'early_calc' => $dayOff ? 'Approved day off – no fines' : self::explain('Early departure', $em, $eh, $ef, $cfg['early'], $cur),
            'is_day_off' => $dayOff, 'updated_at' => now(),
        ];
        if (array_key_exists('notes', $patch)) $vals['notes'] = $patch['notes'];
        if ($ex) DB::table('attendance')->where('id', $ex->id)->update($vals);
        else $vals['id'] = DB::table('attendance')->insertGetId($vals + ['user_id' => $userId, 'date' => $date, 'created_at' => now()]);
        $id = $ex->id ?? $vals['id'];
        foreach ([['late_checkin', $lf, $vals['late_calc']], ['early_checkout', $ef, $vals['early_calc']]] as [$type, $amt, $why]) {
            $f = DB::table('fines')->where('attendance_id', $id)->where('type', $type)->first();
            if ($f) {
                if (abs($f->amount - $amt) > 0.004) DB::table('fines')->where('id', $f->id)->update(['amount' => $amt, 'reason' => $why, 'status' => $amt > 0 ? $f->status : 'waived', 'updated_at' => now()]);
            } elseif ($amt > 0) {
                DB::table('fines')->insert(['user_id' => $userId, 'attendance_id' => $id, 'date' => $date, 'type' => $type, 'amount' => $amt, 'reason' => $why, 'status' => 'outstanding', 'created_at' => now(), 'updated_at' => now()]);
            }
        }
        return DB::table('attendance')->where('id', $id)->first();
    }
}
