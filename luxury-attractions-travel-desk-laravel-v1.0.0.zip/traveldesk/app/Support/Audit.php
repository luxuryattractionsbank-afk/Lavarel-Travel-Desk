<?php

namespace App\Support;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class Audit
{
    public static function log(string $entity, ?int $id, string $action, array $details = [], ?int $userId = null): void
    {
        DB::table('audit_logs')->insert([
            'user_id' => $userId ?? Auth::id(), 'entity_type' => $entity, 'entity_id' => $id, 'action' => $action,
            'details' => $details ? json_encode($details) : null, 'created_at' => now(),
        ]);
    }

    /** Atomic counter (safe with several users saving at the same moment). */
    public static function nextSeq(string $key): int
    {
        return DB::transaction(function () use ($key) {
            $row = DB::table('counters')->where('key', $key)->lockForUpdate()->first();
            if (! $row) {
                DB::table('counters')->insert(['key' => $key, 'value' => 1]);
                return 1;
            }
            DB::table('counters')->where('key', $key)->update(['value' => $row->value + 1]);
            return $row->value + 1;
        });
    }

    public static function format(string $format, int $seq, string $prefix = ''): string
    {
        $d = now();
        $out = strtr($format, ['{YYYY}' => $d->format('Y'), '{YY}' => $d->format('y'), '{MM}' => $d->format('m'), '{DD}' => $d->format('d'), '{PREFIX}' => $prefix]);
        return preg_replace_callback('/\{SEQ(?::(\d+))?\}/', fn ($m) => str_pad((string) $seq, (int) ($m[1] ?? 1), '0', STR_PAD_LEFT), $out);
    }

    public static function receiptNumber(): string
    {
        $f = Settings::get('booking')['receipt_format'];
        $scope = str_contains($f, '{DD}') ? now()->format('Y-m-d') : (str_contains($f, '{MM}') ? now()->format('Y-m') : (str_contains($f, '{YY') ? now()->format('Y') : 'all'));
        return self::format($f, self::nextSeq("receipt:$scope"));
    }

    public static function tourCode(string $prefix): string
    {
        $p = strtoupper($prefix);
        return self::format(Settings::get('booking')['tour_code_format'], self::nextSeq("tour:$p"), $p);
    }
}
