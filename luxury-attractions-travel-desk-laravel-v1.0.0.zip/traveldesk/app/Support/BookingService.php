<?php

namespace App\Support;

use App\Models\User;
use Illuminate\Support\Facades\DB;
use RuntimeException;

class BookingService
{
    private static function fail(string $m): never { throw new RuntimeException($m); }

    /** Create ($bookingId null) or update a booking from the booking-form payload. Returns the booking id. */
    public static function save(array $p, User $me, ?int $bookingId = null): int
    {
        // ---- Customer ----
        $c = $p['customer'] ?? [];
        $name = trim((string) ($c['name'] ?? ''));
        if (mb_strlen($name) < 2) self::fail('Customer name is required.');
        if (! in_array($c['title'] ?? '', ['Mr', 'Mrs', 'Ms', 'Other'])) $c['title'] = 'Mr';
        $contacts = [];
        foreach ($c['contacts'] ?? [] as $ct) {
            $num = trim((string) ($ct['number'] ?? ''));
            if ($num === '') continue;
            if (! preg_match('/^[+\d][\d\s\-()]{5,20}$/', $num)) self::fail("Invalid contact number: $num");
            $row = ['number' => $num, 'call' => ! empty($ct['call']), 'whatsapp' => ! empty($ct['whatsapp']), 'telegram' => ! empty($ct['telegram']), 'viber' => ! empty($ct['viber']), 'other' => trim((string) ($ct['other'] ?? '')) ?: null];
            if (! $row['call'] && ! $row['whatsapp'] && ! $row['telegram'] && ! $row['viber'] && ! $row['other']) $row['call'] = true;
            $contacts[] = $row;
        }
        if (! $contacts) self::fail('At least one contact number is required.');
        $email = trim((string) ($c['email'] ?? ''));
        if ($email !== '' && ! filter_var($email, FILTER_VALIDATE_EMAIL)) self::fail('Invalid customer email.');
        $customer = ['title' => $c['title'], 'name' => $name, 'hotel' => trim((string) ($c['hotel'] ?? '')) ?: null, 'room_number' => trim((string) ($c['room_number'] ?? '')) ?: null,
            'phone' => $contacts[0]['number'], 'contacts' => json_encode($contacts), 'email' => $email ?: null, 'notes' => trim((string) ($c['notes'] ?? '')) ?: null];

        // ---- Items (authoritative price calculation) ----
        $items = $p['items'] ?? [];
        if (! $items) self::fail('Add at least one tour.');
        $calc = [];
        foreach ($items as $i => $it) {
            $tour = Catalog::tour((int) ($it['tour_id'] ?? 0));
            if (! $tour) self::fail('Item '.($i + 1).': select a tour.');
            $option = collect($tour['options'])->firstWhere('id', (int) ($it['option_id'] ?? 0));
            $res = Pricing::calculate($tour, $option, $it, $tour);
            if ($res['errors']) self::fail('Item '.($i + 1)." ({$tour['name']}): ".implode(' ', $res['errors']));
            $calc[] = compact('it', 'tour', 'option', 'res');
        }

        // ---- Below-minimum approvals ----
        $prev = $bookingId ? DB::table('booking_items')->where('booking_id', $bookingId)->get()->keyBy('id') : collect();
        $useApproval = [];
        if (! $me->can('pricing.override')) {
            foreach ($calc as $i => $x) {
                if (! $x['res']['requires_approval']) continue;
                $old = isset($x['it']['id']) ? $prev->get($x['it']['id']) : null;
                if ($old && $old->option_id == ($x['option']['id'] ?? null) && $old->adults == $x['it']['adults'] && $old->children == $x['it']['children'] && $old->infants == $x['it']['infants'] && abs($old->total - $x['res']['total']) < 0.01) continue;
                $l = 'Item '.($i + 1)." ({$x['tour']['name']})";
                $aid = (int) ($x['it']['approval_id'] ?? 0);
                if (! $aid) self::fail("$l: price is below the minimum (".implode('; ', $x['res']['approval_reasons']).'). Request approval from an authorised user first.');
                $a = DB::table('price_approvals')->where('id', $aid)->first();
                if (! $a || $a->requested_by_id != $me->id) self::fail("$l: approval not found.");
                if ($a->status !== 'approved') self::fail("$l: approval is {$a->status}.");
                if (now()->gt($a->expires_at)) self::fail("$l: approval has expired – request again.");
                if ($a->booking_item_id && $a->booking_item_id != ($x['it']['id'] ?? null)) self::fail("$l: this approval was already used.");
                if ($a->tour_id != $x['tour']['id'] || $a->option_id != ($x['option']['id'] ?? null) || $a->adults != $x['it']['adults'] || $a->children != $x['it']['children'] || $a->infants != $x['it']['infants']) self::fail("$l: tour, option or passengers changed since approval – request again.");
                if ($x['res']['total'] < $a->requested_total - 0.01) self::fail("$l: price is lower than the approved ".number_format($a->requested_total, 2).' – request again.');
                $useApproval[$i] = $aid;
            }
        }

        // ---- Payments (new bookings) ----
        $grand = round(array_sum(array_map(fn ($x) => $x['res']['total'], $calc)), 2);
        $pays = [];
        if (! $bookingId) {
            $ps = Settings::get('payments');
            $running = $grand;
            foreach ($p['payments'] ?? [] as $k => $pm) {
                $cur = DB::table('currencies')->where('code', $pm['currency'] ?? '')->where('active', true)->first();
                if (! $cur) self::fail('Payment '.($k + 1).': unsupported currency.');
                $method = ($pm['method'] ?? 'cash') === 'card' ? 'card' : 'cash';
                if ($method === 'card' && $ps['require_card_reference'] && empty($pm['reference'])) self::fail('Payment '.($k + 1).': card payments need a reference number.');
                $chRate = ! empty($pm['change_currency']) ? Finance::rate($pm['change_currency']) : null;
                $s = Pricing::settle($method, (float) $pm['amount'], (float) $cur->rate_to_base, $running, $pm['change_currency'] ?? null, $chRate, $pm['change_amount'] ?? null, (float) $ps['overpayment_tolerance'], Settings::base());
                if ($s['errors']) self::fail('Payment '.($k + 1).': '.implode(' ', $s['errors']));
                $running = round($running - $s['applied'], 2);
                $pays[] = ['pm' => $pm, 'method' => $method, 'cur' => $cur, 's' => $s];
            }
        }
        $salesPerson = ($me->can('bookings.select_salesperson') && ! empty($p['sales_person_id'])) ? (int) $p['sales_person_id'] : $me->id;

        return DB::transaction(function () use ($p, $me, $bookingId, $customer, $calc, $prev, $useApproval, $pays, $grand, $salesPerson) {
            $desk = trim((string) ($p['travel_desk'] ?? '')) ?: null;
            if ($customer['hotel']) DB::table('hotels')->insertOrIgnore(['name' => $customer['hotel']]);
            $bookingFields = ['travel_desk' => $desk, 'sales_person_id' => $salesPerson, 'balance_collection' => ($p['balance_collection'] ?? '') === 'driver' ? 'driver' : 'travel_desk',
                'notes' => trim((string) ($p['notes'] ?? '')) ?: null, 'terms_id' => $p['terms_id'] ?? null, 'updated_at' => now()];
            if ($me->can('bookings.terms_override')) $bookingFields['terms_override'] = trim((string) ($p['terms_override'] ?? '')) ?: null;
            foreach (['customer_signature', 'agent_signature'] as $sig) if (! empty($p[$sig]) && str_starts_with($p[$sig], 'data:image/png;base64,') && strlen($p[$sig]) < 400000) $bookingFields[$sig] = $p[$sig];

            if ($bookingId) {
                $b = DB::table('bookings')->where('id', $bookingId)->lockForUpdate()->first();
                if (in_array($b->status, ['cancelled', 'refunded'])) self::fail('Cancelled/refunded bookings cannot be edited.');
                $oldC = (array) DB::table('customers')->where('id', $b->customer_id)->first();
                $changed = array_keys(array_filter($customer, fn ($v, $k) => (string) ($oldC[$k] ?? '') !== (string) $v, ARRAY_FILTER_USE_BOTH));
                DB::table('customers')->where('id', $b->customer_id)->update($customer + ['updated_at' => now()]);
                if ($changed) Audit::log('booking', $bookingId, 'customer_changed', ['fields' => $changed]);
                DB::table('bookings')->where('id', $bookingId)->update($bookingFields + ['status' => $b->status === 'draft' && ($p['status'] ?? '') !== 'draft' ? 'confirmed' : $b->status]);
                Audit::log('booking', $bookingId, 'booking_edited');
                $id = $bookingId;
            } else {
                $cid = DB::table('customers')->insertGetId($customer + ['created_at' => now(), 'updated_at' => now()]);
                $receipt = Audit::receiptNumber();
                $id = DB::table('bookings')->insertGetId($bookingFields + ['receipt_number' => $receipt, 'customer_id' => $cid, 'created_by_id' => $me->id,
                    'status' => ($p['status'] ?? '') === 'draft' ? 'draft' : 'confirmed', 'base_currency' => Settings::base(), 'issued_at' => now(), 'created_at' => now(),
                    'agent_signature' => $bookingFields['agent_signature'] ?? $me->signature]);
                Audit::log('booking', $id, 'booking_created', ['receipt' => $receipt, 'items' => count($calc), 'total' => $grand]);
            }

            $kept = []; $itemIds = [];
            foreach ($calc as $i => $x) {
                ['it' => $it, 'tour' => $tour, 'option' => $option, 'res' => $res] = $x;
                $v = $res['vehicle'];
                $vals = [
                    'tour_id' => $tour['id'], 'option_id' => $option['id'] ?? null, 'tour_name' => $tour['name'], 'option_name' => $option['name'] ?? null, 'product_type' => $tour['product_type'],
                    'tour_date' => $it['tour_date'], 'adults' => (int) $it['adults'], 'children' => (int) $it['children'], 'infants' => (int) $it['infants'],
                    'transfer_type' => $res['transfer_type'], 'transfer_direction' => $res['transfer_direction'], 'transfer_pricing' => $res['transfer_pricing'],
                    'vehicle_id' => $v['id'] ?? null, 'vehicle_name' => $v['name'] ?? null, 'vehicle_count' => $v ? max(1, (int) ($it['vehicle_count'] ?? 1)) : 0,
                    'slot_id' => $res['transfer_type'] === 'shared' ? ($it['slot_id'] ?? null) : null, 'pickup_time' => $res['pickup_time'], 'drop_time' => $res['drop_time'],
                    'pickup_location' => trim((string) ($it['pickup_location'] ?? '')) ?: null, 'drop_location' => trim((string) ($it['drop_location'] ?? '')) ?: null,
                    'breakdown' => json_encode($res['lines']), 'standard_price' => $res['standard'], 'discount' => $res['discount'], 'agreed_price' => $res['agreed'],
                    'sold_adult_price' => $res['sold']['adult'], 'sold_child_price' => $res['sold']['child'], 'sold_infant_price' => $res['sold']['infant'], 'min_total' => $res['min_total'],
                    'total' => $res['total'], 'notes' => trim((string) ($it['notes'] ?? '')) ?: null, 'updated_at' => now(),
                ];
                $old = isset($it['id']) ? $prev->get($it['id']) : null;
                if ($old && $old->supplier_id && $old->tour_id == $tour['id']) {
                    if (! $old->supplier_cost_manual) $vals['supplier_cost'] = SupplierCost::cost($vals, $old->supplier_id, $res['addon_lines']);
                } else {
                    $sid = SupplierCost::auto($tour['id']);
                    $vals += ['supplier_id' => $sid, 'supplier_cost' => SupplierCost::cost($vals, $sid, $res['addon_lines']), 'supplier_cost_manual' => false];
                }
                if ($old) {
                    DB::table('booking_items')->where('id', $old->id)->update($vals);
                    $iid = $old->id; $kept[] = $old->id;
                    if (abs($old->total - $vals['total']) > 0.004) Audit::log('booking', $id, 'price_changed', ['tour_code' => $old->tour_code, 'from' => $old->total, 'to' => $vals['total']]);
                    DB::table('booking_item_addons')->where('booking_item_id', $iid)->delete();
                } else {
                    $iid = DB::table('booking_items')->insertGetId($vals + ['booking_id' => $id, 'tour_code' => Audit::tourCode($tour['code_prefix']), 'created_at' => now()]);
                }
                foreach ($res['addon_lines'] as $a) DB::table('booking_item_addons')->insert($a + ['booking_item_id' => $iid]);
                if (isset($useApproval[$i])) {
                    DB::table('booking_items')->where('id', $iid)->update(['price_approval_id' => $useApproval[$i]]);
                    DB::table('price_approvals')->where('id', $useApproval[$i])->update(['booking_item_id' => $iid]);
                    Audit::log('booking', $id, 'below_minimum_price_applied', ['approval' => $useApproval[$i], 'total' => $res['total'], 'minimum' => $res['min_total']]);
                }
                $itemIds[] = $iid;
            }
            foreach ($prev as $old) {
                if (! in_array($old->id, $kept) && $old->status !== 'cancelled') {
                    DB::table('booking_items')->where('id', $old->id)->update(['status' => 'cancelled']);
                    Audit::log('booking', $id, 'item_cancelled', ['tour_code' => $old->tour_code]);
                }
            }
            foreach ($pays as $x) {
                $s = $x['s']; $pm = $x['pm'];
                $alloc = isset($pm['item_index']) && $pm['item_index'] !== '' && $pm['item_index'] !== null ? ($itemIds[(int) $pm['item_index']] ?? null) : null;
                $pid = DB::table('payments')->insertGetId([
                    'booking_id' => $id, 'booking_item_id' => $alloc, 'method' => $x['method'], 'currency' => $x['cur']->code, 'amount' => $pm['amount'], 'exchange_rate' => $x['cur']->rate_to_base,
                    'base_amount' => $s['applied'], 'tendered_base' => $s['tendered'], 'overpayment_base' => $s['over'], 'change_currency' => $s['change_currency'], 'change_amount' => $s['change_amount'],
                    'change_base' => $s['change_base'], 'rounding_base' => $s['rounding'], 'reference' => $pm['reference'] ?? null, 'provider' => $x['method'] === 'card' ? ($pm['provider'] ?? null) : null,
                    'card_type' => $pm['card_type'] ?? null, 'is_deposit' => ! empty($pm['is_deposit']), 'notes' => $pm['notes'] ?? null, 'user_id' => $me->id, 'paid_at' => now(),
                ]);
                Audit::log('booking', $id, 'payment_added', ['payment' => $pid, 'method' => $x['method'], 'currency' => $x['cur']->code, 'amount' => $pm['amount'], 'applied' => $s['applied'], 'change' => $s['change_amount']]);
            }
            Finance::recalc($id);
            return $id;
        });
    }
}
