<?php

namespace App\Support;

class Perm
{
    public const LIST = [
        'bookings.create' => 'Create bookings',
        'bookings.view_all' => 'View all bookings (otherwise own only)',
        'bookings.edit' => 'Edit bookings / items / prices',
        'bookings.cancel' => 'Cancel bookings & change status',
        'bookings.terms_override' => 'Override terms on bookings',
        'bookings.select_salesperson' => 'Select responsible sales person',
        'payments.record' => 'Record payments',
        'payments.void' => 'Void payments',
        'refunds.process' => 'Process refunds',
        'receipts.print' => 'Print receipts',
        'receipts.email' => 'Email receipts',
        'tickets.manage' => 'Upload / reissue tickets',
        'tours.manage' => 'Manage tours, options, add-ons, vehicles',
        'reports.view' => 'View sales reports',
        'reports.own_sales' => 'View own sales summary',
        'attendance.self' => 'Check in / out and view own attendance',
        'attendance.manage' => 'Manage all attendance, schedules, days off',
        'fines.manage' => 'Manage fines',
        'users.manage' => 'Manage users, roles and permissions',
        'settings.manage' => 'Manage company & system settings',
        'audit.view' => 'View audit logs',
        'records.delete' => 'Delete any record permanently',
        'pricing.approve' => "Approve other users' below-minimum price requests",
        'pricing.override' => 'Sell below the minimum price without approval',
        'cash.collect' => "Collect cash from agents (view all agents' cash)",
        'cash.own' => 'View own cash holdings',
        'commission.manage' => 'Manage commission plans, salaries, advances & payroll',
        'commission.own' => 'View own commission & payroll',
        'suppliers.view' => 'View suppliers',
        'suppliers.manage' => 'Manage suppliers, price lists & platform logins',
        'suppliers.assign' => 'Assign bookings to suppliers',
        'suppliers.payments' => 'Record supplier payments, costs & driver collections',
        'reviews.write' => 'Write reviews for tours/tickets',
        'reviews.see_supplier' => 'See which supplier a review is about',
    ];

    public const AGENT_DEFAULT = ['bookings.create', 'payments.record', 'receipts.print', 'receipts.email', 'reports.own_sales', 'attendance.self', 'cash.own', 'commission.own', 'reviews.write'];
}
