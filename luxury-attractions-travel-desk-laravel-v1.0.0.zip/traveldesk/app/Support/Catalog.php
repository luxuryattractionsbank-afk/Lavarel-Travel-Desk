<?php

namespace App\Support;

use Illuminate\Support\Facades\DB;

class Catalog
{
    public static function rows($q): array { return array_map(fn ($r) => (array) $r, $q->get()->all()); }

    /** One tour with its options, add-ons, vehicles (own or global) and slots – arrays for the pricing engine. */
    public static function tour(int $id): ?array
    {
        $t = DB::table('tours')->where('id', $id)->first();
        if (! $t) return null;
        $t = (array) $t;
        $t['available_days'] = json_decode($t['available_days'], true) ?: [0, 1, 2, 3, 4, 5, 6];
        foreach (['active', 'no_transfer_allowed', 'shared_available', 'private_available', 'requires_ticket', 'allow_over_capacity'] as $b) $t[$b] = (bool) $t[$b];
        $t['options'] = array_map(function ($o) {
            foreach (['adult_allowed', 'child_allowed', 'infant_allowed', 'active'] as $b) $o[$b] = (bool) $o[$b];
            foreach (['adult_price', 'child_price', 'infant_price', 'group_price'] as $m) $o[$m] = (float) $o[$m];
            foreach (['min_adult_price', 'min_child_price', 'min_infant_price', 'min_group_price'] as $m) $o[$m] = $o[$m] === null ? null : (float) $o[$m];
            return $o;
        }, self::rows(DB::table('tour_options')->where('tour_id', $id)->where('active', true)->orderBy('sort')->orderBy('id')));
        $t['addons'] = array_map(fn ($a) => ['price' => (float) $a['price'], 'min_price' => $a['min_price'] === null ? null : (float) $a['min_price']] + $a, self::rows(DB::table('addons')->where('tour_id', $id)->where('active', true)));
        $own = self::rows(DB::table('vehicles')->where('tour_id', $id)->where('active', true)->orderBy('capacity'));
        $t['vehicles'] = array_map(fn ($v) => ['price' => (float) $v['price']] + $v, $own ?: self::rows(DB::table('vehicles')->whereNull('tour_id')->where('active', true)->orderBy('capacity')));
        $t['slots'] = self::rows(DB::table('pickup_slots')->where('tour_id', $id)->where('active', true)->orderBy('pickup_start'));
        $t['shared_transfer_price'] = (float) $t['shared_transfer_price'];
        return $t;
    }

    public static function all(): array
    {
        return array_values(array_filter(array_map(fn ($id) => self::tour($id), DB::table('tours')->orderBy('product_type')->orderBy('name')->pluck('id')->all())));
    }
}
