<?php

use App\Support\Fmt;

if (! function_exists('money')) {
    function money($n, ?string $cur = null): string { return Fmt::money($n, $cur ?? 'AED'); }
}
if (! function_exists('lbl')) {
    function lbl(?string $s): string { return Fmt::label($s); }
}
if (! function_exists('badge')) {
    function badge(?string $s): string
    {
        $c = match ($s) {
            'paid', 'completed', 'active', 'approved', 'sent', 'finalized' => 'bg-emerald-100 text-emerald-800',
            'partially_paid', 'pending', 'outstanding', 'expired' => 'bg-amber-100 text-amber-800',
            'unpaid', 'failed', 'rejected' => 'bg-red-100 text-red-700',
            'refunded', 'partially_refunded' => 'bg-purple-100 text-purple-800',
            'confirmed', 'reissued' => 'bg-sky-100 text-sky-800',
            default => 'bg-slate-100 text-slate-700',
        };
        return '<span class="badge '.$c.'">'.e(Fmt::label($s)).'</span>';
    }
}
if (! function_exists('can')) {
    function can(string $p): bool { return (bool) auth()->user()?->can($p); }
}
