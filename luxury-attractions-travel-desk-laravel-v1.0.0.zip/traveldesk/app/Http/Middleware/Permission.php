<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

/** Route middleware: perm:bookings.create,bookings.view_all (any of the listed permissions). */
class Permission
{
    public function handle(Request $request, Closure $next, string ...$perms)
    {
        $u = $request->user();
        if (! $u) return redirect()->route('login');
        foreach ($perms as $p) if ($u->can($p)) return $next($request);
        if ($request->expectsJson()) abort(403);
        return redirect()->route('dashboard')->with('error', 'You do not have permission to access that page.');
    }
}
