<?php

namespace App\Http\Middleware;

use App\Support\Installer;
use Closure;
use Illuminate\Http\Request;

/** Before installation every page goes to /install; afterwards /install is closed. */
class EnsureInstalled
{
    public function handle(Request $request, Closure $next)
    {
        $installing = $request->is('install') || $request->is('install/*');
        $installed = Installer::installed();
        if (! $installed && ! $installing) return redirect('/install');
        if ($installed && $installing) return redirect('/login');
        return $next($request);
    }
}
