<?php

namespace App\Http\Controllers;

use App\Support\Audit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TicketController extends Controller
{
    public function index(Request $r)
    {
        $attention = DB::table('booking_items')->join('bookings', 'bookings.id', '=', 'booking_items.booking_id')->join('customers', 'customers.id', '=', 'bookings.customer_id')
            ->where('product_type', 'ticket')->where('booking_items.status', 'active')->where('bookings.status', '!=', 'cancelled')->where('tour_date', '>=', today())
            ->whereNotExists(fn ($q) => $q->from('tickets')->whereColumn('tickets.booking_item_id', 'booking_items.id')->where('tickets.status', 'active'))
            ->select('booking_items.*', 'bookings.receipt_number', 'customers.name as cust')->orderBy('tour_date')->limit(100)->get();
        $tickets = DB::table('tickets')->join('bookings', 'bookings.id', '=', 'tickets.booking_id')->join('customers', 'customers.id', '=', 'bookings.customer_id')
            ->when($r->status, fn ($q) => $q->where('tickets.status', $r->status))->when($r->q, fn ($q) => $q->where(fn ($w) => $w->where('tickets.tour_code', 'like', "%{$r->q}%")->orWhere('customers.name', 'like', "%{$r->q}%")->orWhere('tickets.ticket_number', 'like', "%{$r->q}%")))
            ->select('tickets.*', 'bookings.receipt_number', 'customers.name as cust')->orderByDesc('tickets.id')->limit(200)->get();
        return view('tickets', compact('attention', 'tickets'));
    }

    public function upload(Request $r, int $id)
    {
        $it = DB::table('booking_items')->where('id', $id)->first();
        $r->validate(['ticket' => 'required|file|mimes:pdf,jpg,jpeg,png|max:10240']);
        [$path, $name] = PaymentController::storeFile($r->file('ticket'), 'tickets');
        $tid = DB::table('tickets')->insertGetId(['booking_id' => $it->booking_id, 'booking_item_id' => $id, 'tour_code' => $it->tour_code, 'ticket_type' => $r->ticket_type ?: $it->option_name,
            'ticket_number' => $r->ticket_number, 'ticket_date' => $r->ticket_date ?: $it->tour_date, 'file_path' => $path, 'file_name' => $name, 'user_id' => auth()->id(), 'created_at' => now(), 'updated_at' => now()]);
        Audit::log('booking', $it->booking_id, 'ticket_uploaded', ['ticket' => $tid, 'tour_code' => $it->tour_code]);
        return back()->with('ok', 'Ticket uploaded.');
    }

    public function update(Request $r, int $id)
    {
        $t = DB::table('tickets')->where('id', $id)->first();
        $r->validate(['status' => 'required|in:active,used,expired,cancelled,refunded']);
        DB::table('tickets')->where('id', $id)->update(['status' => $r->status, 'still_usable' => $r->boolean('still_usable'), 'notes' => $r->notes ?: $t->notes, 'updated_at' => now()]);
        Audit::log('booking', $t->booking_id, 'ticket_status_changed', ['ticket' => $id, 'from' => $t->status, 'to' => $r->status]);
        return back()->with('ok', 'Ticket updated.');
    }

    public function reissue(Request $r, int $id)
    {
        $t = DB::table('tickets')->where('id', $id)->first();
        $r->validate(['reason' => 'required|string|min:3', 'ticket' => 'required|file|mimes:pdf,jpg,jpeg,png|max:10240']);
        $code = trim((string) $r->new_tour_code) ?: $t->tour_code;
        $target = DB::table('booking_items')->where('tour_code', $code)->first();
        if (! $target) return back()->with('error', "Tour code $code not found.");
        [$path, $name] = PaymentController::storeFile($r->file('ticket'), 'tickets');
        $new = DB::table('tickets')->insertGetId(['booking_id' => $target->booking_id, 'booking_item_id' => $target->id, 'tour_code' => $code, 'ticket_type' => $t->ticket_type, 'ticket_number' => $r->ticket_number,
            'ticket_date' => $t->ticket_date, 'file_path' => $path, 'file_name' => $name, 'reissued_from_id' => $t->id, 'notes' => "Reissue of ticket #{$t->id}: {$r->reason}", 'user_id' => auth()->id(), 'created_at' => now(), 'updated_at' => now()]);
        DB::table('tickets')->where('id', $id)->update(['status' => 'reissued', 'still_usable' => $r->boolean('original_usable'), 'updated_at' => now()]);
        Audit::log('booking', $t->booking_id, 'ticket_reissued', ['original' => $id, 'new' => $new, 'reason' => $r->reason, 'original_status' => $r->original_status]);
        return back()->with('ok', 'Ticket reissued.');
    }
}
