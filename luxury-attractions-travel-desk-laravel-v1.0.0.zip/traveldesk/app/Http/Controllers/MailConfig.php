<?php

namespace App\Http\Controllers;

use App\Support\Settings;

/** Applies the SMTP settings saved in Settings → Email at runtime. */
class MailConfig
{
    public static function apply(): void
    {
        $e = Settings::get('email');
        if (empty($e['host'])) throw new \RuntimeException('SMTP is not configured (Settings → Email).');
        config([
            'mail.default' => 'smtp',
            'mail.mailers.smtp' => ['transport' => 'smtp', 'host' => $e['host'], 'port' => (int) $e['port'], 'encryption' => $e['encryption'] ?: null,
                'username' => $e['username'] ?: null, 'password' => $e['password'] ? decrypt($e['password']) : null, 'timeout' => 20],
            'mail.from' => ['address' => $e['from_email'], 'name' => $e['from_name']],
        ]);
    }
}
