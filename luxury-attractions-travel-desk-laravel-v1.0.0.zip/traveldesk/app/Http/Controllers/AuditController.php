<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AuditController extends Controller
{
    public function index(Request $r)
    {
        $rows = DB::table('audit_logs')->leftJoin('users', 'users.id', '=', 'audit_logs.user_id')
            ->when($r->entity, fn ($q) => $q->where('entity_type', $r->entity))->when($r->action, fn ($q) => $q->where('action', 'like', "%{$r->action}%"))
            ->when($r->user, fn ($q) => $q->where('audit_logs.user_id', $r->user))->orderByDesc('audit_logs.id')->limit(500)->get(['audit_logs.*', 'users.display_name as who']);
        return view('audit', ['rows' => $rows, 'users' => DB::table('users')->get(['id', 'full_name'])]);
    }
}
