<?php

namespace App\Http\Controllers;

use App\Support\Audit;
use App\Support\BookingService;
use App\Support\Catalog;
use App\Support\Finance;
use App\Support\Fmt;
use App\Support\Settings;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;

class BookingController extends Controller
{
    /** Bookings visible to the current user (agents: own only). */
    public static function scope($q)
    {
        $u = auth()->user();
        if (! $u->can('bookings.view_all')) $q->where(fn ($w) => $w->where('bookings.created_by_id', $u->id)->orWhere('bookings.sales_person_id', $u->id));
        return $q;
    }

    public static function allowed(object $b): bool
    {
        $u = auth()->user();
        return $u->can('bookings.view_all') || $b->created_by_id == $u->id || $b->sales_person_id == $u->id;
    }

    private function filtered(Request $r)
    {
        $q = self::scope(DB::table('bookings')->join('customers', 'customers.id', '=', 'bookings.customer_id')->leftJoin('users as sp', 'sp.id', '=', 'bookings.sales_person_id'));
        if ($s = trim((string) $r->q)) {
            $like = '%'.str_replace(['%', '_'], '', $s).'%';
            $digits = preg_replace('/\D/', '', $s);
            $q->where(function ($w) use ($like, $digits) {
                $w->where('bookings.receipt_number', 'like', $like)->orWhere('customers.name', 'like', $like)->orWhere('customers.phone', 'like', $like)->orWhere('customers.contacts', 'like', $like)
                    ->orWhere('customers.hotel', 'like', $like)->orWhere('customers.room_number', 'like', $like)->orWhere('bookings.travel_desk', 'like', $like)->orWhere('sp.full_name', 'like', $like)
                    ->orWhereExists(fn ($e) => $e->from('booking_items as bi')->whereColumn('bi.booking_id', 'bookings.id')->where(fn ($x) => $x->where('bi.tour_code', 'like', $like)->orWhere('bi.tour_name', 'like', $like)))
                    ->orWhereExists(fn ($e) => $e->from('tickets as t')->whereColumn('t.booking_id', 'bookings.id')->where('t.ticket_number', 'like', $like));
                if (strlen($digits) >= 5) $w->orWhereRaw("REGEXP_REPLACE(customers.contacts, '[^0-9]', '') LIKE ?", ["%$digits%"]);
            });
        }
        if ($r->pay === 'outstanding') $q->whereIn('bookings.payment_status', ['unpaid', 'partially_paid'])->where('bookings.status', '!=', 'cancelled');
        elseif ($r->pay) $q->where('bookings.payment_status', $r->pay);
        if ($r->status) $q->where('bookings.status', $r->status);
        if ($r->desk) $q->where('bookings.travel_desk', $r->desk);
        if ($r->agent) $q->where('bookings.sales_person_id', $r->agent);
        if ($r->from) $q->where('bookings.issued_at', '>=', $r->from.' 00:00:00');
        if ($r->to) $q->where('bookings.issued_at', '<=', $r->to.' 23:59:59');
        if ($r->collection) $q->where('bookings.balance_collection', $r->collection)->where('bookings.balance_due', '>', 0);
        if ($r->tour_from || $r->tour_to) $q->whereExists(fn ($e) => $e->from('booking_items as bi')->whereColumn('bi.booking_id', 'bookings.id')->when($r->tour_from, fn ($x) => $x->where('bi.tour_date', '>=', $r->tour_from))->when($r->tour_to, fn ($x) => $x->where('bi.tour_date', '<=', $r->tour_to)));
        return $q;
    }

    public function index(Request $r)
    {
        $table = $r->view === 'table';
        $rows = $this->filtered($r)->select('bookings.*', 'customers.name as cust', 'customers.phone', 'customers.hotel', 'customers.room_number', 'sp.display_name as agent')
            ->orderByDesc('bookings.issued_at')->orderByDesc('bookings.id')->limit($table ? 500 : 200)->get();
        $lines = $table ? $this->tableRows($rows->pluck('id')->all(), $r) : collect();
        $tours = $table ? collect() : DB::table('booking_items')->whereIn('booking_id', $rows->pluck('id'))->where('status', '!=', 'cancelled')->get()->groupBy('booking_id');
        return view('bookings.index', ['rows' => $rows, 'lines' => $lines, 'tours' => $tours, 'table' => $table,
            'desks' => DB::table('travel_desks')->pluck('name'), 'agents' => can('bookings.view_all') ? DB::table('users')->orderBy('full_name')->get(['id', 'full_name']) : collect()]);
    }

    /** One row per tour item with receipt-level payment details. */
    private function tableRows(array $ids, Request $r)
    {
        if (! $ids) return collect();
        $items = DB::table('booking_items')->join('bookings', 'bookings.id', '=', 'booking_items.booking_id')->join('customers', 'customers.id', '=', 'bookings.customer_id')
            ->leftJoin('users as sp', 'sp.id', '=', 'bookings.sales_person_id')->whereIn('bookings.id', $ids)->where('booking_items.status', '!=', 'cancelled')
            ->when($r->tour_from, fn ($x) => $x->where('booking_items.tour_date', '>=', $r->tour_from))->when($r->tour_to, fn ($x) => $x->where('booking_items.tour_date', '<=', $r->tour_to))
            ->select('booking_items.*', 'bookings.receipt_number', 'bookings.issued_at', 'bookings.travel_desk', 'bookings.total_amount', 'bookings.paid_amount', 'bookings.refunded_amount', 'bookings.balance_due',
                'bookings.payment_status', 'bookings.status as booking_status', 'bookings.balance_collection', 'bookings.notes as booking_notes', 'bookings.base_currency',
                'customers.title', 'customers.name', 'customers.hotel', 'customers.room_number', 'customers.phone', 'customers.contacts', 'customers.notes as customer_notes', 'sp.full_name as agent')
            ->orderByDesc('bookings.issued_at')->orderByDesc('bookings.id')->orderBy('booking_items.id')->get();
        $adds = DB::table('booking_item_addons')->whereIn('booking_item_id', $items->pluck('id'))->get()->groupBy('booking_item_id');
        $pays = DB::table('payments')->whereIn('booking_id', $ids)->where('status', 'active')->get()->groupBy('booking_id');
        return $items->map(function ($it) use ($adds, $pays) {
            $a = $adds->get($it->id, collect());
            $p = $pays->get($it->booking_id, collect());
            $by = fn ($m) => round($p->where('method', $m)->sum('base_amount'), 2);
            $b = (object) ['receipt_number' => $it->receipt_number, 'notes' => $it->booking_notes];
            $c = (object) ['title' => $it->title, 'name' => $it->name, 'hotel' => $it->hotel, 'room_number' => $it->room_number, 'phone' => $it->phone, 'contacts' => $it->contacts, 'notes' => $it->customer_notes];
            return [
                'booking_id' => $it->booking_id, 'created' => Fmt::dt($it->issued_at), 'desk' => $it->travel_desk ?: '-', 'agent' => $it->agent ?: '-', 'receipt' => $it->receipt_number,
                'code' => $it->tour_code, 'tour_date' => Fmt::date($it->tour_date), 'tour_sort' => $it->tour_date, 'tour' => $it->tour_name.($it->option_name ? ' – '.$it->option_name : ''),
                'transfer' => Fmt::transfer($it), 'addons' => Fmt::addons($a) ?: '-', 'guest' => $it->title.' '.$it->name, 'pickup' => Fmt::pickup($it, $it->hotel), 'room' => $it->room_number ?: '-',
                'contacts' => Fmt::contacts($it->contacts, $it->phone), 'copy' => Fmt::copyText($it, $a, $b, $c), 'pax' => "{$it->adults}A / {$it->children}C / {$it->infants}I", 'item_total' => (float) $it->total,
                'receipt_total' => (float) $it->total_amount, 'paid' => round($it->paid_amount - $it->refunded_amount, 2), 'balance' => (float) $it->balance_due,
                'cash' => $by('cash'), 'card' => $by('card'), 'driver' => $by('driver'),
                'payments' => $p->map(fn ($x) => Fmt::label($x->method).' '.$x->currency.' '.number_format($x->amount, 2).($x->change_amount > 0 ? " (change {$x->change_currency} ".number_format($x->change_amount, 2).')' : ''))->implode(' · ') ?: '-',
                'pay_status' => Fmt::label($it->payment_status), 'status' => Fmt::label($it->booking_status), 'collection' => $it->balance_due > 0 ? ($it->balance_collection === 'driver' ? 'Driver' : 'Travel Desk') : '-',
            ];
        });
    }

    public function export(Request $r)
    {
        $r->merge(['view' => 'table']);
        $ids = $this->filtered($r)->orderByDesc('bookings.issued_at')->limit(5000)->pluck('bookings.id')->all();
        $rows = $this->tableRows($ids, $r);
        $cols = ['created' => 'Booking Creation Date', 'desk' => 'Travel Desk', 'agent' => 'Travel Agent', 'receipt' => 'Receipt No.', 'code' => 'Tour Code', 'tour_date' => 'Tour Date', 'tour' => 'Tour / Ticket', 'transfer' => 'Transfer',
            'addons' => 'Add Ons', 'guest' => 'Guest Name', 'pickup' => 'Hotel / Pick Up Location', 'room' => 'Room No.', 'contacts' => 'Contact Number', 'copy' => 'Copy Text', 'pax' => 'Pax', 'item_total' => 'Item Total',
            'receipt_total' => 'Receipt Total', 'paid' => 'Paid', 'balance' => 'Balance Due', 'cash' => 'Cash', 'card' => 'Card', 'driver' => 'Driver Collected', 'payments' => 'Payment Details', 'pay_status' => 'Payment Status', 'collection' => 'Balance Collection', 'status' => 'Booking Status'];
        Audit::log('report', null, 'bookings_exported', ['rows' => $rows->count()]);
        return response()->streamDownload(function () use ($rows, $cols) {
            $out = fopen('php://output', 'w');
            fwrite($out, "\xEF\xBB\xBF");
            fputcsv($out, array_values($cols));
            $seen = [];
            foreach ($rows as $row) {
                $first = ! isset($seen[$row['booking_id']]);
                $seen[$row['booking_id']] = true;
                fputcsv($out, array_map(function ($k) use ($row, $first) {
                    if (! $first && in_array($k, ['receipt_total', 'paid', 'balance', 'cash', 'card', 'driver', 'payments'])) return '';
                    $v = is_float($row[$k]) ? number_format($row[$k], 2, '.', '') : (string) $row[$k];
                    return strlen($v) > 1 && preg_match('/^[=+\-@]/', $v) && ! is_numeric($v) ? "'".$v : $v;
                }, array_keys($cols)));
            }
            fclose($out);
        }, 'bookings-'.now()->format('Y-m-d').'.csv', ['Content-Type' => 'text/csv; charset=utf-8']);
    }

    private function formData(?array $initial): array
    {
        $u = auth()->user();
        $ps = Settings::get('payments');
        return [
            'catalog' => Catalog::all(), 'currencies' => DB::table('currencies')->where('active', true)->orderByDesc('is_base')->orderBy('code')->get(), 'base' => Settings::base(),
            'desks' => DB::table('travel_desks')->where('active', true)->orderBy('name')->pluck('name'), 'terms' => DB::table('terms')->where('active', true)->get(['id', 'title', 'is_default']),
            'sales' => DB::table('users')->where('status', 'active')->orderBy('full_name')->get(['id', 'full_name as name']),
            'canSelectSales' => $u->can('bookings.select_salesperson'), 'canTerms' => $u->can('bookings.terms_override'), 'canOverride' => $u->can('pricing.override'),
            'pay' => ['cash' => $ps['cash_enabled'], 'card' => $ps['card_enabled'], 'requireRef' => $ps['require_card_reference'], 'providers' => $ps['card_providers'], 'tolerance' => (float) $ps['overpayment_tolerance']],
            'me' => ['id' => $u->id, 'name' => $u->full_name], 'today' => now()->toDateString(), 'csrf' => csrf_token(), 'initial' => $initial,
            'urls' => ['save' => $initial ? route('bookings.update', $initial['id']) : route('bookings.store'), 'approval' => route('approvals.request'), 'approvalStatus' => route('approvals.status')],
        ];
    }

    public function create() { return view('bookings.form', ['data' => $this->formData(null), 'initial' => null, 'receipt' => null, 'hotels' => DB::table('hotels')->orderBy('name')->pluck('name')]); }

    public function edit(int $id)
    {
        $b = DB::table('bookings')->where('id', $id)->first();
        abort_unless($b, 404);
        if (in_array($b->status, ['cancelled', 'refunded'])) return redirect()->route('bookings.show', $id)->with('error', 'Cancelled/refunded bookings cannot be edited.');
        $c = DB::table('customers')->where('id', $b->customer_id)->first();
        $items = DB::table('booking_items')->where('booking_id', $id)->where('status', '!=', 'cancelled')->orderBy('id')->get();
        $adds = DB::table('booking_item_addons')->whereIn('booking_item_id', $items->pluck('id'))->get()->groupBy('booking_item_id');
        $initial = [
            'id' => $b->id, 'paid' => round($b->paid_amount - $b->refunded_amount, 2), 'travel_desk' => $b->travel_desk, 'sales_person_id' => $b->sales_person_id, 'balance_collection' => $b->balance_collection,
            'notes' => $b->notes, 'terms_id' => $b->terms_id, 'terms_override' => $b->terms_override, 'customer_signature' => $b->customer_signature, 'agent_signature' => $b->agent_signature,
            'customer' => ['title' => $c->title, 'name' => $c->name, 'hotel' => $c->hotel, 'room_number' => $c->room_number, 'email' => $c->email, 'notes' => $c->notes,
                'contacts' => array_map(fn ($x) => $x + ['other' => ''], json_decode($c->contacts, true) ?: [['number' => $c->phone, 'call' => true]])],
            'items' => $items->map(function ($i) use ($adds) {
                $a = $adds->get($i->id, collect());
                return ['id' => $i->id, 'tour_id' => $i->tour_id, 'option_id' => $i->option_id, 'tour_date' => $i->tour_date, 'adults' => $i->adults, 'children' => $i->children, 'infants' => $i->infants,
                    'transfer_type' => $i->transfer_type, 'transfer_direction' => $i->transfer_direction ?? 'two_way', 'vehicle_id' => $i->vehicle_id, 'vehicle_count' => max(1, $i->vehicle_count), 'slot_id' => $i->slot_id,
                    'pickup_time' => $i->transfer_type === 'private' ? $i->pickup_time : '', 'pickup_location' => $i->pickup_location, 'drop_location' => $i->drop_location,
                    'adult_price' => $i->sold_adult_price ?? '', 'child_price' => $i->sold_child_price ?? '', 'infant_price' => $i->sold_infant_price ?? '', 'agreed_price' => $i->agreed_price ?? '', 'discount' => '',
                    'addons' => $a->pluck('quantity', 'addon_id')->all(), 'addon_prices' => $a->pluck('unit_price', 'addon_id')->all(), 'notes' => $i->notes, 'approval_id' => $i->price_approval_id];
            })->all(),
        ];
        return view('bookings.form', ['data' => $this->formData($initial), 'initial' => $initial, 'receipt' => $b->receipt_number, 'hotels' => DB::table('hotels')->orderBy('name')->pluck('name')]);
    }

    public function store(Request $r)
    {
        try {
            $id = BookingService::save($r->json()->all(), $r->user());
        } catch (\RuntimeException $e) {
            return response()->json(['error' => $e->getMessage()]);
        }
        return response()->json(['ok' => true, 'id' => $id, 'redirect' => route('bookings.show', $id).'?saved=1']);
    }

    public function update(Request $r, int $id)
    {
        try {
            BookingService::save($r->json()->all(), $r->user(), $id);
        } catch (\RuntimeException $e) {
            return response()->json(['error' => $e->getMessage()]);
        }
        return response()->json(['ok' => true, 'id' => $id, 'redirect' => route('bookings.show', $id).'?saved=1']);
    }

    public static function full(int $id): ?array
    {
        $b = DB::table('bookings')->leftJoin('users as sp', 'sp.id', '=', 'bookings.sales_person_id')->leftJoin('users as cb', 'cb.id', '=', 'bookings.created_by_id')
            ->where('bookings.id', $id)->select('bookings.*', 'sp.full_name as sales_person', 'cb.display_name as created_by')->first();
        if (! $b) return null;
        $items = DB::table('booking_items')->leftJoin('suppliers', 'suppliers.id', '=', 'booking_items.supplier_id')->where('booking_id', $id)->orderBy('booking_items.id')->select('booking_items.*', 'suppliers.name as supplier_name')->get();
        $terms = $b->terms_override ?: (DB::table('terms')->where('id', $b->terms_id)->value('content') ?? DB::table('terms')->where('is_default', true)->where('active', true)->value('content'));
        return [
            'b' => $b, 'c' => DB::table('customers')->where('id', $b->customer_id)->first(), 'items' => $items,
            'addons' => DB::table('booking_item_addons')->whereIn('booking_item_id', $items->pluck('id'))->get()->groupBy('booking_item_id'),
            'payments' => DB::table('payments')->join('users', 'users.id', '=', 'payments.user_id')->where('booking_id', $id)->orderBy('paid_at')->select('payments.*', 'users.display_name as staff')->get(),
            'refunds' => DB::table('refunds')->join('users', 'users.id', '=', 'refunds.user_id')->where('booking_id', $id)->select('refunds.*', 'users.display_name as staff')->get(),
            'tickets' => DB::table('tickets')->where('booking_id', $id)->orderBy('id')->get()->groupBy('booking_item_id'),
            'terms' => $terms, 'company' => Settings::get('company'),
        ];
    }

    public function show(Request $r, int $id)
    {
        $d = self::full($id);
        abort_unless($d, 404);
        if (! self::allowed($d['b'])) return redirect()->route('bookings')->with('error', 'You can only open your own bookings.');
        $d['logs'] = can('audit.view') ? DB::table('audit_logs')->leftJoin('users', 'users.id', '=', 'audit_logs.user_id')->where('entity_type', 'booking')->where('entity_id', $id)->orderByDesc('audit_logs.id')->select('audit_logs.*', 'users.display_name as who')->limit(100)->get() : collect();
        $d['currencies'] = DB::table('currencies')->where('active', true)->orderByDesc('is_base')->get();
        $d['suppliers'] = DB::table('suppliers')->where('active', true)->orderBy('name')->get(['id', 'name']);
        $d['links'] = DB::table('tour_suppliers')->whereIn('tour_id', $d['items']->pluck('tour_id'))->get()->groupBy('tour_id');
        $d['myReviews'] = DB::table('supplier_reviews')->where('user_id', auth()->id())->whereIn('booking_item_id', $d['items']->pluck('id'))->get()->keyBy('booking_item_id');
        $d['emails'] = DB::table('email_logs')->where('booking_id', $id)->orderByDesc('id')->limit(5)->get();
        $d['pay'] = Settings::get('payments');
        return view('bookings.show', $d);
    }

    public function receipt(int $id, Request $r)
    {
        $d = self::full($id);
        abort_unless($d && self::allowed($d['b']), 404);
        Audit::log('booking', $id, 'receipt_printed', ['layout' => $r->layout ?? 'a4']);
        return view($r->layout === 'thermal' ? 'bookings.thermal' : 'bookings.receipt', $d + ['blank' => $r->boolean('blank'), 'pdf' => false]);
    }

    public static function pdfBinary(array $d): string
    {
        return Pdf::loadView('bookings.receipt', $d + ['blank' => false, 'pdf' => true])->setPaper('a4')->setOption(['isFontSubsettingEnabled' => true])->output();
    }

    public function pdf(int $id)
    {
        $d = self::full($id);
        abort_unless($d && self::allowed($d['b']), 404);
        return response(self::pdfBinary($d), 200, ['Content-Type' => 'application/pdf', 'Content-Disposition' => 'inline; filename="Receipt-'.$d['b']->receipt_number.'.pdf"']);
    }

    public function email(Request $r, int $id)
    {
        $d = self::full($id);
        abort_unless($d && self::allowed($d['b']), 404);
        $to = trim((string) ($r->email ?: $d['c']->email));
        if (! filter_var($to, FILTER_VALIDATE_EMAIL)) return back()->with('error', 'A valid customer email is required.');
        $tpl = DB::table('email_templates')->where('key', $r->template ?: 'receipt')->first() ?? DB::table('email_templates')->where('key', 'receipt')->first();
        $active = $d['items']->where('status', '!=', 'cancelled');
        $cur = $d['b']->base_currency;
        $vars = ['{{customer_name}}' => $d['c']->title.' '.$d['c']->name, '{{receipt_number}}' => $d['b']->receipt_number, '{{tour_name}}' => $active->pluck('tour_name')->implode(', '),
            '{{tour_date}}' => $active->map(fn ($i) => Fmt::date($i->tour_date))->unique()->implode(', '), '{{total_amount}}' => Fmt::money($d['b']->total_amount, $cur),
            '{{amount_paid}}' => Fmt::money($d['b']->paid_amount - $d['b']->refunded_amount, $cur), '{{balance}}' => Fmt::money($d['b']->balance_due, $cur), '{{company_name}}' => $d['company']['name']];
        $subject = strtr($tpl->subject, $vars);
        $body = strtr($tpl->body, $vars);
        $status = 'sent'; $error = null;
        try {
            MailConfig::apply();
            $pdf = self::pdfBinary($d);
            $files = [];
            if (str_starts_with($tpl->key, 'ticket')) foreach ($d['tickets']->flatten() as $t) if ($t->status === 'active' && $t->file_path) $files[] = $t;
            Mail::raw($body, function ($m) use ($to, $subject, $pdf, $d, $files) {
                $m->to($to)->subject($subject)->attachData($pdf, 'Receipt-'.$d['b']->receipt_number.'.pdf', ['mime' => 'application/pdf']);
                foreach ($files as $t) $m->attach(storage_path('app/private/'.$t->file_path), ['as' => $t->file_name]);
            });
        } catch (\Throwable $e) {
            $status = 'failed'; $error = $e->getMessage();
        }
        DB::table('email_logs')->insert(['booking_id' => $id, 'template' => $tpl->key, 'recipient' => $to, 'subject' => $subject, 'status' => $status, 'error' => $error, 'user_id' => auth()->id(), 'created_at' => now()]);
        Audit::log('booking', $id, 'receipt_emailed', ['to' => $to, 'status' => $status]);
        if ($status === 'sent') {
            DB::table('bookings')->where('id', $id)->update(['last_emailed_at' => now()]);
            return back()->with('ok', "Receipt emailed to $to.");
        }
        return back()->with('error', "Email not sent: $error");
    }

    public function status(Request $r, int $id)
    {
        $d = $r->validate(['status' => 'required|in:draft,confirmed,pending,cancelled,completed', 'reason' => 'nullable|string|max:300']);
        if ($d['status'] === 'cancelled' && strlen(trim($d['reason'] ?? '')) < 3) return back()->with('error', 'A cancellation reason is required.');
        $b = DB::table('bookings')->where('id', $id)->first();
        DB::table('bookings')->where('id', $id)->update(['status' => $d['status'], 'updated_at' => now()]);
        if ($d['status'] === 'completed') DB::table('booking_items')->where('booking_id', $id)->where('status', 'active')->update(['status' => 'completed']);
        Audit::log('booking', $id, $d['status'] === 'cancelled' ? 'booking_cancelled' : 'status_changed', ['from' => $b->status, 'to' => $d['status'], 'reason' => $d['reason'] ?? null]);
        Finance::recalc($id);
        return back()->with('ok', 'Status updated.');
    }

    public function signatures(Request $r, int $id)
    {
        $b = DB::table('bookings')->where('id', $id)->first();
        abort_unless($b && self::allowed($b), 404);
        $u = [];
        foreach (['customer_signature', 'agent_signature'] as $k) {
            $v = $r->input($k);
            if ($v && str_starts_with($v, 'data:image/png;base64,') && strlen($v) < 400000) $u[$k] = $v;
        }
        if ($u) DB::table('bookings')->where('id', $id)->update($u);
        Audit::log('booking', $id, 'signatures_updated');
        return back()->with('ok', 'Signatures saved.');
    }
}
