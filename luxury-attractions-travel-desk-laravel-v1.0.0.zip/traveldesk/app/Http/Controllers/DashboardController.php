<?php

namespace App\Http\Controllers;

use App\Support\Settings;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        $u = auth()->user();
        $scope = fn ($q) => BookingController::scope($q)->where('bookings.status', '!=', 'cancelled');
        $today = today();
        $d = [
            'cur' => Settings::base(),
            'todayB' => $scope(DB::table('bookings'))->whereDate('issued_at', $today)->selectRaw('count(*) n, coalesce(sum(total_amount),0) t, coalesce(sum(balance_due),0) bal')->first(),
            'month' => $scope(DB::table('bookings'))->where('issued_at', '>=', $today->copy()->startOfMonth())->selectRaw('count(*) n, coalesce(sum(total_amount),0) t')->first(),
            'pending' => $scope(DB::table('bookings'))->whereIn('payment_status', ['unpaid', 'partially_paid'])->selectRaw('count(*) n, coalesce(sum(balance_due),0) bal')->first(),
            'upcoming' => $scope(DB::table('booking_items')->join('bookings', 'bookings.id', '=', 'booking_items.booking_id')->join('customers', 'customers.id', '=', 'bookings.customer_id'))
                ->where('tour_date', '>=', $today)->where('booking_items.status', 'active')->orderBy('tour_date')->limit(8)->get(['booking_items.*', 'customers.name as cust', 'customers.hotel']),
            'recent' => BookingController::scope(DB::table('bookings')->join('customers', 'customers.id', '=', 'bookings.customer_id'))->orderByDesc('bookings.id')->limit(8)->get(['bookings.*', 'customers.name as cust']),
            'outstanding' => $scope(DB::table('bookings')->join('customers', 'customers.id', '=', 'bookings.customer_id'))->where('balance_due', '>', 0)->orderByDesc('balance_due')->limit(6)->get(['bookings.*', 'customers.name as cust']),
            'att' => DB::table('attendance')->where('user_id', $u->id)->where('date', $today->toDateString())->first(),
            'showSales' => $u->can('bookings.view_all') || (Settings::get('booking')['agents_see_own_sales'] && $u->can('reports.own_sales')),
        ];
        if ($u->can('bookings.view_all')) {
            $d['staffAtt'] = DB::table('users')->leftJoin('attendance', fn ($j) => $j->on('attendance.user_id', '=', 'users.id')->where('attendance.date', $today->toDateString()))->where('users.status', 'active')->get(['users.display_name', 'attendance.actual_in', 'attendance.actual_out', 'attendance.late_fine', 'attendance.is_day_off']);
            $d['fines'] = DB::table('fines')->where('status', 'outstanding')->selectRaw('count(*) n, coalesce(sum(amount),0) s')->first();
            $d['ticketsNeeded'] = DB::table('booking_items')->where('product_type', 'ticket')->where('status', 'active')->where('tour_date', '>=', $today)->whereNotExists(fn ($q) => $q->from('tickets')->whereColumn('tickets.booking_item_id', 'booking_items.id')->where('tickets.status', 'active'))->count();
            $d['byTour'] = DB::table('booking_items')->join('bookings', 'bookings.id', '=', 'booking_items.booking_id')->where('bookings.issued_at', '>=', $today->copy()->startOfMonth())->where('bookings.status', '!=', 'cancelled')->where('booking_items.status', '!=', 'cancelled')->groupBy('tour_name')->selectRaw('tour_name, sum(total) t')->orderByDesc('t')->limit(6)->get();
        }
        return view('dashboard', $d);
    }
}
