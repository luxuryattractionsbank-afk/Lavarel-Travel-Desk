<?php

namespace App\Http\Controllers;

use App\Support\Audit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class StaffController extends Controller
{
    public function index()
    {
        return view('staff.index', ['rows' => DB::table('users')->join('roles', 'roles.id', '=', 'users.role_id')->leftJoin('employee_schedules as s', 's.user_id', '=', 'users.id')->orderBy('full_name')->get(['users.*', 'roles.name as role', 's.check_in', 's.check_out', 's.weekly_days_off'])]);
    }

    public function edit($id)
    {
        $u = $id === 'new' ? null : DB::table('users')->where('id', $id)->first();
        return view('staff.edit', ['u' => $u, 's' => $u ? DB::table('employee_schedules')->where('user_id', $u->id)->first() : null, 'roles' => DB::table('roles')->get()]);
    }

    public function save(Request $r, $id = null)
    {
        $d = $r->validate(['full_name' => 'required|string|max:120', 'username' => ['required', 'regex:/^[a-z0-9._-]{3,40}$/', 'unique:users,username'.($id ? ",$id" : '')], 'email' => 'required|email',
            'role_id' => 'required|exists:roles,id', 'password' => ($id ? 'nullable' : 'required').'|min:8', 'check_in' => 'required|date_format:H:i', 'check_out' => 'required|date_format:H:i', 'monthly_salary' => 'nullable|numeric|min:0']);
        if ($id == auth()->id() && $r->status === 'inactive') return back()->with('error', 'You cannot deactivate yourself.');
        $vals = ['full_name' => $d['full_name'], 'display_name' => $r->display_name ?: $d['full_name'], 'username' => $d['username'], 'email' => $d['email'], 'role_id' => $d['role_id'],
            'work_mobile' => $r->work_mobile, 'work_whatsapp' => $r->boolean('work_whatsapp'), 'personal_mobile' => $r->personal_mobile, 'personal_whatsapp' => $r->boolean('personal_whatsapp'),
            'status' => $r->status === 'inactive' ? 'inactive' : 'active', 'joining_date' => $r->joining_date ?: null, 'notes' => $r->notes, 'monthly_salary' => (float) $r->monthly_salary, 'updated_at' => now()];
        if (! empty($d['password'])) $vals['password'] = Hash::make($d['password']);
        if ($id) DB::table('users')->where('id', $id)->update($vals); else $id = DB::table('users')->insertGetId($vals + ['created_at' => now()]);
        DB::table('employee_schedules')->updateOrInsert(['user_id' => $id], ['check_in' => $d['check_in'], 'check_out' => $d['check_out'], 'weekly_days_off' => json_encode(array_map('intval', $r->input('days_off', [])))]);
        Audit::log('user', (int) $id, 'user_saved', ['username' => $d['username'], 'password_changed' => ! empty($d['password'])]);
        return redirect()->route('staff.edit', $id)->with('ok', 'Employee saved.');
    }
}
