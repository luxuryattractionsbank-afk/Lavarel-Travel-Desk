<?php

namespace App\Http\Controllers;

use App\Support\Audit;
use App\Support\Catalog;
use App\Support\Pricing;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ApprovalController extends Controller
{
    public function index()
    {
        $u = auth()->user();
        $rows = DB::table('price_approvals')->join('users as rq', 'rq.id', '=', 'price_approvals.requested_by_id')->leftJoin('users as dc', 'dc.id', '=', 'price_approvals.decided_by_id')
            ->when(! $u->can('pricing.approve'), fn ($q) => $q->where('requested_by_id', $u->id))->orderByDesc('price_approvals.id')->limit(200)
            ->get(['price_approvals.*', 'rq.full_name as agent', 'dc.full_name as decider']);
        return view('approvals', ['rows' => $rows]);
    }

    public function request(Request $r)
    {
        $it = $r->input('item', []);
        $tour = Catalog::tour((int) ($it['tour_id'] ?? 0));
        if (! $tour) return response()->json(['error' => 'Select a tour first.']);
        $opt = collect($tour['options'])->firstWhere('id', (int) ($it['option_id'] ?? 0));
        $res = Pricing::calculate($tour, $opt, $it, $tour);
        if ($res['errors']) return response()->json(['error' => implode(' ', $res['errors'])]);
        if (! $res['requires_approval']) return response()->json(['error' => 'This price is within the minimum – no approval needed.']);
        DB::table('price_approvals')->where('requested_by_id', auth()->id())->where('tour_id', $tour['id'])->where('status', 'pending')->whereNull('booking_item_id')->update(['status' => 'cancelled']);
        $id = DB::table('price_approvals')->insertGetId([
            'requested_by_id' => auth()->id(), 'tour_id' => $tour['id'], 'option_id' => $opt['id'] ?? null, 'tour_name' => $tour['name'], 'option_name' => $opt['name'] ?? null,
            'adults' => (int) $it['adults'], 'children' => (int) $it['children'], 'infants' => (int) $it['infants'], 'standard_total' => $res['standard'], 'min_total' => $res['min_total'], 'requested_total' => $res['total'],
            'customer_name' => $r->customer_name, 'reason' => implode(' · ', array_filter([$r->reason, ...$res['approval_reasons']])), 'snapshot' => json_encode($it), 'expires_at' => now()->addDay(), 'created_at' => now(), 'updated_at' => now(),
        ]);
        Audit::log('price_approval', $id, 'price_approval_requested', ['tour' => $tour['name'], 'requested' => $res['total'], 'minimum' => $res['min_total']]);
        return response()->json(['ok' => true, 'id' => $id, 'total' => $res['total']]);
    }

    public function status(Request $r)
    {
        $u = auth()->user();
        $ids = array_filter(array_map('intval', explode(',', (string) $r->ids)));
        return response()->json([
            'pending' => $u->can('pricing.approve') ? DB::table('price_approvals')->where('status', 'pending')->where('requested_by_id', '!=', $u->id)->where('expires_at', '>', now())->count() : 0,
            'mine' => $ids ? DB::table('price_approvals')->leftJoin('users', 'users.id', '=', 'price_approvals.decided_by_id')->whereIn('price_approvals.id', $ids)->where('price_approvals.requested_by_id', $u->id)->get(['price_approvals.id', 'price_approvals.status', 'price_approvals.decision_note', 'users.full_name as by']) : [],
        ]);
    }

    public function decide(Request $r, int $id)
    {
        $a = DB::table('price_approvals')->where('id', $id)->first();
        if (! $a) return back()->with('error', 'Request not found.');
        if ($a->requested_by_id == auth()->id()) return back()->with('error', 'You cannot authorise your own request – it must be approved from another authorised user\'s login.');
        if ($a->status !== 'pending' || now()->gt($a->expires_at)) return back()->with('error', 'This request is no longer pending.');
        $decision = $r->decision === 'approved' ? 'approved' : 'rejected';
        if ($decision === 'rejected' && ! trim((string) $r->note)) return back()->with('error', 'Please give a reason for rejecting.');
        DB::table('price_approvals')->where('id', $id)->update(['status' => $decision, 'decided_by_id' => auth()->id(), 'decided_at' => now(), 'decision_note' => $r->note]);
        Audit::log('price_approval', $id, 'price_approval_'.$decision, ['requested' => $a->requested_total, 'minimum' => $a->min_total]);
        return back()->with('ok', $decision === 'approved' ? 'Approved – the agent can now save the booking.' : 'Rejected.');
    }
}
