<?php

namespace App\Http\Controllers;

use App\Support\Audit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class AuthController extends Controller
{
    public function show() { return Auth::check() ? redirect()->route('dashboard') : view('auth.login'); }

    public function login(Request $r)
    {
        $d = $r->validate(['username' => 'required|string|max:120', 'password' => 'required|string|max:200']);
        $field = str_contains($d['username'], '@') ? 'email' : 'username';
        if (! Auth::attempt([$field => strtolower($d['username']), 'password' => $d['password'], 'status' => 'active'], true)) {
            return back()->withInput(['username' => $d['username']])->with('error', 'Invalid username or password, or the account is inactive.');
        }
        $r->session()->regenerate();
        Audit::log('user', Auth::id(), 'login');
        return redirect()->intended(route('dashboard'));
    }

    public function logout(Request $r)
    {
        Auth::logout();
        $r->session()->invalidate();
        $r->session()->regenerateToken();
        return redirect()->route('login');
    }
}
