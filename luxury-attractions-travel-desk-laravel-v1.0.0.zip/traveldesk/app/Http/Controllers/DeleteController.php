<?php

namespace App\Http\Controllers;

use App\Support\Audit;
use App\Support\Finance;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

/** Permanent delete (permission records.delete). A full copy of the record is kept in the audit log. */
class DeleteController extends Controller
{
    private const MAP = [
        'booking' => 'bookings', 'payment' => 'payments', 'refund' => 'refunds', 'ticket' => 'tickets', 'tour' => 'tours', 'option' => 'tour_options', 'addon' => 'addons',
        'slot' => 'pickup_slots', 'vehicle' => 'vehicles', 'supplier' => 'suppliers', 'supplier_tx' => 'supplier_transactions', 'review' => 'supplier_reviews', 'user' => 'users',
        'fine' => 'fines', 'attendance' => 'attendance', 'day_off' => 'days_off', 'advance' => 'salary_advances', 'cash_handover' => 'cash_handovers', 'approval' => 'price_approvals',
        'terms' => 'terms', 'hotel' => 'hotels', 'desk' => 'travel_desks', 'role' => 'roles',
    ];

    public function destroy(Request $r, string $entity, int $id)
    {
        $table = self::MAP[$entity] ?? abort(404);
        $row = DB::table($table)->where('id', $id)->first();
        if (! $row) return back()->with('error', 'Record not found (it may already have been deleted).');
        $files = [];
        try {
            DB::transaction(function () use ($entity, $table, $id, $row, &$files) {
                switch ($entity) {
                    case 'booking':
                        $files = array_merge(DB::table('tickets')->where('booking_id', $id)->pluck('file_path')->all(), DB::table('payments')->where('booking_id', $id)->pluck('slip_path')->all());
                        DB::table('price_approvals')->whereIn('booking_item_id', DB::table('booking_items')->where('booking_id', $id)->pluck('id'))->update(['booking_item_id' => null]);
                        DB::table('supplier_transactions')->where('booking_id', $id)->delete();
                        DB::table('bookings')->where('id', $id)->delete(); // items, payments, refunds, tickets cascade
                        if (! DB::table('bookings')->where('customer_id', $row->customer_id)->exists()) DB::table('customers')->where('id', $row->customer_id)->delete();
                        break;
                    case 'payment': case 'refund':
                        if ($entity === 'payment') { $files[] = $row->slip_path; DB::table('supplier_transactions')->where('payment_id', $id)->delete(); }
                        DB::table($table)->where('id', $id)->delete();
                        Finance::recalc($row->booking_id);
                        break;
                    case 'ticket': $files[] = $row->file_path; DB::table('tickets')->where('id', $id)->delete(); break;
                    case 'tour':
                        if ($n = DB::table('booking_items')->where('tour_id', $id)->count()) throw new \RuntimeException("This product is used on $n booking line(s). Delete those bookings first, or set it to Inactive.");
                        DB::table('price_approvals')->where('tour_id', $id)->delete();
                        DB::table('tours')->where('id', $id)->delete();
                        break;
                    case 'user':
                        if ($id === auth()->id()) throw new \RuntimeException('You cannot delete your own account.');
                        $n = DB::table('bookings')->where('created_by_id', $id)->orWhere('sales_person_id', $id)->count() + DB::table('payments')->where('user_id', $id)->count();
                        if ($n) throw new \RuntimeException("This employee has $n booking/payment record(s). Set them to Inactive instead to keep the history.");
                        DB::table('users')->where('id', $id)->delete();
                        break;
                    case 'role':
                        if ($row->system) throw new \RuntimeException('Built-in roles cannot be deleted.');
                        if (DB::table('users')->where('role_id', $id)->exists()) throw new \RuntimeException('Users still have this role – move them first.');
                        DB::table('roles')->where('id', $id)->delete();
                        break;
                    default:
                        DB::table($table)->where('id', $id)->delete();
                }
                Audit::log($entity, $id, 'record_deleted', ['reason' => request('reason'), 'snapshot' => (array) $row]);
            });
        } catch (\RuntimeException $e) {
            return back()->with('error', $e->getMessage());
        } catch (\Illuminate\Database\QueryException $e) {
            return back()->with('error', 'This record is still linked to other records and cannot be deleted. Remove the linked records first.');
        }
        foreach (array_filter($files) as $f) Storage::disk('local')->delete($f);
        $back = $r->back && str_starts_with($r->back, url('/')) ? $r->back : url()->previous();
        return redirect($back)->with('ok', ucfirst(str_replace('_', ' ', $entity)).' deleted.');
    }
}
