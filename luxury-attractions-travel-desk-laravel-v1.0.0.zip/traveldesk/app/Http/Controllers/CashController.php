<?php

namespace App\Http\Controllers;

use App\Support\Audit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CashController extends Controller
{
    /** Cash held per agent & currency = cash received − change given − cash refunds − handed over. */
    public static function holdings(?int $only = null): array
    {
        $add = function (&$h, $u, $c, $k, $v) { $h[$u][$c] ??= ['received' => 0, 'change' => 0, 'refunds' => 0, 'handed' => 0]; $h[$u][$c][$k] += (float) $v; };
        $h = [];
        foreach (DB::table('payments')->where('method', 'cash')->where('status', 'active')->when($only, fn ($q) => $q->where('user_id', $only))->groupBy('user_id', 'currency')->selectRaw('user_id, currency, sum(amount) s')->get() as $r) $add($h, $r->user_id, $r->currency, 'received', $r->s);
        foreach (DB::table('payments')->where('status', 'active')->where('change_amount', '>', 0)->when($only, fn ($q) => $q->where('user_id', $only))->groupBy('user_id', 'change_currency')->selectRaw('user_id, change_currency c, sum(change_amount) s')->get() as $r) $add($h, $r->user_id, $r->c, 'change', $r->s);
        foreach (DB::table('refunds')->where('method', 'cash')->when($only, fn ($q) => $q->where('user_id', $only))->groupBy('user_id', 'currency')->selectRaw('user_id, currency, sum(amount) s')->get() as $r) $add($h, $r->user_id, $r->currency, 'refunds', $r->s);
        foreach (DB::table('cash_handover_lines')->join('cash_handovers', 'cash_handovers.id', '=', 'cash_handover_lines.cash_handover_id')->when($only, fn ($q) => $q->where('agent_id', $only))->groupBy('agent_id', 'currency')->selectRaw('agent_id, currency, sum(amount) s')->get() as $r) $add($h, $r->agent_id, $r->currency, 'handed', $r->s);
        foreach ($h as &$u) foreach ($u as &$c) $c['held'] = round($c['received'] - $c['change'] - $c['refunds'] - $c['handed'], 2);
        return $h;
    }

    public function index()
    {
        $collector = can('cash.collect');
        $h = self::holdings($collector ? null : auth()->id());
        return view('cash', ['h' => $h, 'collector' => $collector, 'users' => DB::table('users')->pluck('full_name', 'id'), 'currencies' => DB::table('currencies')->where('active', true)->orderByDesc('is_base')->pluck('code'),
            'hand' => DB::table('cash_handovers')->join('users as a', 'a.id', '=', 'agent_id')->join('users as c', 'c.id', '=', 'collected_by_id')->when(! $collector, fn ($q) => $q->where('agent_id', auth()->id()))->orderByDesc('collected_at')->limit(100)->get(['cash_handovers.*', 'a.full_name as agent', 'c.full_name as collector']),
            'lines' => DB::table('cash_handover_lines')->get()->groupBy('cash_handover_id')]);
    }

    public function collect(Request $r)
    {
        $agent = (int) $r->agent_id;
        if ($agent === auth()->id()) return back()->with('error', 'You cannot record a handover to yourself.');
        $held = self::holdings($agent)[$agent] ?? [];
        $lines = collect($r->input('amt', []))->map(fn ($v, $c) => ['currency' => $c, 'amount' => round((float) $v, 2), 'expected' => $held[$c]['held'] ?? 0])->filter(fn ($l) => $l['amount'] > 0)->values();
        if ($lines->isEmpty()) return back()->with('error', 'Enter at least one amount collected.');
        $id = DB::table('cash_handovers')->insertGetId(['agent_id' => $agent, 'collected_by_id' => auth()->id(), 'collected_at' => $r->collected_at ?: now(), 'notes' => $r->notes]);
        foreach ($lines as $l) DB::table('cash_handover_lines')->insert($l + ['cash_handover_id' => $id]);
        Audit::log('cash_handover', $id, 'cash_collected', ['agent' => $agent, 'lines' => $lines]);
        $diff = $lines->filter(fn ($l) => abs($l['amount'] - $l['expected']) >= 0.01)->map(fn ($l) => $l['currency'].' '.number_format($l['amount'] - $l['expected'], 2))->implode(', ');
        return back()->with('ok', 'Cash collection recorded'.($diff ? " · difference vs expected: $diff" : '').'.');
    }
}
