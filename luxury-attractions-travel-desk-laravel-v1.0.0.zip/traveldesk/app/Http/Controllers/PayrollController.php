<?php

namespace App\Http\Controllers;

use App\Support\Audit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PayrollController extends Controller
{
    public const DEFAULT = ['tier_mode' => 'flat', 'tiers' => [[0, 5000, 5], [5001, 10000, 7], [10001, null, 10]], 'high_sale_enabled' => true, 'high_sale_markup_pct' => 50, 'high_sale_rate' => 5, 'high_sale_basis' => 'sale', 'negative_tiers' => [[0, 2500, 75], [2501, 4999, 50]]];

    public static function plan(int $uid): array
    {
        $p = DB::table('commission_plans')->where('scope', "user:$uid")->first() ?? DB::table('commission_plans')->where('scope', 'team')->first();
        return $p ? ['tier_mode' => $p->tier_mode, 'tiers' => json_decode($p->tiers, true), 'high_sale_enabled' => (bool) $p->high_sale_enabled, 'high_sale_markup_pct' => (float) $p->high_sale_markup_pct, 'high_sale_rate' => (float) $p->high_sale_rate, 'high_sale_basis' => $p->high_sale_basis, 'negative_tiers' => json_decode($p->negative_tiers, true), 'source' => $p->scope] : self::DEFAULT + ['source' => 'default'];
    }

    /** Whole-number bands like 0-5000 / 5001-10000 cover the gap between them. */
    private static function tierFor(float $v, array $tiers): ?array
    {
        foreach ($tiers as $t) { [$from, $to] = $t; if ($v > ($from > 0 ? $from - 1 : -0.01) && ($to === null || $v < $to + 1)) return $t; }
        return null;
    }

    public static function compute(int $uid, string $month): array
    {
        $u = DB::table('users')->where('id', $uid)->first();
        $p = self::plan($uid);
        $start = "$month-01"; $end = date('Y-m-t', strtotime($start)).' 23:59:59';
        $items = DB::table('booking_items')->join('bookings', 'bookings.id', '=', 'booking_items.booking_id')->where('sales_person_id', $uid)->whereBetween('issued_at', [$start, $end])->where('bookings.status', '!=', 'cancelled')->where('booking_items.status', '!=', 'cancelled')->get(['tour_code', 'tour_name', 'standard_price', 'total']);
        $refunds = (float) DB::table('refunds')->join('bookings', 'bookings.id', '=', 'refunds.booking_id')->where('sales_person_id', $uid)->whereBetween('issued_at', [$start, $end])->sum('base_amount');
        $sales = round($items->sum('total') - $refunds, 2);
        $comm = 0; $explain = 'No sales';
        if ($sales > 0) {
            if ($p['tier_mode'] === 'progressive') { foreach ($p['tiers'] as [$f, $t, $rate]) { $portion = max(0, min($sales, $t ?? $sales) - max(0, $f - ($f > 0 ? 1 : 0))); $comm += $portion * $rate / 100; } $explain = 'Progressive tiers'; }
            elseif ($t = self::tierFor($sales, $p['tiers'])) { $comm = $sales * $t[2] / 100; $explain = "Tier {$t[0]}–".($t[1] ?? '∞').": ".number_format($sales, 2)." × {$t[2]}%"; }
        }
        $high = [];
        if ($p['high_sale_enabled']) foreach ($items as $i) if ($i->standard_price > 0 && $i->total > $i->standard_price) { $mk = ($i->total - $i->standard_price) / $i->standard_price * 100; if ($mk + 0.001 >= $p['high_sale_markup_pct']) $high[] = ['code' => $i->tour_code, 'tour' => $i->tour_name, 'std' => (float) $i->standard_price, 'sold' => (float) $i->total, 'markup' => round($mk, 1), 'comm' => round(($p['high_sale_basis'] === 'excess' ? $i->total - $i->standard_price : $i->total) * $p['high_sale_rate'] / 100, 2)]; }
        $neg = 0; $negEx = 'Target met – no cut';
        if ($u->monthly_salary > 0 && ($t = self::tierFor(max(0, $sales), $p['negative_tiers']))) { $neg = round($u->monthly_salary * $t[2] / 100, 2); $negEx = "Sales in {$t[0]}–".($t[1] ?? '∞')." → {$t[2]}% of salary"; }
        $fines = (float) DB::table('fines')->where('user_id', $uid)->whereBetween('date', [$start, substr($end, 0, 10)])->where('status', '!=', 'waived')->sum('amount');
        $adv = (float) DB::table('salary_advances')->where('user_id', $uid)->where('month', $month)->where('status', '!=', 'cancelled')->sum('amount');
        $highTotal = round(array_sum(array_column($high, 'comm')), 2);
        $net = round($u->monthly_salary + $comm + $highTotal - $neg - $fines - $adv, 2);
        return ['user' => $u, 'plan' => $p, 'sales' => $sales, 'refunds' => $refunds, 'commission' => round($comm, 2), 'explain' => $explain, 'high' => $high, 'high_total' => $highTotal, 'negative' => $neg, 'negative_explain' => $negEx,
            'fines' => $fines, 'advances' => $adv, 'net' => $net, 'run' => DB::table('payroll_runs')->where('user_id', $uid)->where('month', $month)->first()];
    }

    public function index(Request $r)
    {
        $month = preg_match('/^\d{4}-\d{2}$/', (string) $r->month) ? $r->month : now()->format('Y-m');
        $manager = can('commission.manage');
        $staff = $manager ? DB::table('users')->where('status', 'active')->orderBy('full_name')->pluck('id') : collect([auth()->id()]);
        return view('payroll', ['month' => $month, 'manager' => $manager, 'calcs' => $staff->map(fn ($id) => self::compute($id, $month)), 'team' => self::plan(0),
            'advances' => DB::table('salary_advances')->join('users', 'users.id', '=', 'salary_advances.user_id')->when(! $manager, fn ($q) => $q->where('user_id', auth()->id()))->orderByDesc('date')->limit(100)->get(['salary_advances.*', 'users.full_name as name']),
            'users' => DB::table('users')->where('status', 'active')->orderBy('full_name')->get(['id', 'full_name'])]);
    }

    private static function tiers(string $text): array
    {
        $out = [];
        foreach (preg_split('/[\r\n;]+/', $text) as $line) {
            if (! trim($line)) continue;
            if (! preg_match('/^\s*([\d.,]+)\s*(?:-\s*([\d.,]+)|\+)\s*[=:]\s*([\d.]+)\s*%?\s*$/', $line, $m)) throw \Illuminate\Validation\ValidationException::withMessages(['tiers' => "Invalid tier \"$line\". Use e.g. 0-5000=5 or 10000+=10"]);
            $out[] = [(float) str_replace(',', '', $m[1]), isset($m[2]) && $m[2] !== '' ? (float) str_replace(',', '', $m[2]) : null, (float) $m[3]];
        }
        return $out;
    }

    public function action(Request $r, string $action)
    {
        $uid = (int) $r->user_id; $month = (string) $r->month;
        switch ($action) {
            case 'plan':
                $scope = $uid ? "user:$uid" : 'team';
                DB::table('commission_plans')->updateOrInsert(['scope' => $scope], ['user_id' => $uid ?: null, 'tier_mode' => $r->tier_mode === 'progressive' ? 'progressive' : 'flat', 'tiers' => json_encode(self::tiers((string) $r->tiers)), 'negative_tiers' => json_encode(self::tiers((string) $r->negative_tiers)),
                    'high_sale_enabled' => $r->boolean('high_sale_enabled'), 'high_sale_markup_pct' => (float) $r->high_sale_markup_pct, 'high_sale_rate' => (float) $r->high_sale_rate, 'high_sale_basis' => $r->high_sale_basis === 'excess' ? 'excess' : 'sale', 'updated_at' => now(), 'created_at' => now()]);
                Audit::log('commission_plan', $uid ?: null, 'commission_plan_saved', ['scope' => $scope]);
                return back()->with('ok', 'Commission plan saved.');
            case 'salary':
                DB::table('users')->where('id', $uid)->update(['monthly_salary' => max(0, (float) $r->salary)]);
                Audit::log('user', $uid, 'salary_changed', ['to' => $r->salary]);
                return back()->with('ok', 'Salary saved.');
            case 'advance':
                $d = $r->validate(['user_id' => 'required|exists:users,id', 'amount' => 'required|numeric|gt:0', 'date' => 'required|date', 'month' => 'required|date_format:Y-m']);
                DB::table('salary_advances')->insert($d + ['reason' => $r->reason, 'status' => 'outstanding', 'created_by_id' => auth()->id(), 'created_at' => now(), 'updated_at' => now()]);
                Audit::log('advance', $uid, 'advance_created', $d);
                return back()->with('ok', 'Advance recorded.');
            case 'finalize':
                $c = self::compute($uid, $month);
                if ($c['run']) return back()->with('error', 'Already finalized – reopen first.');
                DB::table('payroll_runs')->insert(['user_id' => $uid, 'month' => $month, 'breakdown' => json_encode(array_diff_key($c, ['user' => 1, 'run' => 1])), 'net_pay' => $c['net'], 'finalized_by_id' => auth()->id(), 'finalized_at' => now()]);
                DB::table('fines')->where('user_id', $uid)->whereBetween('date', ["$month-01", date('Y-m-t', strtotime("$month-01"))])->where('status', 'outstanding')->update(['status' => 'deducted']);
                DB::table('salary_advances')->where('user_id', $uid)->where('month', $month)->where('status', 'outstanding')->update(['status' => 'deducted']);
                Audit::log('payroll', $uid, 'payroll_finalized', ['month' => $month, 'net' => $c['net']]);
                return back()->with('ok', 'Payroll finalized: net pay '.number_format($c['net'], 2));
            case 'reopen':
                DB::table('payroll_runs')->where('user_id', $uid)->where('month', $month)->delete();
                DB::table('fines')->where('user_id', $uid)->whereBetween('date', ["$month-01", date('Y-m-t', strtotime("$month-01"))])->where('status', 'deducted')->update(['status' => 'outstanding']);
                DB::table('salary_advances')->where('user_id', $uid)->where('month', $month)->where('status', 'deducted')->update(['status' => 'outstanding']);
                Audit::log('payroll', $uid, 'payroll_reopened', ['month' => $month]);
                return back()->with('ok', 'Payroll reopened.');
        }
        abort(404);
    }
}
