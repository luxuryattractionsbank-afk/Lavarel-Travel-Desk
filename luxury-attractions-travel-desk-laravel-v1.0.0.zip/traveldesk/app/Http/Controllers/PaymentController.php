<?php

namespace App\Http\Controllers;

use App\Support\Audit;
use App\Support\Finance;
use App\Support\Pricing;
use App\Support\Settings;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PaymentController extends Controller
{
    public static function storeFile($file, string $dir): array
    {
        $ext = strtolower($file->getClientOriginalExtension());
        abort_unless(in_array($ext, ['pdf', 'jpg', 'jpeg', 'png']) && $file->getSize() <= 10 * 1024 * 1024, 422, 'Only PDF, JPG or PNG files up to 10 MB.');
        $path = $file->storeAs($dir, bin2hex(random_bytes(16)).'.'.$ext, 'local');
        return [$path, preg_replace('/[^\w.\- ]/', '_', $file->getClientOriginalName())];
    }

    public function store(Request $r, int $id)
    {
        $b = DB::table('bookings')->where('id', $id)->first();
        abort_unless($b && BookingController::allowed($b), 404);
        if ($b->status === 'cancelled') return back()->with('error', 'Cannot add a payment to a cancelled booking.');
        $d = $r->validate(['method' => 'required|in:cash,card', 'currency' => 'required|size:3', 'amount' => 'required|numeric|gt:0', 'reference' => 'nullable|string|max:120', 'slip' => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:10240']);
        $ps = Settings::get('payments');
        if ($d['method'] === 'card' && $ps['require_card_reference'] && empty($d['reference'])) return back()->with('error', 'Card payments need a transaction/reference number.');
        $cur = DB::table('currencies')->where('code', $d['currency'])->where('active', true)->first();
        if (! $cur) return back()->with('error', 'Unsupported currency.');
        $ch = $r->change_currency ?: null;
        $s = Pricing::settle($d['method'], (float) $d['amount'], (float) $cur->rate_to_base, (float) $b->balance_due, $ch, $ch ? Finance::rate($ch) : null, $r->filled('change_amount') ? $r->change_amount : null, (float) $ps['overpayment_tolerance'], $b->base_currency);
        if ($s['errors']) return back()->with('error', implode(' ', $s['errors']));
        [$path, $name] = $r->hasFile('slip') ? self::storeFile($r->file('slip'), 'slips') : [null, null];
        DB::transaction(function () use ($r, $id, $d, $cur, $s, $path, $name) {
            $pid = DB::table('payments')->insertGetId([
                'booking_id' => $id, 'booking_item_id' => $r->booking_item_id ?: null, 'method' => $d['method'], 'currency' => $cur->code, 'amount' => $d['amount'], 'exchange_rate' => $cur->rate_to_base,
                'base_amount' => $s['applied'], 'tendered_base' => $s['tendered'], 'overpayment_base' => $s['over'], 'change_currency' => $s['change_currency'], 'change_amount' => $s['change_amount'],
                'change_base' => $s['change_base'], 'rounding_base' => $s['rounding'], 'reference' => $d['reference'] ?? null, 'provider' => $d['method'] === 'card' ? $r->provider : null, 'card_type' => $r->card_type,
                'is_deposit' => $r->boolean('is_deposit'), 'notes' => $r->notes, 'user_id' => auth()->id(), 'slip_path' => $path, 'slip_name' => $name, 'paid_at' => now(),
            ]);
            Audit::log('booking', $id, 'payment_added', ['payment' => $pid, 'method' => $d['method'], 'currency' => $cur->code, 'amount' => $d['amount'], 'applied' => $s['applied'], 'change' => $s['change_amount']]);
            Finance::recalc($id);
        });
        return back()->with('ok', "Payment of {$cur->code} ".number_format($d['amount'], 2).' recorded'.($s['change_amount'] > 0 ? " · give change {$s['change_currency']} ".number_format($s['change_amount'], 2) : ''));
    }

    public function void(Request $r, int $id)
    {
        $p = DB::table('payments')->where('id', $id)->first();
        if (! $p || $p->status === 'void') return back()->with('error', 'Payment not found or already void.');
        if (strlen(trim((string) $r->reason)) < 3) return back()->with('error', 'A reason is required to void a payment.');
        if (DB::table('refunds')->where('payment_id', $id)->exists()) return back()->with('error', 'This payment has refunds and cannot be voided.');
        DB::table('payments')->where('id', $id)->update(['status' => 'void', 'void_reason' => $r->reason, 'voided_by_id' => auth()->id()]);
        Audit::log('booking', $p->booking_id, 'payment_voided', ['payment' => $id, 'reason' => $r->reason]);
        Finance::recalc($p->booking_id);
        return back()->with('ok', 'Payment voided.');
    }

    public function slip(Request $r, int $id)
    {
        $p = DB::table('payments')->where('id', $id)->first();
        abort_unless($p && $r->hasFile('slip'), 422);
        [$path, $name] = self::storeFile($r->file('slip'), 'slips');
        DB::table('payments')->where('id', $id)->update(['slip_path' => $path, 'slip_name' => $name]);
        Audit::log('booking', $p->booking_id, 'payment_slip_uploaded', ['payment' => $id]);
        return back()->with('ok', 'Slip uploaded.');
    }

    public function refund(Request $r, int $id)
    {
        $b = DB::table('bookings')->where('id', $id)->first();
        $d = $r->validate(['currency' => 'required|size:3', 'amount' => 'required|numeric|gt:0', 'method' => 'required|string|max:20', 'reason' => 'required|string|min:3|max:300', 'reference' => 'nullable|string|max:120']);
        $rate = Finance::rate($d['currency']);
        if ($r->payment_id) {
            $p = DB::table('payments')->where('id', $r->payment_id)->where('booking_id', $id)->where('status', 'active')->first();
            if (! $p) return back()->with('error', 'Invalid payment.');
            if ($p->currency === $d['currency']) $rate = (float) $p->exchange_rate;
            $prior = (float) DB::table('refunds')->where('payment_id', $p->id)->sum('base_amount');
            if (round($d['amount'] * $rate, 2) > round($p->base_amount - $prior, 2) + 0.01) return back()->with('error', 'Refund exceeds the refundable amount of this payment.');
        }
        $base = round($d['amount'] * $rate, 2);
        if ($base > round($b->paid_amount - $b->refunded_amount, 2) + 0.01) return back()->with('error', 'Refund exceeds the net amount paid.');
        $rid = DB::table('refunds')->insertGetId(['booking_id' => $id, 'payment_id' => $r->payment_id ?: null, 'currency' => $d['currency'], 'amount' => $d['amount'], 'exchange_rate' => $rate, 'base_amount' => $base,
            'method' => $d['method'], 'reference' => $d['reference'] ?? null, 'reason' => $d['reason'], 'user_id' => auth()->id(), 'created_at' => now()]);
        Audit::log('booking', $id, 'payment_refunded', ['refund' => $rid, 'amount' => $d['amount'], 'currency' => $d['currency'], 'reason' => $d['reason']]);
        Finance::recalc($id);
        return back()->with('ok', 'Refund recorded.');
    }

    /** Balance collected by the supplier's driver: settles the booking and credits the supplier account. */
    public function driver(Request $r, int $id)
    {
        $b = DB::table('bookings')->where('id', $id)->first();
        $d = $r->validate(['supplier_id' => 'required|integer', 'amount' => 'required|numeric|gt:0', 'reference' => 'nullable|string|max:120']);
        if ($b->balance_due <= 0) return back()->with('error', 'This booking has no balance due.');
        $applied = round(min($d['amount'], $b->balance_due), 2);
        DB::transaction(function () use ($id, $b, $d, $applied, $r) {
            $pid = DB::table('payments')->insertGetId(['booking_id' => $id, 'method' => 'driver', 'currency' => $b->base_currency, 'amount' => $d['amount'], 'exchange_rate' => 1, 'base_amount' => $applied,
                'tendered_base' => $d['amount'], 'overpayment_base' => round($d['amount'] - $applied, 2), 'rounding_base' => round($d['amount'] - $applied, 2), 'reference' => $d['reference'] ?? null,
                'provider' => 'Supplier driver', 'notes' => $r->notes, 'user_id' => auth()->id(), 'paid_at' => now()]);
            DB::table('supplier_transactions')->insert(['supplier_id' => $d['supplier_id'], 'type' => 'driver_collection', 'amount' => $d['amount'], 'reference' => $d['reference'] ?? $b->receipt_number,
                'notes' => "Balance collected by driver for {$b->receipt_number}", 'booking_id' => $id, 'payment_id' => $pid, 'user_id' => auth()->id(), 'occurred_at' => now()]);
            Audit::log('booking', $id, 'driver_collection_recorded', ['supplier' => $d['supplier_id'], 'amount' => $d['amount']]);
            Finance::recalc($id);
        });
        return back()->with('ok', 'Driver collection recorded and credited to the supplier account.');
    }
}
