<?php

namespace App\Http\Controllers;

use App\Support\Audit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TourController extends Controller
{
    public function index()
    {
        $tours = DB::table('tours')->orderBy('product_type')->orderBy('name')->get();
        $sup = DB::table('tour_suppliers')->join('suppliers', 'suppliers.id', '=', 'tour_suppliers.supplier_id')->get(['tour_id', 'suppliers.name'])->groupBy('tour_id');
        return view('tours.index', ['tours' => $tours, 'sup' => $sup, 'vehicles' => DB::table('vehicles')->whereNull('tour_id')->orderBy('capacity')->get()]);
    }

    public function edit($id)
    {
        $t = $id === 'new' ? null : DB::table('tours')->where('id', $id)->first();
        abort_if($id !== 'new' && ! $t, 404);
        return view('tours.edit', ['t' => $t, 'suppliers' => DB::table('suppliers')->orderBy('name')->get(),
            'linked' => $t ? DB::table('tour_suppliers')->where('tour_id', $t->id)->pluck('supplier_id')->all() : [],
            'options' => $t ? DB::table('tour_options')->where('tour_id', $t->id)->orderBy('sort')->orderBy('id')->get() : collect(),
            'addons' => $t ? DB::table('addons')->where('tour_id', $t->id)->get() : collect(), 'slots' => $t ? DB::table('pickup_slots')->where('tour_id', $t->id)->orderBy('pickup_start')->get() : collect(),
            'vehicles' => $t ? DB::table('vehicles')->where('tour_id', $t->id)->get() : collect()]);
    }

    public function save(Request $r, $id = null)
    {
        $d = $r->validate(['name' => 'required|string|max:150', 'code_prefix' => ['required', 'regex:/^[A-Za-z0-9]{1,6}$/'], 'product_type' => 'required|in:tour,ticket', 'duration_minutes' => 'nullable|integer|min:0',
            'shared_transfer_price' => 'nullable|numeric|min:0', 'opening_time' => 'nullable|date_format:H:i', 'closing_time' => 'nullable|date_format:H:i']);
        $vals = ['name' => $d['name'], 'code_prefix' => strtoupper($d['code_prefix']), 'product_type' => $d['product_type'], 'description' => $r->description, 'active' => $r->boolean('active'),
            'no_transfer_allowed' => $r->boolean('no_transfer_allowed'), 'shared_available' => $r->boolean('shared_available'), 'private_available' => $r->boolean('private_available'),
            'default_direction' => $r->default_direction === 'one_way' ? 'one_way' : 'two_way', 'shared_transfer_pricing' => $r->shared_transfer_pricing === 'extra' ? 'extra' : 'included',
            'shared_transfer_price' => (float) $r->shared_transfer_price, 'duration_minutes' => (int) $r->duration_minutes, 'opening_time' => $r->opening_time, 'closing_time' => $r->closing_time,
            'operating_hours' => $r->operating_hours, 'validity' => $r->validity, 'available_days' => json_encode(array_map('intval', $r->input('available_days', [0, 1, 2, 3, 4, 5, 6]))),
            'pickup_rules' => $r->pickup_rules, 'drop_rules' => $r->drop_rules, 'supplier_id' => $r->supplier_id ?: null, 'requires_ticket' => $r->boolean('requires_ticket'),
            'allow_over_capacity' => $r->boolean('allow_over_capacity'), 'notes' => $r->notes, 'terms' => $r->terms, 'updated_at' => now()];
        if ($id) DB::table('tours')->where('id', $id)->update($vals);
        else $id = DB::table('tours')->insertGetId($vals + ['created_at' => now()]);
        $ids = array_unique(array_filter(array_map('intval', array_merge($r->input('supplier_ids', []), [$vals['supplier_id']]))));
        DB::table('tour_suppliers')->where('tour_id', $id)->delete();
        foreach ($ids as $s) DB::table('tour_suppliers')->insert(['tour_id' => $id, 'supplier_id' => $s]);
        Audit::log('tour', (int) $id, 'tour_saved', ['name' => $vals['name'], 'suppliers' => $ids]);
        return redirect()->route('tours.edit', $id)->with('ok', 'Product saved.');
    }

    public function option(Request $r, int $id)
    {
        $d = $r->validate(['name' => 'required|string|max:150', 'pricing_method' => 'required|in:per_person,per_vehicle,per_group']);
        $num = fn ($k) => max(0, (float) $r->input($k));
        $min = function ($k, $list) use ($r) {
            if ($r->input($k) === null || $r->input($k) === '') return null;
            $v = (float) $r->input($k);
            if ($v > $list) throw \Illuminate\Validation\ValidationException::withMessages([$k => "Minimum ($v) cannot be higher than the listed price ($list)."]);
            return max(0, $v);
        };
        $vals = ['tour_id' => $id, 'name' => $d['name'], 'description' => $r->description, 'pricing_method' => $d['pricing_method'], 'adult_price' => $num('adult_price'), 'child_price' => $num('child_price'),
            'infant_price' => $num('infant_price'), 'group_price' => $num('group_price'), 'adult_allowed' => $r->boolean('adult_allowed'), 'child_allowed' => $r->boolean('child_allowed'),
            'infant_allowed' => $r->boolean('infant_allowed'), 'restriction_note' => $r->restriction_note, 'ticket_type' => $r->ticket_type, 'ticket_category' => $r->ticket_category,
            'active' => $r->boolean('active'), 'sort' => (int) $r->sort];
        foreach (['adult', 'child', 'infant', 'group'] as $k) $vals["min_{$k}_price"] = $min("min_{$k}_price", $vals["{$k}_price"]);
        if ($r->option_id) DB::table('tour_options')->where('id', $r->option_id)->update($vals);
        else DB::table('tour_options')->insert($vals);
        Audit::log('tour', $id, 'option_saved', ['name' => $d['name'], 'prices' => [$vals['adult_price'], $vals['child_price'], $vals['infant_price']]]);
        return back()->with('ok', 'Option saved.');
    }

    public function addon(Request $r, int $id)
    {
        $d = $r->validate(['name' => 'required|string|max:150', 'pricing_method' => 'required|in:per_person,per_unit,per_vehicle,per_group', 'price' => 'required|numeric|min:0', 'min_price' => 'nullable|numeric|min:0|lte:price']);
        $vals = ['tour_id' => $id, 'name' => $d['name'], 'pricing_method' => $d['pricing_method'], 'price' => $d['price'], 'min_price' => $d['min_price'] ?? null, 'active' => $r->boolean('active')];
        if ($r->addon_id) DB::table('addons')->where('id', $r->addon_id)->update($vals); else DB::table('addons')->insert($vals);
        Audit::log('tour', $id, 'addon_saved', $vals);
        return back()->with('ok', 'Add-on saved.');
    }

    public function slot(Request $r, int $id)
    {
        $d = $r->validate(['pickup_start' => 'required|date_format:H:i', 'pickup_end' => 'required|date_format:H:i|after_or_equal:pickup_start', 'drop_start' => 'nullable|date_format:H:i', 'drop_end' => 'nullable|date_format:H:i']);
        $vals = $d + ['tour_id' => $id, 'active' => $r->boolean('active')];
        if ($r->slot_id) DB::table('pickup_slots')->where('id', $r->slot_id)->update($vals); else DB::table('pickup_slots')->insert($vals);
        return back()->with('ok', 'Time slot saved.');
    }

    public function vehicle(Request $r)
    {
        $d = $r->validate(['name' => 'required|string|max:100', 'capacity' => 'required|integer|min:1', 'price' => 'required|numeric|min:0', 'supplier_cost' => 'nullable|numeric|min:0']);
        $vals = $d + ['tour_id' => $r->tour_id ?: null, 'active' => $r->boolean('active')];
        if ($r->vehicle_id) DB::table('vehicles')->where('id', $r->vehicle_id)->update($vals); else DB::table('vehicles')->insert($vals);
        return back()->with('ok', 'Vehicle saved.');
    }
}
