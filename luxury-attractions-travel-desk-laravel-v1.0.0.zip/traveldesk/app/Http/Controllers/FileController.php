<?php

namespace App\Http\Controllers;

use App\Support\Settings;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class FileController extends Controller
{
    /** Private files (tickets, payment slips) – only for users who can see the booking. */
    public function show(string $type, int $id)
    {
        $row = match ($type) { 'ticket' => DB::table('tickets')->where('id', $id)->first(), 'slip' => DB::table('payments')->where('id', $id)->first(), default => null };
        abort_unless($row, 404);
        $b = DB::table('bookings')->where('id', $row->booking_id)->first();
        abort_unless(BookingController::allowed($b) || can('tickets.manage'), 403);
        $path = $type === 'ticket' ? $row->file_path : $row->slip_path;
        $name = $type === 'ticket' ? $row->file_name : $row->slip_name;
        abort_unless($path && Storage::disk('local')->exists($path), 404);
        return Storage::disk('local')->response($path, $name, ['Cache-Control' => 'private, no-store', 'X-Content-Type-Options' => 'nosniff']);
    }

    public function branding(string $kind)
    {
        $c = Settings::get('company');
        $f = $kind === 'favicon' ? ($c['favicon'] ?: $c['logo']) : $c['logo'];
        if ($f && Storage::disk('public')->exists($f)) return Storage::disk('public')->response($f, null, ['Cache-Control' => 'public, max-age=300']);
        $svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="14" fill="#17223d"/><text x="32" y="42" font-family="Arial" font-weight="700" font-size="26" text-anchor="middle" fill="#e3c26b">LA</text></svg>';
        return response($svg, 200, ['Content-Type' => 'image/svg+xml', 'Cache-Control' => 'public, max-age=300']);
    }
}
