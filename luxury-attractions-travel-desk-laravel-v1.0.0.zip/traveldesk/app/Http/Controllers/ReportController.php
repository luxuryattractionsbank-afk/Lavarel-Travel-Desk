<?php

namespace App\Http\Controllers;

use App\Support\Settings;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
    private function data(Request $r): array
    {
        $from = $r->from ?: now()->startOfMonth()->toDateString(); $to = $r->to ?: today()->toDateString();
        $own = ! can('reports.view');
        $b = fn () => DB::table('bookings')->whereBetween('bookings.issued_at', ["$from 00:00:00", "$to 23:59:59"])->where('bookings.status', '!=', 'cancelled')->when($own, fn ($q) => $q->where('bookings.sales_person_id', auth()->id()))
            ->when($r->agent && ! $own, fn ($q) => $q->where('bookings.sales_person_id', $r->agent))->when($r->desk, fn ($q) => $q->where('bookings.travel_desk', $r->desk));
        $p = fn () => DB::table('payments')->join('bookings', 'bookings.id', '=', 'payments.booking_id')->where('payments.status', 'active')->whereBetween('payments.paid_at', ["$from 00:00:00", "$to 23:59:59"])->when($own, fn ($q) => $q->where('bookings.sales_person_id', auth()->id()))->when($r->method, fn ($q) => $q->where('payments.method', $r->method))->when($r->currency, fn ($q) => $q->where('payments.currency', $r->currency));
        $ids = $b()->pluck('id');
        return [
            'from' => $from, 'to' => $to, 'cur' => Settings::base(),
            'summary' => $b()->selectRaw('count(*) n, coalesce(sum(bookings.total_amount),0) sales, coalesce(sum(standard_total),0) std, coalesce(sum(discount_total),0) disc, coalesce(sum(balance_due),0) bal')->first(),
            'daily' => $b()->selectRaw('date(issued_at) k, count(*) n, sum(total_amount) t')->groupByRaw('date(issued_at)')->orderBy('k')->get(),
            'monthly' => $b()->selectRaw("date_format(issued_at, '%Y-%m') k, count(*) n, sum(total_amount) t")->groupByRaw("date_format(issued_at, '%Y-%m')")->orderBy('k')->get(),
            'byTour' => DB::table('booking_items')->whereIn('booking_id', $ids)->where('status', '!=', 'cancelled')->selectRaw('tour_name k, count(*) n, sum(adults+children+infants) pax, sum(total) t')->groupBy('tour_name')->orderByDesc('t')->get(),
            'byOption' => DB::table('booking_items')->whereIn('booking_id', $ids)->where('status', '!=', 'cancelled')->selectRaw("concat(tour_name, ' – ', coalesce(option_name,'-')) k, count(*) n, sum(total) t")->groupBy('tour_name', 'option_name')->orderByDesc('t')->get(),
            'byAgent' => $b()->leftJoin('users', 'users.id', '=', 'bookings.sales_person_id')->selectRaw('coalesce(users.full_name, "-") k, count(*) n, sum(bookings.total_amount) t, sum(bookings.balance_due) bal')->groupBy('users.full_name')->orderByDesc('t')->get(),
            'byDesk' => $b()->selectRaw('coalesce(travel_desk, "-") k, count(*) n, sum(total_amount) t')->groupBy('travel_desk')->orderByDesc('t')->get(),
            'byMethod' => $p()->selectRaw('method k, count(*) n, sum(base_amount) t')->groupBy('method')->get(),
            'byCurrency' => $p()->selectRaw('currency k, method m, sum(amount) a, sum(base_amount) t')->groupBy('currency', 'method')->orderBy('currency')->get(),
            'change' => $p()->where('change_amount', '>', 0)->selectRaw('change_currency k, sum(change_amount) a')->groupBy('change_currency')->pluck('a', 'k'),
            'outstanding' => $b()->join('customers', 'customers.id', '=', 'bookings.customer_id')->where('bookings.balance_due', '>', 0)->orderByDesc('bookings.balance_due')->limit(300)->get(['bookings.*', 'customers.name as cust']),
        ];
    }

    public function index(Request $r)
    {
        return view('reports', $this->data($r) + ['desks' => DB::table('travel_desks')->pluck('name'), 'agents' => DB::table('users')->orderBy('full_name')->get(['id', 'full_name']), 'currencies' => DB::table('currencies')->pluck('code')]);
    }

    public function export(Request $r)
    {
        $d = $this->data($r);
        $set = match ($r->report) {
            'by_tour' => [['Tour', 'Items', 'Pax', 'Sales'], $d['byTour']->map(fn ($x) => [$x->k, $x->n, $x->pax, $x->t])],
            'by_agent' => [['Agent', 'Bookings', 'Sales', 'Outstanding'], $d['byAgent']->map(fn ($x) => [$x->k, $x->n, $x->t, $x->bal])],
            'by_method' => [['Method', 'Payments', 'Base amount'], $d['byMethod']->map(fn ($x) => [$x->k, $x->n, $x->t])],
            'by_currency' => [['Currency', 'Method', 'Received', 'Base'], $d['byCurrency']->map(fn ($x) => [$x->k, $x->m, $x->a, $x->t])],
            'outstanding' => [['Receipt', 'Customer', 'Total', 'Balance', 'Collection'], $d['outstanding']->map(fn ($x) => [$x->receipt_number, $x->cust, $x->total_amount, $x->balance_due, $x->balance_collection])],
            default => [['Date', 'Bookings', 'Sales'], $d['daily']->map(fn ($x) => [$x->k, $x->n, $x->t])],
        };
        return response()->streamDownload(function () use ($set) { $o = fopen('php://output', 'w'); fwrite($o, "\xEF\xBB\xBF"); fputcsv($o, $set[0]); foreach ($set[1] as $row) fputcsv($o, $row); fclose($o); }, ($r->report ?: 'daily').'-'.$d['from'].'-'.$d['to'].'.csv', ['Content-Type' => 'text/csv']);
    }
}
