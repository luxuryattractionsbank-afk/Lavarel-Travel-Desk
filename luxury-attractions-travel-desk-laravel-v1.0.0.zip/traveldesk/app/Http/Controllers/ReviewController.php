<?php

namespace App\Http\Controllers;

use App\Support\Audit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReviewController extends Controller
{
    public function index()
    {
        $u = auth()->user();
        $see = $u->can('reviews.see_supplier');
        $rows = DB::table('supplier_reviews')->leftJoin('users', 'users.id', '=', 'supplier_reviews.user_id')->leftJoin('tours', 'tours.id', '=', 'supplier_reviews.tour_id')->leftJoin('suppliers', 'suppliers.id', '=', 'supplier_reviews.supplier_id')
            ->when(! $see && ! $u->can('suppliers.manage'), fn ($q) => $q->where('supplier_reviews.user_id', $u->id))->orderByDesc('supplier_reviews.id')->limit(200)
            ->get(['supplier_reviews.*', 'users.display_name as who', 'tours.name as tour', 'suppliers.name as supplier']);
        $toReview = $u->can('reviews.write') ? BookingController::scope(DB::table('booking_items')->join('bookings', 'bookings.id', '=', 'booking_items.booking_id')->join('customers', 'customers.id', '=', 'bookings.customer_id'))
            ->where('booking_items.status', '!=', 'cancelled')->whereBetween('tour_date', [today()->subDays(60), today()])
            ->whereNotExists(fn ($q) => $q->from('supplier_reviews as r')->whereColumn('r.booking_item_id', 'booking_items.id')->where('r.user_id', $u->id))
            ->orderByDesc('tour_date')->limit(50)->get(['booking_items.*', 'bookings.receipt_number', 'customers.name as cust']) : collect();
        return view('reviews', compact('rows', 'toReview', 'see'));
    }

    public function store(Request $r, int $id)
    {
        $it = DB::table('booking_items')->join('bookings', 'bookings.id', '=', 'booking_items.booking_id')->where('booking_items.id', $id)->first(['booking_items.*', 'bookings.created_by_id', 'bookings.sales_person_id']);
        abort_unless($it && BookingController::allowed($it), 403);
        $d = $r->validate(['rating' => 'required|integer|min:1|max:5', 'comment' => 'nullable|string|max:1000']);
        if (DB::table('supplier_reviews')->where('booking_item_id', $id)->where('user_id', auth()->id())->exists()) return back()->with('error', 'You have already reviewed this tour booking.');
        DB::table('supplier_reviews')->insert(['supplier_id' => $it->supplier_id, 'tour_id' => $it->tour_id, 'booking_item_id' => $id, 'tour_code' => $it->tour_code, 'rating' => $d['rating'], 'comment' => $d['comment'] ?? null, 'user_id' => auth()->id(), 'created_at' => now()]);
        Audit::log('review', $id, 'review_added', ['rating' => $d['rating']]);
        return back()->with('ok', 'Thank you – review saved.');
    }
}
