<?php

namespace App\Http\Controllers;

use App\Support\Audit;
use App\Support\SupplierCost;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;

class SupplierController extends Controller
{
    public function index()
    {
        return view('suppliers.index', ['rows' => DB::table('suppliers')->orderBy('name')->get(), 'bal' => SupplierCost::balances(),
            'money' => can('suppliers.payments') || can('suppliers.manage')]);
    }

    public function show(int $id)
    {
        $s = DB::table('suppliers')->where('id', $id)->first();
        abort_unless($s, 404);
        $offered = DB::table('tour_suppliers')->where('supplier_id', $id)->pluck('tour_id')->all();
        $tours = DB::table('tours')->whereIn('id', $offered)->orderBy('name')->get();
        $lists = $tours->map(fn ($t) => [
            't' => $t, 'options' => DB::table('tour_options')->where('tour_id', $t->id)->orderBy('sort')->get(), 'addons' => DB::table('addons')->where('tour_id', $t->id)->get(),
            'vehicles' => ($v = DB::table('vehicles')->where('tour_id', $t->id)->get())->count() ? $v : DB::table('vehicles')->whereNull('tour_id')->orderBy('capacity')->get(),
            'slots' => DB::table('pickup_slots')->where('tour_id', $t->id)->orderBy('pickup_start')->get(),
            'info' => DB::table('supplier_services_info')->where('supplier_id', $id)->where('tour_id', $t->id)->first(),
        ]);
        $pay = can('suppliers.payments') || can('suppliers.manage');
        return view('suppliers.show', [
            's' => $s, 'lists' => $lists, 'offered' => $offered, 'allTours' => DB::table('tours')->orderBy('name')->get(['id', 'name']), 'b' => SupplierCost::balances([$id])[$id], 'pay' => $pay,
            'prices' => DB::table('supplier_prices')->where('supplier_id', $id)->get()->keyBy('option_id'), 'addonCosts' => DB::table('supplier_addon_costs')->where('supplier_id', $id)->pluck('cost', 'addon_id'),
            'vehicleCosts' => DB::table('supplier_vehicle_costs')->where('supplier_id', $id)->get()->keyBy('vehicle_id'),
            'txs' => $pay ? DB::table('supplier_transactions')->leftJoin('users', 'users.id', '=', 'supplier_transactions.user_id')->leftJoin('bookings', 'bookings.id', '=', 'supplier_transactions.booking_id')->where('supplier_id', $id)->orderByDesc('occurred_at')->get(['supplier_transactions.*', 'users.display_name as who', 'bookings.receipt_number']) : collect(),
            'items' => $pay ? DB::table('booking_items')->join('bookings', 'bookings.id', '=', 'booking_items.booking_id')->join('customers', 'customers.id', '=', 'bookings.customer_id')->where('booking_items.supplier_id', $id)->where('booking_items.status', '!=', 'cancelled')->where('bookings.status', '!=', 'cancelled')->orderByDesc('tour_date')->limit(300)->get(['booking_items.*', 'bookings.receipt_number', 'customers.name as cust']) : collect(),
            'reviews' => DB::table('supplier_reviews')->leftJoin('users', 'users.id', '=', 'supplier_reviews.user_id')->where('supplier_id', $id)->orderByDesc('supplier_reviews.id')->get(['supplier_reviews.*', 'users.display_name as who']),
            'password' => can('suppliers.manage') && $s->platform_password ? rescue(fn () => Crypt::decryptString($s->platform_password), '', false) : '',
        ]);
    }

    public function save(Request $r, $id = null)
    {
        $d = $r->validate(['name' => 'required|string|max:150', 'email' => 'nullable|email']);
        $vals = ['name' => $d['name'], 'contact' => $r->contact, 'phone' => $r->phone, 'email' => $r->email, 'whatsapp_group' => $r->whatsapp_group, 'details' => $r->details, 'platform_url' => $r->platform_url,
            'platform_username' => $r->platform_username, 'notes' => $r->notes, 'active' => $r->boolean('active', true), 'updated_at' => now()];
        if ($r->filled('platform_password')) $vals['platform_password'] = Crypt::encryptString($r->platform_password);
        if ($r->boolean('clear_password')) $vals['platform_password'] = null;
        try {
            if ($id) DB::table('suppliers')->where('id', $id)->update($vals); else $id = DB::table('suppliers')->insertGetId($vals + ['created_at' => now()]);
        } catch (\Illuminate\Database\QueryException) {
            return back()->with('error', "{$d['name']} already exists.");
        }
        Audit::log('supplier', (int) $id, 'supplier_saved', ['name' => $d['name'], 'password_changed' => $r->filled('platform_password')]);
        return redirect()->route('suppliers.show', $id)->with('ok', 'Supplier saved.');
    }

    public function tours(Request $r, int $id)
    {
        DB::table('tour_suppliers')->where('supplier_id', $id)->delete();
        foreach (array_unique(array_map('intval', $r->input('tour_ids', []))) as $t) DB::table('tour_suppliers')->insert(['tour_id' => $t, 'supplier_id' => $id]);
        Audit::log('supplier', $id, 'supplier_tours_updated', ['tours' => $r->input('tour_ids', [])]);
        return back()->with('ok', 'Offered tours saved – fill in the price lists below.');
    }

    /** Price list for one tour: per option (adult/child/infant or group), per add-on, per vehicle, plus service details. */
    public function prices(Request $r, int $id, int $tour)
    {
        $v = fn ($x) => ($x === null || $x === '') ? null : max(0, round((float) $x, 2));
        DB::transaction(function () use ($r, $id, $tour, $v) {
            foreach (DB::table('tour_options')->where('tour_id', $tour)->pluck('id') as $o) {
                $a = $v($r->input("opt.$o.adult")); $c = $v($r->input("opt.$o.child")); $i = $v($r->input("opt.$o.infant"));
                if ($a === null && $c === null && $i === null) { DB::table('supplier_prices')->where('supplier_id', $id)->where('option_id', $o)->delete(); continue; }
                DB::table('supplier_prices')->updateOrInsert(['supplier_id' => $id, 'option_id' => $o], ['adult_cost' => $a ?? 0, 'child_cost' => $c ?? 0, 'infant_cost' => $i ?? 0]);
            }
            foreach (DB::table('addons')->where('tour_id', $tour)->pluck('id') as $a) {
                $c = $v($r->input("addon.$a"));
                if ($c === null) DB::table('supplier_addon_costs')->where('supplier_id', $id)->where('addon_id', $a)->delete();
                else DB::table('supplier_addon_costs')->updateOrInsert(['supplier_id' => $id, 'addon_id' => $a], ['cost' => $c]);
            }
            foreach ((array) $r->input('veh', []) as $vid => $row) {
                $c = $v($row['cost'] ?? null);
                if ($c === null) DB::table('supplier_vehicle_costs')->where('supplier_id', $id)->where('vehicle_id', $vid)->delete();
                else DB::table('supplier_vehicle_costs')->updateOrInsert(['supplier_id' => $id, 'vehicle_id' => (int) $vid], ['cost' => $c, 'hours' => $v($row['hours'] ?? null)]);
            }
            DB::table('supplier_services_info')->updateOrInsert(['supplier_id' => $id, 'tour_id' => $tour], $r->only('pickup_times', 'drop_times', 'tour_details', 'itinerary', 'notes'));
            DB::table('tour_suppliers')->insertOrIgnore(['tour_id' => $tour, 'supplier_id' => $id]);
        });
        Audit::log('supplier', $id, 'price_list_saved', ['tour' => $tour]);
        return back()->with('ok', 'Price list saved. New bookings assigned to this supplier use these costs.');
    }

    public function tx(Request $r, int $id)
    {
        $d = $r->validate(['type' => 'required|in:payment,adjustment', 'amount' => 'required|numeric|not_in:0', 'date' => 'nullable|date']);
        if ($d['type'] === 'payment' && $d['amount'] < 0) return back()->with('error', 'Payments must be positive.');
        DB::table('supplier_transactions')->insert(['supplier_id' => $id, 'type' => $d['type'], 'amount' => $d['amount'], 'reference' => $r->reference, 'notes' => $r->notes, 'user_id' => auth()->id(), 'occurred_at' => ($d['date'] ?? null) ? $d['date'].' 12:00:00' : now()]);
        Audit::log('supplier', $id, 'supplier_'.$d['type'], ['amount' => $d['amount'], 'reference' => $r->reference]);
        return back()->with('ok', $d['type'] === 'payment' ? 'Payment to supplier recorded.' : 'Adjustment recorded.');
    }

    public function queue(Request $r)
    {
        $assigned = $r->show === 'assigned';
        $rows = DB::table('booking_items')->join('bookings', 'bookings.id', '=', 'booking_items.booking_id')->join('customers', 'customers.id', '=', 'bookings.customer_id')->leftJoin('suppliers', 'suppliers.id', '=', 'booking_items.supplier_id')
            ->where('booking_items.status', '!=', 'cancelled')->where('bookings.status', '!=', 'cancelled')
            ->when($assigned, fn ($q) => $q->whereNotNull('booking_items.supplier_id')->orderByDesc('supplier_assigned_at'), fn ($q) => $q->whereNull('booking_items.supplier_id')->where('tour_date', '>=', today())->orderBy('tour_date'))
            ->limit(200)->get(['booking_items.*', 'bookings.receipt_number', 'customers.name as cust', 'customers.hotel', 'suppliers.name as supplier_name']);
        return view('suppliers.queue', ['rows' => $rows, 'assigned' => $assigned, 'suppliers' => DB::table('suppliers')->where('active', true)->orderBy('name')->get(['id', 'name']),
            'links' => DB::table('tour_suppliers')->get()->groupBy('tour_id')]);
    }

    public function assign(Request $r, int $id)
    {
        $it = DB::table('booking_items')->where('id', $id)->first();
        abort_unless($it, 404);
        $sid = $r->supplier_id ? (int) $r->supplier_id : null;
        $adds = DB::table('booking_item_addons')->where('booking_item_id', $id)->get()->map(fn ($a) => ['addon_id' => $a->addon_id, 'quantity' => $a->quantity])->all();
        $cost = SupplierCost::cost((array) $it, $sid, $adds);
        $manual = false;
        if ($r->filled('cost') && can('suppliers.payments') && abs((float) $r->cost - $cost) >= 0.01) { $cost = round((float) $r->cost, 2); $manual = true; }
        DB::table('booking_items')->where('id', $id)->update(['supplier_id' => $sid, 'supplier_cost' => $sid ? $cost : 0, 'supplier_cost_manual' => $manual, 'supplier_assigned_by_id' => $sid ? auth()->id() : null, 'supplier_assigned_at' => $sid ? now() : null]);
        if ($sid) DB::table('tour_suppliers')->insertOrIgnore(['tour_id' => $it->tour_id, 'supplier_id' => $sid]);
        DB::table('supplier_reviews')->where('booking_item_id', $id)->update(['supplier_id' => $sid]);
        Audit::log('booking', $it->booking_id, 'supplier_assigned', ['tour_code' => $it->tour_code, 'from' => $it->supplier_id, 'to' => $sid, 'cost' => $cost]);
        return back()->with('ok', $sid ? 'Assigned · supplier cost '.number_format($cost, 2).' added to their account.' : 'Supplier removed.');
    }
}
