<?php

namespace App\Http\Controllers;

use App\Support\Audit;
use App\Support\Fines;
use App\Support\Settings;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AttendanceController extends Controller
{
    public function index(Request $r)
    {
        $admin = can('attendance.manage');
        $from = $r->from ?: today()->startOfMonth()->toDateString(); $to = $r->to ?: today()->toDateString();
        $user = $admin ? $r->user : auth()->id();
        $rows = DB::table('attendance')->join('users', 'users.id', '=', 'attendance.user_id')->whereBetween('date', [$from, $to])->when($user, fn ($q) => $q->where('user_id', $user))->orderByDesc('date')->get(['attendance.*', 'users.display_name as name']);
        $other = DB::table('fines')->whereBetween('date', [$from, $to])->whereNotIn('type', ['late_checkin', 'early_checkout'])->where('status', '!=', 'waived')->when($user, fn ($q) => $q->where('user_id', $user))->groupBy('user_id')->selectRaw('user_id, sum(amount) s')->pluck('s', 'user_id');
        return view('attendance', ['rows' => $rows, 'other' => $other, 'from' => $from, 'to' => $to, 'admin' => $admin, 'cfg' => Settings::get('attendance'), 'cur' => Settings::base(),
            'staff' => $admin ? DB::table('users')->where('status', 'active')->orderBy('full_name')->get(['id', 'full_name']) : collect(),
            'mine' => DB::table('attendance')->where('user_id', auth()->id())->where('date', today()->toDateString())->first(),
            'offs' => DB::table('days_off')->join('users', 'users.id', '=', 'days_off.user_id')->where('date', '>=', $from)->when($user, fn ($q) => $q->where('user_id', $user))->orderBy('date')->get(['days_off.*', 'users.display_name as name'])]);
    }

    public function check(Request $r)
    {
        $today = today()->toDateString(); $time = now()->format('H:i');
        $a = DB::table('attendance')->where('user_id', auth()->id())->where('date', $today)->first();
        if ($r->op === 'in') {
            if ($a?->actual_in) return back()->with('error', "Already checked in at {$a->actual_in}.");
            $x = Fines::record(auth()->id(), $today, ['actual_in' => $time]);
            Audit::log('attendance', $x->id, 'check_in', ['time' => $time, 'fine' => $x->late_fine]);
            return back()->with('ok', "Checked in at $time. {$x->late_calc}");
        }
        if (! $a?->actual_in) return back()->with('error', 'You have not checked in today.');
        if ($a->actual_out) return back()->with('error', "Already checked out at {$a->actual_out}.");
        $x = Fines::record(auth()->id(), $today, ['actual_out' => $time]);
        Audit::log('attendance', $x->id, 'check_out', ['time' => $time, 'fine' => $x->early_fine]);
        return back()->with('ok', "Checked out at $time. {$x->early_calc}");
    }

    public function correct(Request $r)
    {
        $d = $r->validate(['user_id' => 'required|exists:users,id', 'date' => 'required|date', 'actual_in' => 'nullable|date_format:H:i', 'actual_out' => 'nullable|date_format:H:i', 'reason' => 'required|string|min:3']);
        $before = DB::table('attendance')->where('user_id', $d['user_id'])->where('date', $d['date'])->first();
        $x = Fines::record((int) $d['user_id'], $d['date'], ['actual_in' => $d['actual_in'] ?? null, 'actual_out' => $d['actual_out'] ?? null, 'notes' => $r->notes]);
        Audit::log('attendance', $x->id, 'attendance_corrected', ['before' => $before ? [$before->actual_in, $before->actual_out] : null, 'after' => [$x->actual_in, $x->actual_out], 'reason' => $d['reason']]);
        return back()->with('ok', "Saved. {$x->late_calc}. {$x->early_calc}");
    }

    public function dayoff(Request $r)
    {
        $d = $r->validate(['user_id' => 'required|exists:users,id', 'date' => 'required|date', 'type' => 'required|string|max:30']);
        DB::table('days_off')->insertOrIgnore($d + ['notes' => $r->notes, 'created_at' => now(), 'updated_at' => now()]);
        if (DB::table('attendance')->where('user_id', $d['user_id'])->where('date', $d['date'])->exists()) Fines::record((int) $d['user_id'], $d['date']);
        Audit::log('day_off', null, 'day_off_added', $d);
        return back()->with('ok', 'Day off added.');
    }

    public function fines(Request $r)
    {
        $admin = can('fines.manage');
        $user = $admin ? $r->user : auth()->id();
        $rows = DB::table('fines')->join('users', 'users.id', '=', 'fines.user_id')->leftJoin('users as cb', 'cb.id', '=', 'fines.created_by_id')->when($user, fn ($q) => $q->where('fines.user_id', $user))
            ->when($r->status, fn ($q) => $q->where('fines.status', $r->status))->orderByDesc('date')->limit(300)->get(['fines.*', 'users.display_name as name', 'cb.display_name as by']);
        return view('fines', ['rows' => $rows, 'admin' => $admin, 'cur' => Settings::base(), 'staff' => $admin ? DB::table('users')->orderBy('full_name')->get(['id', 'full_name']) : collect()]);
    }

    public function fine(Request $r)
    {
        if ($r->fine_id) {
            $r->validate(['status' => 'required|in:outstanding,deducted,waived']);
            DB::table('fines')->where('id', $r->fine_id)->update(['status' => $r->status, 'updated_at' => now()]);
            Audit::log('fine', (int) $r->fine_id, 'fine_status_changed', ['to' => $r->status]);
            return back()->with('ok', 'Fine updated.');
        }
        $d = $r->validate(['user_id' => 'required|exists:users,id', 'type' => 'required|string', 'amount' => 'required|numeric', 'date' => 'required|date', 'reason' => 'required|string|max:255']);
        $id = DB::table('fines')->insertGetId($d + ['notes' => $r->notes, 'status' => 'outstanding', 'created_by_id' => auth()->id(), 'created_at' => now(), 'updated_at' => now()]);
        Audit::log('fine', $id, 'fine_created', $d);
        return back()->with('ok', 'Fine created.');
    }
}
