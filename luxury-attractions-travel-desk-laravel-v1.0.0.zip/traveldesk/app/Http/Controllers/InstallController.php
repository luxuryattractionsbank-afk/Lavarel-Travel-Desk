<?php

namespace App\Http\Controllers;

use App\Support\Installer;
use Illuminate\Http\Request;

class InstallController extends Controller
{
    public function show() { return view('install', ['reqs' => Installer::requirements()]); }

    private function db(Request $r): array
    {
        return ['host' => trim($r->input('host', 'localhost')) ?: 'localhost', 'port' => trim($r->input('port', '3306')) ?: '3306', 'database' => trim((string) $r->input('database')), 'username' => trim((string) $r->input('username')), 'password' => (string) $r->input('password')];
    }

    public function test(Request $r)
    {
        $db = $this->db($r);
        if (! $db['database'] || ! $db['username']) return back()->withInput()->with('error', 'Enter the database name and username.');
        try {
            $msg = Installer::testDb($db);
        } catch (\Throwable $e) {
            return back()->withInput()->with('error', $e->getMessage());
        }
        session(['install_db' => $db]);
        return back()->with('ok', $msg);
    }

    public function install(Request $r)
    {
        $db = session('install_db');
        if (! $db) return redirect('/install')->with('error', 'Test the database connection first.');
        $d = $r->validate([
            'company_name' => 'required|string|max:150', 'company_phone' => 'nullable|string|max:60', 'company_email' => 'nullable|email',
            'admin_name' => 'required|string|max:120', 'admin_email' => 'required|email', 'admin_username' => ['required', 'regex:/^[a-zA-Z0-9._-]{3,40}$/'],
            'admin_password' => 'required|string|min:8|confirmed',
        ], ['admin_password.confirmed' => 'The two passwords do not match.', 'admin_username.regex' => 'Username: 3–40 letters, numbers, dot, dash or underscore.']);
        try {
            Installer::testDb($db);
            Installer::install($db, $d + ['example_data' => $r->boolean('example_data'), 'demo_agent' => $r->boolean('demo_agent')]);
        } catch (\Throwable $e) {
            report($e);
            return back()->withInput()->with('error', 'Installation failed: '.$e->getMessage());
        }
        session()->forget('install_db');
        return redirect('/login')->with('ok', 'Installation complete. Sign in with username “'.strtolower($d['admin_username']).'” and the password you chose.');
    }
}
