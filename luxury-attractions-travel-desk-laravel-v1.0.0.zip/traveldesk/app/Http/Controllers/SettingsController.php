<?php

namespace App\Http\Controllers;

use App\Support\Audit;
use App\Support\Perm;
use App\Support\Settings;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SettingsController extends Controller
{
    public function index(Request $r)
    {
        $tab = $r->tab ?: (can('settings.manage') ? 'company' : 'roles');
        return view('settings', ['tab' => $tab, 'company' => Settings::get('company'), 'booking' => Settings::get('booking'), 'payments' => Settings::get('payments'), 'att' => Settings::get('attendance'), 'email' => Settings::get('email'),
            'currencies' => DB::table('currencies')->orderByDesc('is_base')->orderBy('code')->get(), 'rates' => DB::table('exchange_rates')->orderByDesc('id')->limit(20)->get(), 'terms' => DB::table('terms')->get(),
            'templates' => DB::table('email_templates')->get(), 'desks' => DB::table('travel_desks')->orderBy('name')->get(), 'hotels' => DB::table('hotels')->orderBy('name')->get(), 'roles' => DB::table('roles')->get(), 'version' => trim(@file_get_contents(base_path('VERSION')) ?: '1.0.0'),
            'pendingMigrations' => rescue(fn () => count(array_diff(array_map(fn ($f) => basename($f, '.php'), glob(database_path('migrations/*.php'))), DB::table('migrations')->pluck('migration')->all())), 0, false)]);
    }

    public function save(Request $r, string $section)
    {
        abort_unless($section === 'role' ? can('users.manage') : can('settings.manage'), 403);
        switch ($section) {
            case 'company':
                $v = $r->only('name', 'phone', 'email', 'address', 'website', 'description', 'receipt_header', 'receipt_footer', 'legal_text');
                foreach (['logo', 'favicon'] as $f) if ($r->hasFile($f)) {
                    $r->validate([$f => 'image|mimes:png,jpg,jpeg,ico|max:4096']);
                    $v[$f] = $r->file($f)->store('branding', 'public');
                }
                if ($r->boolean('remove_logo')) $v['logo'] = null;
                Settings::save('company', $v);
                break;
            case 'booking':
                foreach (['receipt_format', 'tour_code_format'] as $k) if (! str_contains((string) $r->$k, '{SEQ')) return back()->with('error', "$k must contain {SEQ} or {SEQ:n}");
                if (! str_contains((string) $r->tour_code_format, '{PREFIX}')) return back()->with('error', 'Tour code format must contain {PREFIX}.');
                Settings::save('booking', ['receipt_format' => $r->receipt_format, 'tour_code_format' => $r->tour_code_format, 'agents_see_own_sales' => $r->boolean('agents_see_own_sales')]);
                break;
            case 'payments':
                Settings::save('payments', ['cash_enabled' => $r->boolean('cash_enabled'), 'card_enabled' => $r->boolean('card_enabled'), 'require_card_reference' => $r->boolean('require_card_reference'), 'overpayment_tolerance' => max(0, (float) $r->overpayment_tolerance),
                    'card_providers' => array_values(array_filter(array_map('trim', explode(',', (string) $r->card_providers)))), 'refund_methods' => array_values(array_filter(array_map('trim', explode(',', (string) $r->refund_methods))))]);
                break;
            case 'attendance':
                $rule = fn ($k) => ['grace' => (int) $r->input("$k.grace"), 'first' => (float) $r->input("$k.first"), 'additional' => (float) $r->input("$k.additional"), 'rounding' => in_array($r->input("$k.rounding"), ['threshold', 'ceil', 'floor']) ? $r->input("$k.rounding") : 'threshold'];
                Settings::save('attendance', ['late' => $rule('late'), 'early' => $rule('early'), 'default_in' => $r->default_in ?: '09:00', 'default_out' => $r->default_out ?: '18:00']);
                break;
            case 'email':
                $v = $r->only('host', 'port', 'encryption', 'username', 'from_name', 'from_email');
                if ($r->filled('password')) $v['password'] = encrypt($r->password);
                Settings::save('email', $v);
                break;
            case 'template':
                DB::table('email_templates')->where('key', $r->key)->update(['subject' => $r->subject, 'body' => $r->body]);
                break;
            case 'currency':
                $d = $r->validate(['code' => 'required|alpha|size:3', 'rate_to_base' => 'required|numeric|gt:0']);
                $code = strtoupper($d['code']);
                $old = DB::table('currencies')->where('code', $code)->first();
                if ($old?->is_base && (float) $d['rate_to_base'] !== 1.0) return back()->with('error', 'The base currency rate must be 1.');
                DB::table('currencies')->updateOrInsert(['code' => $code], ['name' => $r->name ?: $code, 'symbol' => $r->symbol ?: $code, 'rate_to_base' => $d['rate_to_base'], 'active' => $old?->is_base ? true : $r->boolean('active'), 'cash_accepted' => $r->boolean('cash_accepted'), 'is_base' => $old->is_base ?? false]);
                if (! $old || (float) $old->rate_to_base !== (float) $d['rate_to_base']) DB::table('exchange_rates')->insert(['currency' => $code, 'rate_to_base' => $d['rate_to_base'], 'user_id' => auth()->id(), 'created_at' => now()]);
                break;
            case 'base':
                $target = DB::table('currencies')->where('code', $r->code)->first();
                if ($target && ! $target->is_base) DB::transaction(function () use ($target) {
                    foreach (DB::table('currencies')->get() as $c) {
                        $rate = $c->code === $target->code ? 1 : round($c->rate_to_base / $target->rate_to_base, 6);
                        DB::table('currencies')->where('code', $c->code)->update(['rate_to_base' => $rate, 'is_base' => $c->code === $target->code]);
                        DB::table('exchange_rates')->insert(['currency' => $c->code, 'rate_to_base' => $rate, 'user_id' => auth()->id(), 'created_at' => now()]);
                    }
                });
                break;
            case 'terms':
                $d = $r->validate(['title' => 'required|string|max:150', 'content' => 'required|string']);
                $vals = $d + ['active' => $r->boolean('active'), 'is_default' => $r->boolean('is_default'), 'updated_at' => now()];
                $id = $r->terms_id ? tap((int) $r->terms_id, fn ($id) => DB::table('terms')->where('id', $id)->update($vals)) : DB::table('terms')->insertGetId($vals + ['created_at' => now()]);
                if ($vals['is_default']) DB::table('terms')->where('id', '!=', $id)->update(['is_default' => false]);
                break;
            case 'desk': case 'hotel':
                $r->validate(['name' => 'required|string|max:150']);
                $table = $section === 'desk' ? 'travel_desks' : 'hotels';
                $vals = $section === 'desk' ? ['name' => $r->name, 'location' => $r->location, 'active' => $r->boolean('active', true)] : ['name' => $r->name, 'area' => $r->area];
                try { $r->row_id ? DB::table($table)->where('id', $r->row_id)->update($vals) : DB::table($table)->insert($vals); } catch (\Illuminate\Database\QueryException) { return back()->with('error', "{$r->name} already exists."); }
                break;
            case 'role':
                $perms = array_values(array_intersect($r->input('perm', []), array_keys(Perm::LIST)));
                if ($r->role_id) {
                    $role = DB::table('roles')->where('id', $r->role_id)->first();
                    if ($role->key === 'admin') return back()->with('error', 'The Admin role always has full access.');
                    DB::table('roles')->where('id', $role->id)->update(['name' => $r->name, 'permissions' => json_encode($perms), 'updated_at' => now()]);
                } else {
                    DB::table('roles')->insert(['key' => \Illuminate\Support\Str::slug($r->name, '_').'_'.substr(md5(microtime()), 0, 4), 'name' => $r->name, 'permissions' => json_encode($perms), 'created_at' => now(), 'updated_at' => now()]);
                }
                break;
            case 'migrate':
                \Illuminate\Support\Facades\Artisan::call('migrate', ['--force' => true]);
                foreach (['config:clear', 'route:clear', 'view:clear'] as $c) \Illuminate\Support\Facades\Artisan::call($c);
                Audit::log('system', null, 'database_updated', ['output' => trim(\Illuminate\Support\Facades\Artisan::output())]);
                return back()->with('ok', 'Database is up to date. Existing records were kept.');
            default: abort(404);
        }
        Audit::log('settings', null, 'settings_updated', ['section' => $section]);
        return back()->with('ok', 'Saved.');
    }
}
