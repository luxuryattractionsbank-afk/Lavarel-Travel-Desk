<?php

namespace App\Http\Controllers;

use App\Support\Audit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class ProfileController extends Controller
{
    public function index() { return view('profile'); }

    public function save(Request $r)
    {
        $u = $r->user();
        if ($r->has('signature')) {
            $s = (string) $r->signature;
            DB::table('users')->where('id', $u->id)->update(['signature' => str_starts_with($s, 'data:image/png;base64,') && strlen($s) < 400000 ? $s : null]);
            Audit::log('user', $u->id, 'signature_updated');
            return back()->with('ok', 'Signature saved.');
        }
        $r->validate(['current' => 'required', 'password' => 'required|min:8|confirmed']);
        if (! Hash::check($r->current, $u->password)) return back()->with('error', 'Current password is incorrect.');
        DB::table('users')->where('id', $u->id)->update(['password' => Hash::make($r->password)]);
        Audit::log('user', $u->id, 'password_changed');
        return back()->with('ok', 'Password updated.');
    }
}
