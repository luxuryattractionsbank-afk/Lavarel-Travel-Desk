<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

// First visit after upload: create .env from .env.example with a fresh APP_KEY so the web installer can run.
$base = dirname(__DIR__);
if (! file_exists($base.'/.env') && file_exists($base.'/.env.example') && is_writable($base)) {
    $env = file_get_contents($base.'/.env.example');
    $env = preg_replace('/^APP_KEY=.*$/m', 'APP_KEY=base64:'.base64_encode(random_bytes(32)), $env);
    file_put_contents($base.'/.env', $env);
    @chmod($base.'/.env', 0600);
}

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(web: __DIR__.'/../routes/web.php', commands: __DIR__.'/../routes/console.php', health: '/up')
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->web(prepend: [\App\Http\Middleware\EnsureInstalled::class]);
        $middleware->alias(['perm' => \App\Http\Middleware\Permission::class]);
        $middleware->redirectGuestsTo('/login');
        $middleware->trustProxies(at: '*');
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        //
    })->create();
