<?php

use Illuminate\Foundation\Application;
use Illuminate\Http\Request;

define('LARAVEL_START', microtime(true));

/*
 | Host-friendly preflight: show actionable requirements instead of a blank
 | Composer HTTP 500 before Laravel is able to render its installer.
 */
$preflightProblems = [];
if (PHP_VERSION_ID < 80200) {
    $preflightProblems[] = 'PHP 8.2 or newer is required. This server is running PHP '.PHP_VERSION.'.';
}
foreach (['pdo_mysql', 'mbstring', 'openssl', 'dom', 'curl', 'gd'] as $extension) {
    if (! extension_loaded($extension)) {
        $preflightProblems[] = 'Enable the PHP extension: '.$extension;
    }
}
if (! file_exists(__DIR__.'/../vendor/autoload.php')) {
    $preflightProblems[] = 'Composer dependencies are missing (vendor/autoload.php was not found). Upload the complete package.';
}
foreach ([__DIR__.'/../storage' => 'storage', __DIR__.'/../bootstrap/cache' => 'bootstrap/cache'] as $path => $label) {
    if (! is_dir($path) || ! is_writable($path)) {
        $preflightProblems[] = 'The '.$label.' folder must exist and be writable (normally permission 755 on Hostinger).';
    }
}
$envPath = __DIR__.'/../.env';
if (! file_exists($envPath) && ! is_writable(dirname($envPath))) {
    $preflightProblems[] = 'The application root must be writable so the installer can create .env.';
}

if ($preflightProblems) {
    http_response_code(503);
    header('Content-Type: text/html; charset=UTF-8');
    $items = implode('', array_map(static fn (string $message): string => '<li>'.htmlspecialchars($message, ENT_QUOTES, 'UTF-8').'</li>', $preflightProblems));
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Travel Desk server check</title><style>body{margin:0;background:#0f1a33;color:#17223d;font:16px/1.55 Arial,sans-serif}main{max-width:720px;margin:8vh auto;background:#fff;border-radius:16px;padding:32px;box-shadow:0 20px 60px #0005}b,h1{color:#0f1a33}.mark{display:grid;place-items:center;width:58px;height:58px;border-radius:14px;background:#c9a24a;font-size:24px;font-weight:800}li{margin:10px 0}.help{background:#fff8e5;border-left:4px solid #c9a24a;padding:14px 16px;margin-top:24px}code{background:#eef1f6;padding:2px 5px;border-radius:4px}</style></head><body><main><div class="mark">LA</div><h1>Travel Desk server check</h1><p>The application files are present, but the server is not ready to run Laravel.</p><ul>'.$items.'</ul><div class="help"><b>Hostinger:</b> open <b>Websites → Dashboard → PHP Configuration</b>, select PHP 8.2 or 8.3, and click Update. For this subdomain only, add <code>SetHandler application/x-lsphp82</code> at the top of its <code>.htaccess</code>. Then reload this page.</div></main></body></html>';
    exit;
}

if (file_exists($maintenance = __DIR__.'/../storage/framework/maintenance.php')) {
    require $maintenance;
}

require __DIR__.'/../vendor/autoload.php';

/** @var Application $app */
$app = require_once __DIR__.'/../bootstrap/app.php';
$app->handleRequest(Request::capture());
