# Luxury Attractions Travel Desk v1.0.1 — Hostinger package

This is the complete Laravel 12 + MySQL package. It includes `vendor/` and extracts directly into the application folder (there is no extra `traveldesk/` wrapper).

## Install on traveldesk.starthenights.com

1. In Hostinger hPanel, open **Websites → Dashboard → PHP Configuration**. Choose **PHP 8.2 or PHP 8.3**, then click **Update**. The old site response showed PHP 8.1.34, which Laravel cannot use.
2. Create a new empty MySQL database and database user. Grant that user all privileges on the database.
3. Empty the subdomain folder, upload this ZIP there, and extract it. `artisan`, `app`, `public`, `storage`, and `vendor` must be directly in that folder.
4. Recommended: point the subdomain document root to this package's `public` folder. If Hostinger does not offer that option, leave the document root at the package root; the included root `.htaccess` safely forwards requests to `public/`.
5. Ensure `storage` and `bootstrap/cache` are writable. On Hostinger, permission **755** is normally correct.
6. Open `https://traveldesk.starthenights.com/install`. The package creates `.env` and an application key automatically, then asks for your database and administrator details.

## If the browser still shows a server-check page

Follow every item shown there. In particular, enable `pdo_mysql`, `mbstring`, `openssl`, `dom`, `curl`, `gd`, `fileinfo`, `zip`, and `bcmath` in PHP Configuration.

## Important

Do not install `laravel-travel-desk-v1.1.0-full.zip` as a standalone application. That archive is an incomplete update snapshot: it has no `vendor/`, no `composer.lock`, and omits required configuration and application modules.
